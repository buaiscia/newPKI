<?php


/**
 * Class SimpleSAML_Error_NoPassive
 *
 * @deprecated This class has been deprecated and will be removed in SimpleSAMLphp 2.0. Please use
 * SimpleSAML\Module\saml\Error\NoPassive instead.
 *
 * @see \SimpleSAML\Module\saml\Error\NoPassive
 */
class SimpleSAML_Error_NoPassive extends SimpleSAML_Error_Exception {

}
