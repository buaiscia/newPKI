<?php

/**
 * Baseclass for user error exceptions
 * 
 * 
 * @author Thomas Graff <thomas.graff@uninett.no>
 * @package SimpleSAMLphp_base
 *
 */
class SimpleSAML_Error_User extends SimpleSAML_Error_Exception{
	
}
