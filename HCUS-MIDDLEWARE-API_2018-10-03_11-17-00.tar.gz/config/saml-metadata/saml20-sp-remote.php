<?php

@include __DIR__ . '/../vendor/autoload.php';
@include __DIR__ . '/../../vendor/autoload.php';

use Symfony\Component\Yaml\Yaml;

$appConfig = Yaml::parse(\file_get_contents(__DIR__ . '/../default.yml'));

$localAppConfigLocation = __DIR__ . '/../local.yml';
if (file_exists($localAppConfigLocation)) {
    $appConfig = array_replace_recursive($appConfig, Yaml::parse(\file_get_contents($localAppConfigLocation)));
}

$metadata = [];

foreach ($appConfig['saml']['sp'] as $k => $sp) {
    $metadata[$k] = [
        'AssertionConsumerService' => $sp['AssertionConsumerService'],
        'SingleLogoutService'      => $sp['SingleLogoutService'],
        'certificate'              => $sp['certificate'],
    ];
}