<?php

@include __DIR__ . '/../vendor/autoload.php';
@include __DIR__ . '/../../vendor/autoload.php';

use Symfony\Component\Yaml\Yaml;

$appConfig = Yaml::parse(\file_get_contents(__DIR__ . '/../default.yml'));

$localAppConfigLocation = __DIR__ . '/../local.yml';
if (file_exists($localAppConfigLocation)) {
    $appConfig = array_replace_recursive($appConfig, Yaml::parse(\file_get_contents($localAppConfigLocation)));
}

$metadata[$appConfig['saml']['entityID']] = [
    'host' => '__DEFAULT__',
    'privatekey' => 'server.key',
    'certificate' => 'server.crt',
    'auth' => 'api',
    'attributes.NameFormat' => 'urn:oasis:names:tc:SAML:2.0:attrname-format:uri',
    'NameIDFormat' => 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
    'assertion.encryption' => true,
    'sign.logout' => true,
    'signature.algorithm' => 'http://www.w3.org/2001/04/xmldsig-more#rsa-sha256',
    'simplesaml.nameidattribute' => 'emailid',
    'SingleSignOnServiceBinding' => 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST',
    'authproc' => [
        100 => ['class' => 'core:AttributeMap', 'name2oid'],
    ],
];
