<?php

require __DIR__ . '/../../vendor/autoload.php';

use Symfony\Component\Yaml\Yaml;

$appConfig = Yaml::parse(\file_get_contents(__DIR__ . '/../default.yml'));

$localAppConfigLocation = __DIR__ . '/../local.yml';
if (file_exists($localAppConfigLocation)) {
    $appConfig = array_replace_recursive($appConfig, Yaml::parse(\file_get_contents($localAppConfigLocation)));
}


if (!defined('ROOT_DIR')) {
    define('ROOT_DIR', __DIR__ . '/../../');
}

$trustedDomains = [
    parse_url($appConfig['base']['url']['api'])['host'],
    parse_url($appConfig['base']['url']['web'])['host']
];

if (isset(parse_url($appConfig['base']['url']['api'])['port'])) {
    $trustedDomains[] = parse_url($appConfig['base']['url']['api'])['host'] . ':' . parse_url($appConfig['base']['url']['api'])['port'];
}

if (isset(parse_url($appConfig['base']['url']['web'])['port'])) {
    $trustedDomains[] = parse_url($appConfig['base']['url']['web'])['host'] . ':' . parse_url($appConfig['base']['url']['web'])['port'];
}

$config = [
    // Base information
    'baseurlpath' => '/saml/',
    'certdir' => 'cert/',
    'loggingdir' => __DIR__ .'/../../logs/',
    'datadir' => __DIR__ .'/../../data/',
    'tempdir' => '/tmp/simplesaml',

    // Derive debug from YAML
    'debug' => $appConfig['debug'],
    'showerrors' => $appConfig['debug'],
    'errorreporting' => $appConfig['debug'],
    'debug.validatexml' => !$appConfig['debug'],

    // Admin information derived from YAML
    'auth.adminpassword' => $appConfig['saml']['auth.adminpassword'],
    'admin.protectindexpage' => $appConfig['saml']['admin.protectindex'],
    'admin.protectmetadata' => $appConfig['saml']['admin.protectmetadata'],
    'secretsalt' => $appConfig['saml']['secretsalt'],

    // Technical information derived from YAML
    'technicalcontact_name' => $appConfig['saml']['technicalcontact_name'],
    'technicalcontact_email' => $appConfig['saml']['technicalcontact_email'],

    // Determine the timezone from UTC/ZULU
    'timezone' => null,

    // Log settings go here
    'logging.level' => $appConfig['debug'] ? SimpleSAML_Logger::DEBUG : SimpleSAML_Logger::NOTICE,
    'logging.handler' => 'file',

    'logging.facility' => defined('LOG_LOCAL5') ? constant('LOG_LOCAL5') : LOG_USER,
    'logging.processname' => 'simplesamlphp',
    'logging.logfile' => 'simplesamlphp.log',

    // Enable IDP for SAML 2.0
    'enable.saml20-idp' => true,
    'enable.shib13-idp' => false,
    'enable.adfs-idp' => false,
    'enable.wsfed-sp' => false,
    'enable.authmemcookie' => false,

    // These attributes control how long the session is valid for
    'session.duration' => (15 * 60),
    'session.datastore.timeout' => (15 * 60),
    'session.state.timeout' => (15 * 60),

    // These attributes control how long the cookie is valid for
    'session.cookie.name' => 'HomeCreditSAML',
    'session.cookie.lifetime' => (15 * 60),
    'session.cookie.path' => '/saml/',
    'session.cookie.domain' => parse_url($appConfig['base']['url']['api'])['host'],
    'session.cookie.secure' => true,

    'enable.http_post' => false,

    // Don't override these values'
    'session.phpsession.cookiename' => 'HomeCreditSession',
    'session.phpsession.savepath' => null,
    'session.phpsession.httponly' => true,
    'session.authtoken.cookiename' => 'HomeCreditAuthToken',
    'session.rememberme.enable' => false,
    'session.rememberme.checked' => false,
    'session.rememberme.lifetime' => (14 * 86400),

    // This controls the language's SimpleSaml will translate too
    'language.available' => [
        'en'//, 'es'
    ],
    'language.rtl' => ['ar', 'dv', 'fa', 'ur', 'he'],
    'language.default' => 'en',
    'language.parameter.name' => 'language',
    'language.parameter.setcookie' => true,
    'language.cookie.name' => 'language',
    'language.cookie.domain' => parse_url($appConfig['base']['url']['api'])['host'],
    'language.cookie.path' => '/saml/',
    'language.cookie.lifetime' => (60 * 60 * 24 * 900),

    'attributes.extradictionary' => null,

    // This controls the theme
    'theme.use' => 'hcus:hcus',

    'default-wsfed-idp' => 'urn:federation:pingfederate:localhost',

    // Discovery settings
    'idpdisco.enableremember' => false,
    'idpdisco.rememberchecked' => false,
    'idpdisco.validate' => true,
    'idpdisco.extDiscoveryStorage' => null,
    'idpdisco.layout' => 'dropdown',
    'shib13.signresponse' => true,

    /*
     * Authentication processing filters that will be executed for all IdPs
     * Both Shibboleth and SAML 2.0
     */
    'authproc.idp' => [
        /* Enable the authproc filter below to add URN Prefixces to all attributes
         10 => array(
             'class' => 'core:AttributeMap', 'addurnprefix'
         ), */
        /* Enable the authproc filter below to automatically generated eduPersonTargetedID.
        20 => 'core:TargetedID',
        */

        // Adopts language from attribute to use in UI
        30 => 'core:LanguageAdaptor',

        /* Add a realm attribute from edupersonprincipalname
        40 => 'core:AttributeRealm',
         */
        45 => [
            'class'         => 'core:StatisticsWithAttribute',
            'attributename' => 'realm',
            'type'          => 'saml20-idp-SSO',
        ],

        /* When called without parameters, it will fallback to filter attributes ‹the old way›
         * by checking the 'attributes' parameter in metadata on IdP hosted and SP remote.
         */
        50 => 'core:AttributeLimit',

        /*
         * Search attribute "distinguishedName" for pattern and replaces if found

        60 => array(
            'class' => 'core:AttributeAlter',
            'pattern' => '/OU=studerende/',
            'replacement' => 'Student',
            'subject' => 'distinguishedName',
            '%replace',
        ),
         */

        /*
         * Consent module is enabled (with no permanent storage, using cookies).

        90 => array(
            'class' => 'consent:Consent',
            'store' => 'consent:Cookie',
            'focus' => 'yes',
            'checked' => TRUE
        ),
         */
        // If language is set in Consent module it will be added as an attribute.
        99 => 'core:LanguageAdaptor',
    ],

    /*
     * Authentication processing filters that will be executed for all SPs
     * Both Shibboleth and SAML 2.0
     */
    'authproc.sp' => [
        /*
        10 => array(
            'class' => 'core:AttributeMap', 'removeurnprefix'
        ),
        */

        /*
         * Generate the 'group' attribute populated from other variables, including eduPersonAffiliation.
         60 => array(
            'class' => 'core:GenerateGroups', 'eduPersonAffiliation'
        ),
        */
        /*
         * All users will be members of 'users' and 'members'
        61 => array(
            'class' => 'core:AttributeAdd', 'groups' => array('users', 'members')
        ),
        */

        // Adopts language from attribute to use in UI
        90 => 'core:LanguageAdaptor',
    ],

    /*
     * This option configures the metadata sources. The metadata sources is given as an array with
     * different metadata sources. When searching for metadata, simpleSAMPphp will search through
     * the array from start to end.
     *
     * Each element in the array is an associative array which configures the metadata source.
     * The type of the metadata source is given by the 'type' element. For each type we have
     * different configuration options.
     *
     * Flat file metadata handler:
     * - 'type': This is always 'flatfile'.
     * - 'directory': The directory we will load the metadata files from. The default value for
     *                this option is the value of the 'metadatadir' configuration option, or
     *                'metadata/' if that option is unset.
     *
     * XML metadata handler:
     * This metadata handler parses an XML file with either an EntityDescriptor element or an
     * EntitiesDescriptor element. The XML file may be stored locally, or (for debugging) on a remote
     * web server.
     * The XML hetadata handler defines the following options:
     * - 'type': This is always 'xml'.
     * - 'file': Path to the XML file with the metadata.
     * - 'url': The URL to fetch metadata from. THIS IS ONLY FOR DEBUGGING - THERE IS NO CACHING OF THE RESPONSE.
     *
     * MDX metadata handler:
     * This metadata handler looks up for the metadata of an entity at the given MDX server.
     * The MDX metadata handler defines the following options:
     * - 'type': This is always 'mdx'.
     * - 'server': URL of the MDX server (url:port). Mandatory.
     * - 'validateFingerprint': The fingerprint of the certificate used to sign the metadata.
     *                          You don't need this option if you don't want to validate the signature on the metadata. Optional.
     * - 'cachedir': Directory where metadata can be cached. Optional.
     * - 'cachelength': Maximum time metadata cah be cached, in seconds. Default to 24
     *                  hours (86400 seconds). Optional.
     *
     * PDO metadata handler:
     * This metadata handler looks up metadata of an entity stored in a database.
     *
     * Note: If you are using the PDO metadata handler, you must configure the database
     * options in this configuration file.
     *
     * The PDO metadata handler defines the following options:
     * - 'type': This is always 'pdo'.
     *
     *
     * Examples:
     *
     * This example defines two flatfile sources. One is the default metadata directory, the other
     * is a metadata directory with autogenerated metadata files.
     *
     * 'metadata.sources' => array(
     *     array('type' => 'flatfile'),
     *     array('type' => 'flatfile', 'directory' => 'metadata-generated'),
     *     ),
     *
     * This example defines a flatfile source and an XML source.
     * 'metadata.sources' => array(
     *     array('type' => 'flatfile'),
     *     array('type' => 'xml', 'file' => 'idp.example.org-idpMeta.xml'),
     *     ),
     *
     * This example defines an mdx source.
     * 'metadata.sources' => array(
     *     array('type' => 'mdx', server => 'http://mdx.server.com:8080', 'cachedir' => '/var/simplesamlphp/mdx-cache', 'cachelength' => 86400)
     *     ),
     *
     * This example defines an pdo source.
     * 'metadata.sources' => array(
     *     array('type' => 'pdo')
     *     ),
     *
     * Default:
     * 'metadata.sources' => array(
     *     array('type' => 'flatfile')
     *     ),
     */
    'metadata.sources' => [
        ['type' => 'flatfile'],
    ],

    'store.type'                    => 'phpsession',

    // Sign the metadata file using the default keys
    'metadata.sign.enable' => true,
    'metadata.sign.privatekey' => null,
    'metadata.sign.privatekey_pass' => null,
    'metadata.sign.certificate' => null,

    'proxy' => null,

    'trusted.url.domains' => array_merge($trustedDomains, $appConfig['saml']['domains'])
];