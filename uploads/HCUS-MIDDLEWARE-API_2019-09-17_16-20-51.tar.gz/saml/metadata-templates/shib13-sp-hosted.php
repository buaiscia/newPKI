<?php
/**
 * SAML 1.1 SP configuration for SimpleSAMLphp.
 *
 * See: https://simplesamlphp.org/docs/stable/saml:sp
 */

/*
 * Example of hosted Shibboleth 1.3 SP.
 */
$metadata['__DYNAMIC:1__'] = array(
	'host' => '__DEFAULT__',
);
