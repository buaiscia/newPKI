<?php

@include __DIR__ . '/../vendor/autoload.php';
@include __DIR__ . '/../../vendor/autoload.php';

use Symfony\Component\Yaml\Yaml;

$appConfig = Yaml::parse(\file_get_contents(__DIR__ . '/../default.yml'));

$localAppConfigLocation = __DIR__ . '/../local.yml';
if (file_exists($localAppConfigLocation)) {
    $appConfig = array_replace_recursive($appConfig, Yaml::parse(\file_get_contents($localAppConfigLocation)));
}

/**
 * Pulls the entity id from the auth state
 * @param array $request
 * @return string
 */
function getSpEntityIdFromAuthState($request)
{
    if (!isset($request['AuthState'])) {
        return null;
    }

    $url = explode(':', $request['AuthState']);
    unset($url[0]);
    $url = implode(':', $url);
    $queryParams = explode('&', parse_url($url)['query']);
    $spEntityId = null;
    foreach ($queryParams as $query) {
        if (stripos($query, 'spentityid') !== false) {
            return explode('=', $query)[1];
            break;
        }
    }

    return null;
}

/**
 * Pulls service provider config
 * @param array $request
 * @return array
 */
function getSpConfigFromEntityId($appConfig, $entityId)
{
    if ($entityId === null) {
        return null;
    }

    if (isset($appConfig['saml']['sp'][$entityId])) {
        return $appConfig['saml']['sp'][$entityId];
    }

    return null;
}

$spEntityId = getSpEntityIdFromAuthState($_REQUEST);

$config = [
    'api' => [
        'api:Api',
        'entityID'      => $appConfig['saml']['entityID'],
        'api'           => $appConfig['base']['url']['api'],
        'web'           => $appConfig['base']['url']['web'],
        'debug'         => $appConfig['debug'],
        'api.secret'    => $appConfig['saml']['api.secret'],
        'cid'           => $appConfig['saml']['cid'],
        'spEntityId'    => $spEntityId,
        'sp'            => getSpConfigFromEntityId($appConfig, $spEntityId)
    ]
];

// Allow admin logins in debug mode
if ($appConfig['debug']) {
    $config['admin'] = [
        'core:AdminPassword',
    ];
}