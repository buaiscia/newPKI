<?php

use HomeCredit\Provider\BankRepositoryServiceProvider;
use Monolog\Logger;
use Ramsey\Uuid\Uuid;
use Silex\Application;
use Silex\Provider\DoctrineServiceProvider;
use Silex\Provider\HttpFragmentServiceProvider;
use Silex\Provider\LocaleServiceProvider;
use Silex\Provider\MonologServiceProvider;
use Silex\Provider\ServiceControllerServiceProvider;
use Silex\Provider\ValidatorServiceProvider;
use Silex\Provider\WebProfilerServiceProvider;
use Symfony\Component\Yaml\Yaml;
use Monolog\Handler\HandlerInterface;
use JDesrosiers\Silex\Provider\CorsServiceProvider;
use Symfony\Component\Translation\Loader\PoFileLoader;
use Silex\Provider\TranslationServiceProvider;
use Moust\Silex\Provider\CacheServiceProvider;
use Symfony\Component\Debug\ErrorHandler;
use Symfony\Component\Debug\ExceptionHandler;
use Monolog\Handler\StreamHandler;
use Symfony\Component\HttpFoundation\Request;

if (!defined("ROOT_DIR")) {
    define("ROOT_DIR", dirname(dirname(__FILE__)) . '/');
}

$app = new Application();

// App Config
$appConfig = Yaml::parse(\file_get_contents(__DIR__ . '/default.yml'));
$localAppConfigLocation = __DIR__ . '/local.yml';
if (file_exists($localAppConfigLocation)) {
    $appConfig = array_replace_recursive($appConfig, Yaml::parse(\file_get_contents($localAppConfigLocation)));
}

$app['config'] = $appConfig;

// Debug mode?
$app['debug'] = $app['config']['debug'];

// Force hard error loging to a file we have access to
ini_set('log_errors', 1);
ini_set('error_log', ROOT_DIR . '/logs/php-errors.log');

// If in debug mode, track all errors and display them
if ($app['debug']) {
    error_reporting(-1);
    ini_set('display_errors', 'true');
}

// Register the error handlers
ErrorHandler::register();
ExceptionHandler::register($app['debug']);

// Translations
$app->register(new LocaleServiceProvider());

$app->register(new TranslationServiceProvider(), [
    'locale' => $app['locale'],
    //'translator.cache_dir' => ROOT_DIR . '/cache/translations',
    'locale_fallbacks' => [ 'en' ],
]);

$app->extend('translator', function ($translator, $app) {
    $translator->addLoader('po', new PoFileLoader());
    $translator->addResource('po', ROOT_DIR . 'translations/messages.en.po', 'en');
    $translator->addResource('po', ROOT_DIR . 'translations/messages.es.po', 'es');

    return $translator;
});

// Twig
$app->register(new Silex\Provider\TwigServiceProvider(), [
    'twig.path' => ROOT_DIR . '/src/Views'
]);

// Swiftmailer
$app->register(new Silex\Provider\SwiftmailerServiceProvider());

$swiftmailerOptions = [
    'host' => $app['config']['mail']['host'],
    'port' => $app['config']['mail']['port'],
    'logging' => $app['debug']
];

if (!empty($app['config']['mail']['username'])) {
    $swiftmailerOptions['username'] = $app['config']['mail']['username'];
}

if (!empty($app['config']['mail']['password'])) {
    $swiftmailerOptions['password'] = $app['config']['mail']['password'];
}

if (!empty($app['config']['mail']['security'])) {
    $swiftmailerOptions['security'] = $app['config']['mail']['security'];
}

$app['swiftmailer.options'] = $swiftmailerOptions;

// Redis Cache
$app->register(new CacheServiceProvider(), [
    'cache.options' => [
        'driver' => 'redis',
        'redis' => function () use ($app) {
            $redis = new Redis;
            $redis->connect($app['config']['redis']['host'], $app['config']['redis']['port']);
            return $redis;
        }
    ]
]);

// Logging
$app->register(
    new MonologServiceProvider(),
    [
        'monolog.logfile' => ROOT_DIR . '/logs/app.log',
        'monolog.level' => constant('\Monolog\Logger::' . $app['config']['log']['level']),
        'monolog.name' => $app['config']['name'],
    ]
);

$app['request.id'] = null;

// Fetch the HCITRACE header, or generate a random UUID4
$app->before(function (Request $request, Application $app) {
    $app['request.id'] = $request->headers->get('HCITRACE', Uuid::uuid4()->toString());
});

$app->extend('monolog', function (Logger $logger, Application $app) {
    $logger->pushProcessor(
        function ($data) use ($app) {
            $data['extra']['request_id'] = $app['request.id'];
            if (isset($data['context']['exception']) && $data['context']['exception'] instanceof \Exception) {
                $exception = $data['context']['exception'];
                unset($data['context']['exception']);
                $data['context']['exception']['message'] = $exception->getMessage();
                $data['context']['exception']['file'] = $exception->getFile();
                $data['context']['exception']['line'] = $exception->getLine();
            }
            return $data;
        }
    );

    $handler = new \HomeCredit\Logger\NoEventsHandler(
        constant('\Monolog\Logger::' . $app['config']['log']['level']),
        false
    );

    $handler->setHandler($logger->getHandlers()[0]);
    $handler->setFormatter(
        new \Monolog\Formatter\LineFormatter(
            "[%datetime%] %channel%.%level_name%: %message% %context% %extra%\n"
        )
    );

    $logger->setHandlers([$handler]);

    return $logger;
});

$app['monolog.factory'] = $app->protect(function ($name) use ($app) {
    $log = new $app['monolog.logger.class']($name);
    $log->pushHandler($app['monolog.handler']);

    return $log;
});

// Create custom channels for external services.
foreach (['fd', 'paypoint', 'osb', 'transunion', 'transunion_fulfill', 'lpf'] as $channel) {

    $app['monolog.' . $channel] = function ($app) use ($channel) {
        return $app['monolog.factory']($channel);
    };

    $app['monolog.' . $channel] = function ($app) use ($channel) {
        $logger = new $app['monolog.logger.class']($channel);
        $logger->pushProcessor(
            function ($data) use ($app) {
                $data['extra']['request_id'] = $app['request.id'];
                return $data;
            }
        );

        $handler = new StreamHandler(ROOT_DIR . '/logs/' . $channel .'.log', constant('\Monolog\Logger::' . $app['config']['log']['level']));
        $logger->pushHandler($handler);

        $logger->setTimezone(new DateTimeZone($app['config']['log']['timezone']));

        return $logger;
    };
}



// Database
$app->register(
    new DoctrineServiceProvider(),
    [
        'db.options' => $app['config']['database'],
    ]
);

$app->register(new ValidatorServiceProvider());
$app->register(new BankRepositoryServiceProvider());

$app->register(new CorsServiceProvider(), [
    'cors.allowOrigin' => $app['config']['allow_origin'],
]);

if ($app['config']['profiler']['enable'] && $app['debug']) {
    $app->register(new HttpFragmentServiceProvider());
    $app->register(new ServiceControllerServiceProvider());

    $app->register(new WebProfilerServiceProvider(), [
        'profiler.cache_dir' => __DIR__.'/../cache/profiler',
        'profiler.mount_prefix' => '/api/_profiler',
    ]);
}

return $app;
