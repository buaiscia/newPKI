<?php

namespace HomeCredit\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class ChangeUsernameFormType
 * @package HomeCredit\Form\Type
 */
class ChangeUsernameFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('username', RepeatedType::class, [
                'required' => true,
                'first_options' => [
                    'label' => 'Create Username',
                    'attr' => [
                        'maxlength' => 255,
                        'minlength' => 8,
                    ],
                ],
                'second_options' => [
                    'label' => 'Retype New Username',
                    'attr' => [
                        'maxlength' => 255,
                        'minlength' => 8,
                    ],
                ],
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 8, 'max' => 255]),
                    new Assert\Regex([
                        'pattern' => '/^[a-zA-Z0-9]*$/',
                        'message' => 'Your username may only consist of letters and numbers.',
                    ]),
                ],
            ])
            ->add('password', PasswordType::class, [
                'label' => 'Current Password',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 8, 'max' => 255]),
                ],
                'attr' => [
                    'maxlength' => 255,
                    'minlength' => 8,
                ],
            ])
            ->add('submit', SubmitType::class, [
                'label' => 'Change Username',
                'attr' => [
                    'class' => 'btn-text-small',
                ]
            ]);
    }
}