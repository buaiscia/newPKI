<?php

namespace HomeCredit\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class ForgotPasswordFormType
 * @package HomeCredit\Form\Type
 */
class ForgotPasswordFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('username', TextType::class, [
                'label' => 'Username',
                'required' => true,
                'help_text' => 'Your username should be at least 8 characters and may consist of letters or numbers.',
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 8, 'max' => 255]),
                    new Assert\Regex([
                        'pattern' => '/^[a-zA-Z0-9]*$/',
                        'message' => 'Your username may only consist of letters and numbers.',
                    ]),
                ],
                'attr' => [
                    'maxlength' => 255,
                    'minlength' => 8,
                ],
            ])
            ->add('send', SubmitType::class);
    }
}