<?php

namespace HomeCredit\Security;

use DateTime;
use stdClass;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;

/**
 * Class User
 * @package HomeCredit\Security
 */
class User implements UserInterface
{
    /**
     * @var string
     */
    protected $username;

    /**
     * @var string
     */
    protected $accessToken;

    /**
     * @var string
     */
    protected $refreshToken;

    /**
     * @var string
     */
    protected $ikm;

    /**
     * @var array
     */
    protected $roles;

    /**
     * @var DateTime
     */
    protected $expiresAt;

    /**
     * @var string
     */
    protected $logoutUrl;

    /**
     * @var string
     */
    protected $cid;

    /**
     * @return mixed
     */
    public function getCid()
    {
        return $this->cid;
    }

    /**
     * @return mixed
     */
    public function setCid($cid)
    {
        $this->cid = $cid;
    }

    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        // arbitrary, unused
        return 'password';
    }

    /**
     * @return string
     */
    public function getSalt()
    {
        // arbitrary, unused
        return 'salt';
    }

    /**
     * @return mixed
     */
    public function getRoles()
    {
        return $this->roles;
    }

    /**
     * @param array $roles
     */
    public function setRoles(array $roles)
    {
        $this->roles = $roles;
    }

    /**
     * @return DateTime
     */
    public function getExpiresAt()
    {
        return $this->expiresAt;
    }

    /**
     * @param DateTime $expiresAt
     */
    public function setExpiresAt($expiresAt)
    {
        $this->expiresAt = $expiresAt;
    }

    /**
     * @return string
     */
    public function getAccessToken()
    {
        return $this->accessToken;
    }

    /**
     * @param string $accessToken
     */
    public function setAccessToken($accessToken)
    {
        $this->accessToken = $accessToken;
    }

    /**
     * @return string
     */
    public function getRefreshToken()
    {
        return $this->refreshToken;
    }

    /**
     * @param string $refreshToken
     */
    public function setRefreshToken($refreshToken)
    {
        $this->refreshToken = $refreshToken;
    }

    /**
     * @return string
     */
    public function getIkm()
    {
        return $this->ikm;
    }

    /**
     * @param string $ikm
     */
    public function setIkm($ikm)
    {
        $this->ikm = $ikm;
    }

    /**
     * @return string
     */
    public function getLogoutUrl(): ?string
    {
        return $this->logoutUrl;
    }

    /**
     * @param string $logoutUrl
     */
    public function setLogoutUrl(string $logoutUrl)
    {
        $this->logoutUrl = $logoutUrl;
    }

    /**
     * @return void
     */
    public function eraseCredentials()
    {
    }

    /**
     * @param string credentials
     */
    public static function createFromSamlResponse(array $credentials)
    {
        if (empty($credentials['access_token']) ||
            empty($credentials['refresh_token']) ||
            empty($credentials['ikm']) ||
            empty($credentials['expires_at'] ||
            empty($credentials['cid']))
        ) {
            throw new AuthenticationException('Authentication service unavailable');
        }

        $user = new static;
        $user->setUsername(end($credentials));
        $user->setAccessToken($credentials['access_token'][0]);
        $user->setRefreshToken($credentials['refresh_token'][0]);
        $user->setIkm(\base64_decode($credentials['ikm'][0]));
        $user->setExpiresAt(DateTime::createFromFormat('U', $credentials['expires_at'][0]));
        $user->setCid($credentials['customerid'][0]);

        $user->setRoles(['ROLE_CUSTOMER']);

        return $user;
    }
}
