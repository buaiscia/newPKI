<?php

namespace HomeCredit\Api\Request;

use DateTime;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException as GuzzleRequestException;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\RequestOptions;
use HomeCredit\Api\Exception\BadConnectionException;
use HomeCredit\Api\Exception\BadRequestException;
use HomeCredit\Api\Exception\NotFoundException;
use Psr\Http\Message\ResponseInterface;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;

/**
 * Class AbstractRequest
 * @package HomeCredit\Repository
 */
abstract class AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [];

    /**
     * @var array
     */
    protected $data;

    /**
     * @var Client
     */
    protected $guzzle;

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var string
     */
    protected $uri;

    /**
     * @var string
     */
    protected $version;

    /**
     * AbstractRequest constructor.
     * @param Client $guzzle
     */
    public function __construct(Client $guzzle, Session $session)
    {
        $this->guzzle = $guzzle;
        $this->data = [];
        $this->session = $session;
    }

    /**
     * @return array
     */
    public function getData(): array
    {
        return $this->data;
    }

    /**
     * @param array $data
     */
    public function setData(array $data): void
    {
        $filtered = array_filter($data, [$this, 'isAcceptedKey'], ARRAY_FILTER_USE_KEY);

        if (!empty($filtered['dob'])) { // change formatting of dob
            $dateTime = DateTime::createFromFormat('m/d/Y', $filtered['dob']);
            if ($dateTime) {
                $filtered['dob'] = $dateTime->format('Y-m-d');
            }
        }

        if (in_array('has_social', $this->acceptedKeys)) {
            if (empty($filtered['has_social'])) {
                $filtered['has_social'] = true;
            } else {
                $filtered['has_social'] = false;
            }
        }

        $this->data = $filtered;
    }

    /**
     * @param $key
     * @return bool
     */
    public function isAcceptedKey($key)
    {
        return in_array($key, $this->acceptedKeys);
    }

    /**
     * Performs a GET request
     * @param boolean $retry
     */
    public function get($retry = true, $credentials = null): ResponseInterface
    {
        try {
            return $this->guzzle->get($this->uri, [
                RequestOptions::HEADERS => $this->getHeaders($this->data, $this->uri, 'GET', $credentials),
            ]);
        } catch (GuzzleRequestException $e) {
            $this->handleRequestError($e, $retry);
        }
    }

    /**
     * @return ResponseInterface
     * @throws BadConnectionException
     * @throws BadRequestException
     * @throws NotFoundException
     */
    public function send($retry = true): ResponseInterface
    {
        try {
            return $this->guzzle->post($this->uri, [
                RequestOptions::JSON => $this->data,
                RequestOptions::HEADERS => $this->getHeaders($this->data, $this->uri),
            ]);
        } catch (GuzzleRequestException $e) {
            $this->handleRequestError($e, $retry);
        }
    }

    /**
     * Calculates the HKDF headers
     * @param array $payload
     * @param string $uri
     * @param string $method
     * @return array
     */
    private function getHeaders(array $payload = [], string $uri = null, $method = 'POST', $credentials = null)
    {
        $headers = [
            'Accept-Language' => \HomeCredit\App::get()['locale']
        ];
        
        if ($this->version !== null) {
            $headers['API-Version'] = $this->version;
        }

        $accessToken = false;
        $ikm = false;

        // If we're dealing with session date, try to grab it first
        if ($this->session->get('app.security.ikm')) {
            $accessToken = $this->session->get('app.security.access_token');
            $ikm = $this->session->get('app.security.ikm');
        }

        // If credentials were passed, try grabbing them instead
        if ($credentials !== null) {
            $accessToken = $credentials['access_token'][0];
            $ikm = \base64_decode($credentials['ikm'][0]);
        }

        // If we weren't able to determine credentials, return the current headers
        if (!$ikm || !$accessToken) {
            return $headers;
        }

        // Calculate an RFC 1123 date
        $date = (new DateTime($this->getDateStringWithDrift()))->format(DateTime::RFC1123);

        // Generate the hkdf key
        $salt = \random_bytes(32);
        $hkdf = \hash_hkdf(
            'sha256',
            $ikm,
            32,
            'HMAC|AuthenticationKey',
            $salt
        );

        $encodedSalt = \base64_encode($salt);

        // Calculate the appropriate payload
        if ($method === 'GET' and $payload === []) {
            $payload = '';
        } else {
            $payload = \json_encode($payload);
        }
        
        // Generate a signature string
        $signature = \hash('sha256', $payload) . "\n" .
            $method . "+/" . $uri . "\n" .
            $date . "\n" .
            $encodedSalt;

        // Calculate the HMAC
        $hmac = \base64_encode(
            \hash_hmac('sha256', $signature, \bin2hex($hkdf), true)
        );

        // Add the headers and submit
        $headers['Authorization'] = 'HMAC ' . $accessToken . ',' . $hmac . ',' . $encodedSalt;
        $headers['X-DATE'] = $date;

        return $headers;
    }

    /**
     * @return string
     */
    private function getDateStringWithDrift(): string
    {
        $dateString = 'now';

        if ($this->session->has('app.security.drift')) {
            $sign = '+';
            if ($this->session->get('app.security.drift') < 0) {
                $sign = '';
            }
            $dateString = $sign . ((string) $this->session->get('app.security.drift')) . ' seconds';
        }

        return $dateString;
    }



    /**
     * Handles the request error
     * @param Exception $e
     */
    private function handleRequestError(\Exception $e, $retry = false)
    {
        $response = $e->getResponse();
        if ($response instanceof Response && $response->getStatusCode() === 422) {
            // check if it's a drift issue and retry
            if ($retry) {
                if (!empty($response->getHeader('Date'))) {
                    $serverTime = DateTime::createFromFormat('D, d M Y H:i:s T', $response->getHeader('Date')[0]);
                    $currentTimeWithDrift = new DateTime($this->getDateStringWithDrift());
                    $intervalSeconds = $currentTimeWithDrift->getTimestamp() - $serverTime->getTimestamp();

                    if ($intervalSeconds > 60 || $intervalSeconds < -60) {
                        $currentTime = new DateTime('now');
                        $intervalSeconds = $currentTime->getTimestamp() - $serverTime->getTimestamp();

                        $this->session->set('app.security.drift', $intervalSeconds);

                        return $this->send(false);
                    }
                }
            }

            throw new BadCredentialsException();
        } else if ($response instanceof Response && $response->getStatusCode() === 400) {
            $body = \json_decode($response->getBody(), true);

            if (!empty($body['error']['description'])) {
                $errors = [];
                if (is_array($body['error']['description'])) {
                    foreach ($body['error']['description'] as $key => $value) {
                        $errors[str_replace(['[', ']'], '', $key)] = $value;
                    }
                } else {
                    $errors['general'] = $body['error']['description'];
                }
                throw new BadRequestException(isset($errors['general']) ? $errors['general'] : $errors);
            }
        } elseif ($response instanceof Response && $response->getStatusCode() === 404) {
            throw new NotFoundException();
        }

        throw new BadConnectionException();
    }
}