<?php

namespace HomeCredit\Api\Request;

/**
 * Class FDIEmailRequest
 * @package HomeCredit\Api\Request
 */
class FDIEmailRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'token',
        'change'
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v1/customer/emailverify';
}