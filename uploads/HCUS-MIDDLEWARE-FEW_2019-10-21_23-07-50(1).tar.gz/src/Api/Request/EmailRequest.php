<?php

namespace HomeCredit\Api\Request;

/**
 * Class EmailRequest
 * @package HomeCredit\Api\Request
 */
class EmailRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'token'
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v1/user/email_change';
}