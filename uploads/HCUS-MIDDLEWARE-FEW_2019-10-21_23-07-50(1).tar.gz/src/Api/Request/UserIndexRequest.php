<?php

namespace HomeCredit\Api\Request;

/**
 * Class UserIndexRequest
 * @package HomeCredit\Api\Request
 */
class UserIndexRequest extends AbstractRequest
{
    protected $uri = 'api/v1/user/index';
}