<?php

namespace HomeCredit\Api\Request;

/**
 * Class TriggerActivationRequest
 * @package HomeCredit\Api\Request
 */
class TriggerActivationRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'username',
        'contactMethod',
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v3/customer/trigger_activation';

    /**
     * @var string
     */
    protected $version = '20190218';
}
