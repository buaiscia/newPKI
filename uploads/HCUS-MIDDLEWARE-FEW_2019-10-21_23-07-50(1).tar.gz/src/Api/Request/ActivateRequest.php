<?php

namespace HomeCredit\Api\Request;

/**
 * Class ActivateRequest
 * @package HomeCredit\Api\Request
 */
class ActivateRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'activation_token',
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v1/customer/activate';
}