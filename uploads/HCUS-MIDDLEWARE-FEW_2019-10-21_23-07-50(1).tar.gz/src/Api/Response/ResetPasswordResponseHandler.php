<?php

namespace HomeCredit\Api\Response;

/**
 * Class ResetPasswordResponseHandler
 * @package HomeCredit\Api\Response
 */
final class ResetPasswordResponseHandler extends AbstractResponseHandler
{
}