<?php

namespace HomeCredit\Api\Response;

use Psr\Http\Message\ResponseInterface;

/**
 * Class ActivateResponseHandler
 * @package HomeCredit\Api\Response
 */
final class ActivateResponseHandler extends AbstractResponseHandler
{
}