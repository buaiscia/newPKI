<?php

namespace HomeCredit\Api\Response;

/**
 * Class ChangeEmailResponseHandler
 * @package HomeCredit\Api\Response
 */
final class ChangeEmailResponseHandler extends AbstractResponseHandler
{
}