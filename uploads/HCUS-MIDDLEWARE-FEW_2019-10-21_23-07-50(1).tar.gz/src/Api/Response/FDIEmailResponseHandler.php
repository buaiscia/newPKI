<?php

namespace HomeCredit\Api\Response;

/**
 * Class FDIEmailResponseHandler
 * @package HomeCredit\Api\Response
 */
final class FDIEmailResponseHandler extends AbstractResponseHandler
{
}