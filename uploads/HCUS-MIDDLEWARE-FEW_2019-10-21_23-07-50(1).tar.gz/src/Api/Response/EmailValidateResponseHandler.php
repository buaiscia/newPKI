<?php
namespace HomeCredit\Api\Response;

/**
 * Class EmailValidateResponseHandler
 * @package HomeCredit\Api\Response
 */
final class EmailValidateResponseHandler extends AbstractResponseHandler
{
}
