<?php

namespace HomeCredit\Api\Response;

use Psr\Http\Message\ResponseInterface;

/**
 * Class DeviceResponseHandler
 * @package HomeCredit\Api\Response
 */
final class DeviceResponseHandler extends AbstractResponseHandler
{
}