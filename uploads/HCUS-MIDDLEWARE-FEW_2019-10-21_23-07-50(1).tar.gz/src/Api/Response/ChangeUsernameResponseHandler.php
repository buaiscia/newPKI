<?php

namespace HomeCredit\Api\Response;

/**
 * Class ChangeUsernameResponseHandler
 * @package HomeCredit\Api\Response
 */
final class ChangeUsernameResponseHandler extends AbstractResponseHandler
{
}