<?php

namespace HomeCredit;

/**
 * Helper method to get an instance of the Silex\Application
 * This class exists so that instances of $app don't need to be passed around, and can instead be loaded.
 * This class is should only be used by models
 * @class App
 */
final class App
{
    /**
     * static::get
     * @return \Silex\Application
     */
    public static function get()
    {
        global $app;
        if (get_class($app) !== 'Silex\Application') {
            $app = require __DIR__ . '/../config/app.php';
        }
        
        return $app;
    }
}