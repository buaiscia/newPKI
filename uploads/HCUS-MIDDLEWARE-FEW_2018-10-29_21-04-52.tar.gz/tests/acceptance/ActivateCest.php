<?php

namespace tests\acceptance;

use AcceptanceTester;

class ActivateCest
{
    public function activateTest(\AcceptanceTester $I)
    {
        $I->amOnPage('/en/activate');
        $I->fillField('#activate_form_welcomecode', '4700121000031020');
        $I->click('button[type=submit]');
    }
}