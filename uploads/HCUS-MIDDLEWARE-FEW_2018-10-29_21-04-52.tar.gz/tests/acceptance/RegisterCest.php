<?php

namespace tests\acceptance;

use AcceptanceTester;

class RegisterCest
{
    public function registerTest(\AcceptanceTester $I)
    {
        $I->amOnPage('/en/register');
        $I->fillField('#register_form_email', 'adriel.oliveira@example.org');
        $I->fillField('#register_form_username', 'adrieloliveira');
        $I->fillField('#register_form_password_first', 'C0mp1eXP@ssw0rd');
        $I->fillField('#register_form_password_second', 'C0mp1eXP@ssw0rd');
        $I->fillField('#register_form_welcomecode', '4700121000031020');
        $I->fillField('#register_form_social', '7560');
        $I->dontSeeCheckboxIsChecked('#register_form_accept_terms');
        $I->checkOption('#register_form_accept_terms');
        $I->seeCheckboxIsChecked('#register_form_accept_terms');
        $I->click('button[type=submit]');
        $I->wait(2);
        $I->seeCurrentUrlEquals('/?registered=1');
    }
}