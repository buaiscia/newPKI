let webpack = require('webpack'),
    config = require('./config');
    
config.module.rules.push({
    test: /\.scss$/,
    use: [
        {loader: 'style-loader'},
        {loader: 'css-loader'},
        {loader: 'postcss-loader'},
        {loader: 'sass-loader'}
    ]
});

config.plugins.push(
    new webpack.NamedModulesPlugin(),
    new webpack.HotModuleReplacementPlugin(),
    new webpack.DefinePlugin({
        'APPLICATION_ENV' : '"local"',
        'process.env.NODE_ENV': '"dev"'
    })
);

module.exports = Object.assign(config, {
    devtool: 'source-map',
    devServer: {
        hot: true,
        disableHostCheck: true,
        watchOptions: {
            aggregateTimeout: 300,
            poll: 1000
        }
    }
});
