<?php

use HomeCredit\Provider\ControllerProvider;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Silex\Application;

$app = require __DIR__ . '/bootstrap.php';

// Routes
$app->mount('/', new ControllerProvider());

// Error handler
$app->error(function (Exception $e, Request $request, $code) use ($app) {
    if ($app['debug']) {
        return;
    }

    if ($e instanceof NotFoundHttpException) { // 404
        $template = 'pages/404.html.twig';
    } else { // 500
        $template = 'pages/500.html.twig';
    }

    return $app['twig']->render($template, [
        'code' => $code,
    ]);
});

$app->before(function (Request $request, Application $app) {
    $app['locale'] = 'en'; //$request->getLocale();
    $app['translator']->setLocale('en');
});

$app->after(function (Request $request, Response $response, Application $app) {
    $response->headers->set('Pragma', 'no-cache');
    $response->headers->set('Cache-Control', 'no-cache, private');
});

return $app;