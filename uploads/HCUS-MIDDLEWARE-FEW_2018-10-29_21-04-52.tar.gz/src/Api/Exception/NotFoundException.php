<?php

namespace HomeCredit\Api\Exception;

use Exception;

/**
 * Class NotFoundException
 * @package HomeCredit\Api\Exception
 */
class NotFoundException extends Exception
{
}