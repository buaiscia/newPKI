<?php

namespace HomeCredit\Api\Exception;

use Exception;

/**
 * Class BadRequestException
 * @package HomeCredit\Api\Exception
 */
class BadRequestException extends Exception
{
    /**
     * @var array $errors
     */
    private $errors = [];

    /**
     * Overloaded constructor
     * @param mixed $message
     */
    public function __construct($message)
    {
        if (!\is_array($message)) {
            parent::__construct($message);
        } else {
            $this->errors = $message;
        }
    }

    /**
     * Returns an array of errors
     */
    public function getErrors()
    {
        return $this->errors;
    }
}