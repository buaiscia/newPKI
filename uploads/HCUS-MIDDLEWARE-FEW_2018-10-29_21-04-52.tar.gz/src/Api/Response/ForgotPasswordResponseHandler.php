<?php

namespace HomeCredit\Api\Response;

/**
 * Class ForgotPasswordResponseHandler
 * @package HomeCredit\Api\Response
 */
final class ForgotPasswordResponseHandler extends AbstractResponseHandler
{
}