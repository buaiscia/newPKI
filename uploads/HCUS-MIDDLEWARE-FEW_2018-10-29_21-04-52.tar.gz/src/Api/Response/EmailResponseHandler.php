<?php

namespace HomeCredit\Api\Response;

/**
 * Class EmailResponseHandler
 * @package HomeCredit\Api\Response
 */
final class EmailResponseHandler extends AbstractResponseHandler
{
}