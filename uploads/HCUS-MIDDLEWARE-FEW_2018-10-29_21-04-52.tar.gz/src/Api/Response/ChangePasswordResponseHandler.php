<?php

namespace HomeCredit\Api\Response;

/**
 * Class ChangePasswordResponseHanlder
 * @package HomeCredit\Api\Response
 */
final class ChangePasswordResponseHandler extends AbstractResponseHandler
{
}