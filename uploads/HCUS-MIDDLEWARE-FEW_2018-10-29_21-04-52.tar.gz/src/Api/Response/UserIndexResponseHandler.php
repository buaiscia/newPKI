<?php

namespace HomeCredit\Api\Response;

use Psr\Http\Message\ResponseInterface;

/**
 * Class UserIndexResponseHandler
 * @package HomeCredit\Api\Response
 */
final class UserIndexResponseHandler extends AbstractResponseHandler
{
}