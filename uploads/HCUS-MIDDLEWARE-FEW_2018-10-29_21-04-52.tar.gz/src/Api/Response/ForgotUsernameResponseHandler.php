<?php

namespace HomeCredit\Api\Response;

use Psr\Http\Message\ResponseInterface;

/**
 * Class ForgotUsernameResponseHandler
 * @package HomeCredit\Api\Response
 */
final class ForgotUsernameResponseHandler extends AbstractResponseHandler
{
}