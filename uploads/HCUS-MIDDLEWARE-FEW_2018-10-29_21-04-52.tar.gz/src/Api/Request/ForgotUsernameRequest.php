<?php

namespace HomeCredit\Api\Request;

class ForgotUsernameRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'social',
        'welcomecode'
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v1/user/forgotlogin';
    
    /**
     * @var string
     */
    protected $version = '20170711';
}