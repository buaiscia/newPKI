<?php

namespace HomeCredit\Api\Request;

/**
 * Class ForgotPasswordRequest
 * @package HomeCredit\Api\Request
 */
class ForgotPasswordRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'username',
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v1/user/resetpassword';
}