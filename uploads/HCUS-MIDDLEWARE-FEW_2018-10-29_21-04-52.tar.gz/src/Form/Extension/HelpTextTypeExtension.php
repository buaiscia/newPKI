<?php

namespace HomeCredit\Form\Extension;

use Symfony\Component\Form\AbstractTypeExtension;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\PropertyAccess\PropertyAccess;

/**
 * Class HelpTextTypeExtension
 * @package HomeCredit\Form\Extension
 */
class HelpTextTypeExtension extends AbstractTypeExtension
{
    /**
     * @return string
     */
    public function getExtendedType(): string
    {
        return TextType::class;
    }

    /**
     * Add the image_path option
     *
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefined(['help_text']);
        $resolver->setDefined(['help_title']);
        $resolver->setDefined(['help_button_text']);
    }

    /**
     * @param FormView $view
     * @param FormInterface $form
     * @param array $options
     */
    public function buildView(FormView $view, FormInterface $form, array $options): void
    {
        if (isset($options['help_text'])) {
            $view->vars['help_text'] = $options['help_text'];
        }
        if (isset($options['help_title'])) {
            $view->vars['help_title'] = $options['help_title'];
        }
        if (isset($options['help_button_text'])) {
            $view->vars['help_button_text'] = $options['help_button_text'];
        }
    }
}