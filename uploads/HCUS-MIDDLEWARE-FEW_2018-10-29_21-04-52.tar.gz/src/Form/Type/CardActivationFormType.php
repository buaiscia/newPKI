<?php

namespace HomeCredit\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class CardActivationFormType
 * @package HomeCredit\Form\Type
 */
class CardActivationFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('social', PasswordType::class, [
                'label' => 'SSN (Last Four)',
                'required' => true,
                'constraints' => [
                    new Assert\Regex([
                        'pattern' => '/^\d{4}$/',
                        'message' => 'Please enter the last four digits of your Social Security Number.',
                    ]),
                ],
                'help_text' => 'We use your social security number to identify you and keep your account safe. We never store it.',
                'help_title' => 'Why do you need my SSN?',
                'help_button_text' => 'Got It',
                'attr' => [
                    'maxlength' => 4,
                    'minlength' => 4,
                    'pattern' => '^\d{4}$',
                    'title' => 'Please enter the last four digits of your Social Security Number.',
                ]
            ])
            ->add('cardnumber', PasswordType::class, [
                'label' => 'Account Number',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\CardScheme([
                        'schemes' => ['VISA'],
                        'message' => 'Invalid account number. Please enter the number provided in your welcome packet.',
                    ]),
                ],
            ])
            ->add('cvv', TextType::class, [
                'label' => 'CVV',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Regex([
                        'pattern' => '/^\d{3}$/',
                        'message' => 'Please enter the CVV number from the back of your card.',
                    ])
                ]
            ])
            ->add('expiration', TextType::class, [
                'label' => 'Expiration Date',
                'attr' => [
                    'placeholder' => 'MM/YY'
                ],
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Regex([
                        'pattern' =>  '/^\d{2}\/\d{2}$/',
                        'message' => 'Please enter your expiration date in the following format: MM/YY'
                    ])
                ]
            ])
            ->add('confirm', SubmitType::class);
    }
}