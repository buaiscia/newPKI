<?php

namespace HomeCredit\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

/**
 * Class ResetPasswordFormType
 * @package HomeCredit\Form\Type
 */
class ResetPasswordFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('reset_token', HiddenType::class)
            ->add('password', RepeatedType::class, [
                'type' => PasswordType::class,
                'invalid_message' => 'The password fields must match.',
                'required' => true,
                'first_options' => [
                    'label' => 'Create Password',
                    'attr' => [
                        'maxlength' => 255,
                        'minlength' => 8,
                    ],
                ],
                'second_options' => [
                    'label' => 'Retype Password',
                    'attr' => [
                        'maxlength' => 255,
                        'minlength' => 8,
                    ],
                ],
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 8, 'max' => 255]),
                    new Assert\Callback(function ($object, ExecutionContextInterface $context, $payload) {
                        $addViolation = false;
                        $regex = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*(\d|(_|[^\w]))).+$/';
                        if (!preg_match($regex, $object)) {
                            $addViolation = true;
                        }

                        if ($addViolation) {
                            $context->buildViolation('Your password must contain a combination of upper and lower case letters, and at least one number.')
                                ->addViolation();
                        }
                    }),
                ],
            ])
            ->add('save', SubmitType::class);
    }
}