<?php

namespace HomeCredit\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

/**
 * Class ChangePasswordFormType
 * @package HomeCredit\Form\Type
 */
class ChangePasswordFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('password', PasswordType::class, [
                'label' => 'Current Password',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 8, 'max' => 255]),
                ],
                'attr' => [
                    'maxlength' => 255,
                    'minlength' => 8,
                ],
            ])
            ->add('new_password', RepeatedType::class, [
                'type' => PasswordType::class,
                'first_options' => [
                    'label' => 'Create Password',
                    'attr' => [
                        'maxlength' => 255,
                        'minlength' => 8,
                        'class' => 'pw-strength',
                        'pattern' => '^(?=.*[a-z])(?=.*[A-Z])(?=.*(\d|(_|[^\w]))).+$',
                    ],
                ],
                'second_options' => [
                    'label' => 'Retype Password',
                    'attr' => [
                        'maxlength' => 255,
                        'minlength' => 8,
                    ],
                ],
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 8, 'max' => 255]),
                    new Assert\Callback(function ($object, ExecutionContextInterface $context, $payload) {
                        $addViolation = false;
                        $regex = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*(\d|(_|[^\w]))).+$/';
                        if (!preg_match($regex, $object)) {
                            $addViolation = true;
                        }

                        if ($addViolation) {
                            $context->buildViolation('Your password must contain a combination of upper and lower case letters, and at least one number.')
                                ->addViolation();
                        }
                    }),
                ],
            ])
            ->add('submit', SubmitType::class, [
                'label' => 'Change Password',
                'attr' => [
                    'class' => 'btn-text-small',
                ]
            ]);
    }
}