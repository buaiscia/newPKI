<?php

namespace HomeCredit\Controller;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class AndroidManifestController
 * @package HomeCredit\Controller
 */
final class AndroidManifestController
{
    /**
     * Returns the /apple-app-site-association file for deep links
     * @param Application $app
     * @param Request $request
     * @return JsonResponse
     */
    public function index(Application $app, Request $request)
    {
        return JsonResponse::create([
            'short_name' => $app['config']['android-manifest']['short_name'],
            'name' => $app['config']['android-manifest']['name'],
            'icons' => [
                [
                    'src' => 'dist/img/favicons/v1-apple-icon-114x114.png',
                    'type' => 'img/png',
                    'size' => '144x144'
                ]
            ],
            'related_applications' => [
                [
                    'platform' => 'play',
                    'id' => ('com.homecredit' . ($app['config']['android-manifest']['appID'] !== null ? '.' . $app['config']['android-manifest']['appID'] : null))
                ]
            ]
        ]);
    }
}