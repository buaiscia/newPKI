<?php

namespace HomeCredit\Controller;

use Exception;
use HomeCredit\Api\Exception\BadConnectionException;
use HomeCredit\Api\Exception\BadRequestException;
use HomeCredit\Api\Exception\NotFoundException;
use HomeCredit\Api\Request\AbstractRequest;
use HomeCredit\Api\Response\AbstractResponseHandler;
use Symfony\Component\Form\Exception\OutOfBoundsException;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\Request;
use Twig_Environment;

/**
 * Class LoginHelpController
 * @package HomeCredit\Controller
 */
final class LoginHelpController
{
    /**
     * @var Form
     */
    private $passwordForm;

    /**
     * @var AbstractResponseHandler
     */
    private $passwordResponseHandler;

    /**
     * @var AbstractRequest
     */
    private $passwordRequest;

    /**
     * @var Twig_Environment
     */
    private $twig;

    /**
     * @var Form
     */
    private $usernameForm;

    /**
     * @var AbstractRequest
     */
    private $usernameRequest;

    /**
     * @var AbstractResponseHandler
     */
    private $usernameResponseHandler;

    /**
     * LoginHelpController constructor.
     * @param Form $passwordForm
     * @param AbstractResponseHandler $passwordResponseHandler
     * @param AbstractRequest $passwordRequest
     * @param Twig_Environment $twig
     * @param Form $usernameForm
     * @param AbstractRequest $usernameRequest
     * @param AbstractResponseHandler $usernameResponseHandler
     */
    public function __construct(
        Form $passwordForm,
        AbstractRequest $passwordRequest,
        AbstractResponseHandler $passwordResponseHandler,
        Twig_Environment $twig,
        Form $usernameForm,
        AbstractRequest $usernameRequest,
        AbstractResponseHandler $usernameResponseHandler
    ) {
        $this->passwordForm = $passwordForm;
        $this->twig = $twig;
        $this->usernameForm = $usernameForm;
        $this->usernameRequest = $usernameRequest;
        $this->usernameResponseHandler = $usernameResponseHandler;
        $this->passwordResponseHandler = $passwordResponseHandler;
        $this->passwordRequest = $passwordRequest;
    }

    /**
     * @param Request $request
     * @return string
     */
    public function help(Request $request)
    {
        $viewData = [];

        $freshPasswordForm = clone $this->passwordForm;

        $this->passwordForm->handleRequest($request);
        if ($this->passwordForm->isValid()) {
            $this->passwordRequest->setData($this->passwordForm->getData());

            try {
                $this->passwordResponseHandler->handle(
                    $this->passwordRequest->send()
                );

                if ($this->passwordResponseHandler->isOk()) {
                    $this->passwordForm = $freshPasswordForm;

                    $viewData['modal_visible'] = true;
                    $viewData['modal_title'] = 'Check Your Email';
                    $viewData['modal_text'] = 'Look for an email from My Home Credit with next steps.';
                }
            } catch (NotFoundException $e) {
                $viewData['modal_visible'] = true;
                $viewData['modal_title'] = 'Check Your Email';
                $viewData['modal_text'] = 'Look for an email from My Home Credit with next steps.';
            } catch (BadConnectionException $e) {
                $viewData['modal_visible'] = true;
                $viewData['modal_title'] = 'Connection Error';
                $viewData['modal_text'] = 'We are unable to process your request at this time.';
            }
        }

        $freshUsernameForm = clone $this->usernameForm;

        $this->usernameForm->handleRequest($request);
        if ($this->usernameForm->isValid()) {
            $this->usernameRequest->setData($this->usernameForm->getData());

            try {
                $this->usernameResponseHandler->handle(
                    $this->usernameRequest->send()
                );

                if ($this->usernameResponseHandler->isOk()) {
                    // clear submission
                    $this->usernameForm = $freshUsernameForm;

                    $viewData['modal_visible'] = true;
                    $viewData['modal_title'] = 'Check Your Email';
                    $viewData['modal_text'] = 'Look for an email from My Home Credit with your forgotten username.';
                }
            } catch (BadRequestException $e) {
                foreach ($e->getErrors() as $key => $value) {
                    try {
                        $this->usernameForm->get($key)->addError(new FormError($value));
                    } catch (OutOfBoundsException $e) {
                        $this->usernameForm->addError(new FormError($value));
                    }
                }
            } catch (BadConnectionException $e) {
                $viewData['modal_visible'] = true;
                $viewData['modal_title'] = 'Connection Error';
                $viewData['modal_text'] = 'We are unable to process your request at this time.';
            }
        }

        $viewData['password_form'] = $this->passwordForm->createView();
        $viewData['username_form'] = $this->usernameForm->createView();

        return $this->twig->render('pages/login-help.html.twig', $viewData);
    }
}