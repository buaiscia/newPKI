<?php

namespace HomeCredit\Controller;

use HomeCredit\Api\Exception\BadConnectionException;
use HomeCredit\Api\Exception\BadRequestException;
use HomeCredit\Api\Request\AbstractRequest;
use HomeCredit\Api\Response\AbstractResponseHandler;
use Symfony\Component\Form\Exception\OutOfBoundsException;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\Request;
use Twig_Environment;

/**
 * Class CardActivationController
 * @package HomeCredit\Controller
 */
final class CardActivationController
{
    /**
     * @var Twig_Environment
     */
    private $twig;

    /**
     * @var Form
     */
    private $form;

    /**
     * @var AbstractRequest
     */
    private $request;

    /**
     * @var AbstractResponseHandler
     */
    private $responseHandler;

    /**
     * CardActivationController constructor.
     * @param Form $form
     * @param AbstractRequest $request
     * @param AbstractResponseHandler $responseHandler
     * @param Twig_Environment $twig
     */
    public function __construct(
        Form $form,
        AbstractRequest $request,
        AbstractResponseHandler $responseHandler,
        Twig_Environment $twig
    ) {
        $this->form = $form;
        $this->twig = $twig;
        $this->request = $request;
        $this->responseHandler = $responseHandler;
    }

    /**
     * @return string
     */
    public function activate(Request $request)
    {
        $viewData = [];

        $freshForm = clone $this->form;

        $this->form->handleRequest($request);

        if ($this->form->isValid()) {
            $this->request->setData($this->form->getData());

            try {
                $this->responseHandler->handle(
                    $this->request->send()
                );

                if ($this->responseHandler->isOk()) {
                    $this->form = $freshForm;

                    $viewData['success'] = true;
                    $viewData['modal_visible'] = true;
                    $viewData['modal_title'] = 'Success';
                    $viewData['modal_text'] = 'Your card has been activated.';
                }

            } catch (BadRequestException $e) {
                $viewData['form_errors'] = json_encode($e->getErrors());
                foreach ($e->getErrors() as $key => $value) {
                    try {
                        $this->form->get($key)->addError(new FormError($value));
                    } catch (OutOfBoundsException $e) {
                        $this->form->addError(new FormError($value));
                    }
                }
            } catch (BadConnectionException $e) {
                $viewData['modal_visible'] = true;
                $viewData['modal_title'] = 'Connection Error';
                $viewData['modal_text'] = 'We are unable to process your request at this time.';
            }
        } else if ($this->form->isSubmitted()) {
            $viewData['form_errors'] = json_encode($this->getFormErrors($this->form));
        }

        $viewData['form'] = $this->form->createView();

        return $this->twig->render('pages/card-activation.html.twig', $viewData);
    }

    /**
     * List all errors of a given bound form.
     *
     * @param Form $form
     * @return array
     */
    protected function getFormErrors(Form $form)
    {
        $errors = array();

        // Global
        foreach ($form->getErrors() as $error) {
            $errors[$form->getName()][] = $error->getMessage();
        }

        // Fields
        foreach ($form as $child /** @var Form $child */) {
            if (!$child->isValid()) {
                foreach ($child->getErrors() as $error) {
                    $errors[$child->getName()][] = $error->getMessage();
                }
            }
        }

        return $errors;
    }
}