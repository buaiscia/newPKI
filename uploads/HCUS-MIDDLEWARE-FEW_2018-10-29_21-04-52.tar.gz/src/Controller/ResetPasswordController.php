<?php

namespace HomeCredit\Controller;

use Closure;
use HomeCredit\Api\Exception\BadConnectionException;
use HomeCredit\Api\Exception\BadRequestException;
use HomeCredit\Api\Request\AbstractRequest;
use HomeCredit\Api\Response\AbstractResponseHandler;
use Symfony\Component\Form\Exception\OutOfBoundsException;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\Request;
use Twig_Environment;

/**
 * Class ResetPasswordController
 * @package HomeCredit\Controller
 */
final class ResetPasswordController
{
    /**
     * @var Form
     */
    private $form;

    /**
     * @var Closure
     */
    private $loginUrl;

    /**
     * @var AbstractRequest
     */
    private $request;

    /**
     * @var AbstractResponseHandler
     */
    private $responseHandler;

    /**
     * @var Twig_Environment
     */
    private $twig;

    /**
     * @var array
     */
    private $config;

    /**
     * @var string
     */
    private $locale;

    public function __construct(
        Form $form,
        Closure $loginUrl,
        array $config,
        string $locale,
        AbstractRequest $request,
        AbstractResponseHandler $responseHandler,
        Twig_Environment $twig
    ) {
        $this->form = $form;
        $this->loginUrl = $loginUrl;
        $this->request = $request;
        $this->responseHandler = $responseHandler;
        $this->twig = $twig;
        $this->config = $config;
        $this->locale = $locale;
    }

    public function reset(Request $request)
    {
        $viewData = [];
        $this->form->handleRequest($request);

        $viewData['token'] = $request->get('token');
        if (!$this->form->isSubmitted()) {
            $this->form->get('reset_token')->setData($viewData['token']);
        } elseif ($this->form->isValid()) {
            $this->request->setData($this->form->getData());

            try {
                $this->responseHandler->handle(
                    $this->request->send()
                );

                if ($this->responseHandler->isOk()) {
                    $viewData['modal_visible'] = true;
                    $viewData['modal_title'] = 'Password Changed';
                    $viewData['modal_text'] = 'You may now login with your new password';
                    $viewData['modal_options'] = [
                        [
                            'type' => 'link',
                            'url' => ($this->loginUrl)($this->config, $this->locale),
                            'text' => 'Log In',
                        ]
                    ];
                }
            } catch (BadRequestException $e) {
                foreach ($e->getErrors() as $key => $value) {
                    try {
                        $this->form->get($key)->addError(new FormError($value));
                    } catch (OutOfBoundsException $e) {
                        $this->form->addError(new FormError($value));
                    }
                }
            } catch (BadConnectionException $e) {
                $viewData['modal_visible'] = true;
                $viewData['modal_title'] = 'Connection Error';
                $viewData['modal_text'] = 'We are unable to process your request at this time.';
            }
        }

        $viewData['form'] = $this->form->createView();
        return $this->twig->render('pages/reset-password.html.twig', $viewData);
    }
}