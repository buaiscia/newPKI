<?php
namespace HomeCredit\Controller;

use Symfony\Component\HttpFoundation\Request;
use Twig_Environment;

/**
 * Class HomeController
 * @package HomeCredit\Controller
 */
final class HomeController
{
    /**
     * @var Twig_Environment
     */
    private $twig;

    /**
     * HomeController constructor.
     * @param Twig_Environment $twig
     */
    public function __construct(Twig_Environment $twig)
    {
        $this->twig = $twig;
    }

    /**
     * @return string
     */
    public function index(Request $request)
    {
        $viewData = [];

        if ($request->query->get('registered', false)) {
            $viewData['modal_visible'] = true;
            $viewData['modal_title'] = 'Success';
            $viewData['modal_text'] = 'Please check your email for next steps.';
        }
        
        return $this->twig->render('pages/home.html.twig', $viewData);
    }

    /**
     * Displays logged out messaging for the /loggedout route
     */
    public function loggedout()
    {
        return $this->twig->render('pages/loggedout.html.twig');
    }
}