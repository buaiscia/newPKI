<?php

namespace HomeCredit\Controller;

use HomeCredit\Api\Exception\BadConnectionException;
use HomeCredit\Api\Exception\BadRequestException;
use HomeCredit\Api\Request\AbstractRequest;
use HomeCredit\Api\Response\AbstractResponseHandler;
use Symfony\Component\Form\Exception\OutOfBoundsException;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Generator\UrlGenerator;
use Twig_Environment;

/**
 * Class ProfileController
 * @package HomeCredit\Controller
 */
final class ProfileController
{
    /**
     * @var Twig_Environment
     */
    private $twig;

    /**
     * @var Form
     */
    private $changePasswordForm;

    /**
     * @var Form
     */
    private $changeUsernameForm;

    /**
     * @var Form
     */
    private $changeEmailForm;

    /**
     * @var AbstractRequest
     */
    private $changePasswordRequest;

    /**
     * @var AbstractRequest
     */
    private $changeUsernameRequest;

    /**
     * @var AbstractRequest
     */
    private $changeEmailRequest;

    /**
     * @var AbstractResponseHandler
     */
    private $changePasswordResponseHandler;

    /**
     * @var AbstractResponseHandler
     */
    private $changeUsernameResponseHandler;

    /**
     * @var AbstractResponseHandler
     */
    private $changeEmailResponseHandler;

    /**
     * @var UrlGenerator
     */
    private $urlGenerator;

    /**
     * ProfileController constructor.
     * @param Form $changePasswordForm
     * @param Form $changeUsernameForm
     * @param Form $changeEmailForm
     * @param AbstractRequest $changePasswordRequest
     * @param AbstractRequest $changeUsernameRequest
     * @param AbstractRequest $changeEmailRequest
     * @param AbstractResponseHandler $changePasswordResponse
     * @param AbstractResponseHandler $changeUsernameResponse
     * @param AbstractResponseHandler $changeEmailResponse
     * @param Twig_Environment $twig
     */
    public function __construct(
        Form $changePasswordForm,
        Form $changeUsernameForm,
        Form $changeEmailForm,
        AbstractRequest $changePasswordRequest,
        AbstractRequest $changeUsernameRequest,
        AbstractRequest $changeEmailRequest,
        AbstractResponseHandler $changePasswordResponse,
        AbstractResponseHandler $changeUsernameResponse,
        AbstractResponseHandler $changeEmailResponse,
        Twig_Environment $twig,
        UrlGenerator $urlGenerator
    ) {
        $this->changePasswordForm = $changePasswordForm;
        $this->changeUsernameForm = $changeUsernameForm;
        $this->changeEmailForm = $changeEmailForm;

        $this->changePasswordRequest = $changePasswordRequest;
        $this->changeUsernameRequest = $changeUsernameRequest;
        $this->changeEmailRequest = $changeEmailRequest;

        $this->changePasswordResponseHandler = $changePasswordResponse;
        $this->changeUsernameResponseHandler = $changeUsernameResponse;
        $this->changeEmailResponseHandler = $changeEmailResponse;

        $this->twig = $twig;
        $this->urlGenerator = $urlGenerator;
    }

    public function profile(Request $request)
    {
        $viewData = [];

        $viewData = $this->processForm(
            $viewData,
            $request,
            $this->changePasswordForm,
            $this->changePasswordRequest,
            $this->changePasswordResponseHandler,
            [
                'modal_title' => 'Success',
                'modal_text' => 'You will now be logged out. Please log in with your new password to make further changes.',
                'modal_options' => [
                    [
                        'type' => 'link',
                        'url' => $this->urlGenerator->generate('logout'),
                        'text' => 'Log Out'
                    ]
                ]
            ]
        );
        $viewData = $this->processForm(
            $viewData,
            $request,
            $this->changeUsernameForm,
            $this->changeUsernameRequest,
            $this->changeUsernameResponseHandler,
            [
                'modal_title' => 'Username Changed',
                'modal_text' => 'You will now be logged out. Please log in with your new username to make further changes.',
                'modal_options' => [
                    [
                        'type' => 'link',
                        'url' => $this->urlGenerator->generate('logout'),
                        'text' => 'Log Out'
                    ]
                ]
            ]
        );
        $viewData = $this->processForm(
            $viewData,
            $request,
            $this->changeEmailForm,
            $this->changeEmailRequest,
            $this->changeEmailResponseHandler,
            [
                'modal_title' => 'Email Change Pending',
                'modal_text' => 'Please check your email to complete the process.',
            ]
        );

        $viewData += [
            'change_email_form' => $this->changeEmailForm->createView(),
            'change_password_form' => $this->changePasswordForm->createView(),
            'change_username_form' => $this->changeUsernameForm->createView(),
        ];

        return $this->twig->render('pages/profile.html.twig', $viewData);
    }

    /**
     * @param array $viewData
     * @param Request $request
     * @param Form $form
     * @param AbstractRequest $apiRequest
     * @param AbstractResponseHandler $responseHandler
     * @param array $modalOptions
     * @return mixed
     */
    private function processForm(
        array $viewData,
        Request $request,
        Form $form,
        AbstractRequest $apiRequest,
        AbstractResponseHandler $responseHandler,
        array $modalOptions
    ) {
        $form->handleRequest($request);
        if ($form->isValid()) {
            $apiRequest->setData($form->getData());

            try {
                $responseHandler->handle(
                    $apiRequest->send()
                );

                if ($responseHandler->isOk()) {
                    $viewData['modal_visible'] = true;
                    $viewData += $modalOptions;
                }
            } catch (BadRequestException $e) {
                foreach ($e->getErrors() as $key => $value) {
                    try {
                        $form->get($key)->addError(new FormError($value));
                    } catch (OutOfBoundsException $e) {
                        $form->addError(new FormError($value));
                    }
                }
            } catch (BadConnectionException $e) {
                $viewData['modal_visible'] = true;
                $viewData['modal_title'] = 'Connection Error';
                $viewData['modal_text'] = 'We are unable to process your request at this time.';
            }
        }

        return $viewData;
    }
}