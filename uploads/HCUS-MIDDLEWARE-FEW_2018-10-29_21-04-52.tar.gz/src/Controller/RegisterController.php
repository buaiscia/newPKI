<?php

namespace HomeCredit\Controller;

use HomeCredit\Api\Exception\BadConnectionException;
use HomeCredit\Api\Exception\BadRequestException;
use HomeCredit\Api\Request\AbstractRequest;
use HomeCredit\Api\Response\AbstractResponseHandler;
use Symfony\Component\Form\Exception\OutOfBoundsException;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Twig_Environment;
use Symfony\Component\Routing\Generator\UrlGenerator;

/**
 * Class RegisterController
 * @package HomeCredit\Controller
 */
final class RegisterController
{
    /**
     * @var Form
     */
    private $form;

    /**
     * @var AbstractRequest
     */
    private $request;

    /**
     * @var AbstractResponseHandler
     */
    private $responseHandler;

    /**
     * @var Twig_Environment
     */
    private $twig;

    /**
     * @var UrlGenerator
     */
    private $urlGenerator;

    /**
     * @var string
     */
    private $locale;

    /**
     * RegisterController constructor.
     * @param Form $form
     * @param string $locale
     * @param AbstractRequest $request
     * @param AbstractResponseHandler $responseHandler
     * @param Twig_Environment $twig
     * @param UrlGenerator $urlGenerator
     */
    public function __construct(
        Form $form,
        string $locale,
        AbstractRequest $request,
        AbstractResponseHandler $responseHandler,
        Twig_Environment $twig,
        UrlGenerator $urlGenerator
    ) {
        error_reporting(-1);
        ini_set('display_errors', 'true');
        $this->form = $form;
        $this->request = $request;
        $this->responseHandler = $responseHandler;
        $this->twig = $twig;
        $this->urlGenerator = $urlGenerator;
        $this->locale = $locale;
    }

    /**
     * @param Request $request
     * @return string
     */
    public function register(Request $request)
    {
        $viewData = [];
        $viewData['form_errors'] = null;
        $this->form->handleRequest($request);

        if ($this->form->isValid()) {
            $this->request->setData($this->form->getData());

            try {
                $this->responseHandler->handle(
                    $this->request->send()
                );

                if ($this->responseHandler->isOk()) {
                    return new RedirectResponse(
                        $this->urlGenerator->generate('home', [
                            'registered' => '1'
                        ])
                    );
                }
            } catch (BadRequestException $e) {
                $viewData['form_errors'] = json_encode($e->getErrors());
                foreach ($e->getErrors() as $key => $value) {
                    try {
                        $this->form->get($key)->addError(new FormError($value));
                    } catch (OutOfBoundsException $e ) {
                        $this->form->addError(new FormError($value));
                    }
                }
            } catch (BadConnectionException $e) {
                $viewData['modal_visible'] = true;
                $viewData['modal_title'] = 'Connection Error';
                $viewData['modal_text'] = 'We are unable to process your request at this time.';
            }
        } else if ($this->form->isSubmitted()) {
            $viewData['form_errors'] = json_encode($this->getFormErrors($this->form));
        }

        $viewData['register_form'] = $this->form->createView();

        return $this->twig->render('pages/register.html.twig', $viewData);
    }

    /**
     * List all errors of a given bound form.
     *
     * @param Form $form
     * @return array
     */
    protected function getFormErrors(Form $form)
    {
        $errors = array();

        // Global
        foreach ($form->getErrors() as $error) {
            $errors[$form->getName()][] = $error->getMessage();
        }

        // Fields
        foreach ($form as $child /** @var Form $child */) {
            if (!$child->isValid()) {
                foreach ($child->getErrors() as $error) {
                    $errors[$child->getName()][] = $error->getMessage();
                }
            }
        }

        return $errors;
    }
}
