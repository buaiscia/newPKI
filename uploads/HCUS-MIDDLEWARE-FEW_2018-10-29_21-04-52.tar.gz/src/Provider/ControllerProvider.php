<?php

namespace HomeCredit\Provider;

use HomeCredit\Controller\ActivateController;
use HomeCredit\Controller\AndroidManifestController;
use HomeCredit\Controller\AppleAppSiteAssociationController;
use HomeCredit\Controller\CardActivationController;
use HomeCredit\Controller\DeviceController;
use HomeCredit\Controller\EmailController;
use HomeCredit\Controller\FDIEmailController;
use HomeCredit\Controller\HomeController;
use HomeCredit\Controller\LoginHelpController;
use HomeCredit\Controller\ProfileController;
use HomeCredit\Controller\RegisterController;
use HomeCredit\Controller\ResetPasswordController;
use HomeCredit\Controller\SamlController;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;

use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Class ControllerProvider
 * @package HomeCredit\Provider\Controller
 */
class ControllerProvider implements ControllerProviderInterface
{
    /**
     * @param Application $app
     * @return ControllerCollection
     */
    public function connect(Application $app)
    {
        $app['app.controllers.home'] = function (Application $app) {
            return new HomeController($app['twig']);
        };

        $app['app.controllers.profile'] = function (Application $app) {
            return new ProfileController(
                $app['app.form.change_password'],
                $app['app.form.change_username'],
                $app['app.form.change_email'],
                $app['api.request.change_password'],
                $app['api.request.change_username'],
                $app['api.request.change_email'],
                $app['api.response_handler.change_password'],
                $app['api.response_handler.change_username'],
                $app['api.response_handler.change_email'],
                $app['twig'],
                $app['url_generator']
            );
        };

        $app['app.controllers.login_help'] = function (Application $app) {
            return new LoginHelpController(
                $app['app.form.forgot_password'],
                $app['api.request.forgot_password'],
                $app['api.response_handler.forgot_password'],
                $app['twig'],
                $app['app.form.forgot_username'],
                $app['api.request.forgot_username'],
                $app['api.response_handler.forgot_username']
            );
        };

        $app['app.controllers.register'] = function (Application $app) {
            return new RegisterController(
                $app['app.form.register'],
                $app['locale'],
                $app['api.request.registration'],
                $app['api.response_handler.registration'],
                $app['twig'],
                $app['url_generator']
            );
        };

        $app['app.controllers.activate'] = function (Application $app) {
            return new ActivateController(
                $app['api.request.activate'],
                $app['api.response_handler.activate'],
                $app['twig'],
                $app['validator']
            );
        };

        $app['app.controllers.card_activation'] = function (Application $app) {
            return new CardActivationController(
                $app['app.form.card_activation'],
                $app['api.request.card_activation'],
                $app['api.response_handler.card_activation'],
                $app['twig']
            );
        };

        $app['app.controllers.reset_password'] = function (Application $app) {
            return new ResetPasswordController(
                $app['app.form.reset_password'],
                $app['saml_login'],
                $app['config'],
                $app['locale'],
                $app['api.request.reset_password'],
                $app['api.response_handler.reset_password'],
                $app['twig']
            );
        };

        $app['app.controllers.email'] = function (Application $app) {
            return new EmailController(
                $app['api.request.email'],
                $app['api.response_handler.email'],
                $app['twig'],
                $app['validator']
            );
        };

        $app['app.controllers.device'] = function (Application $app) {
            return new DeviceController(
                $app['api.request.device'],
                $app['api.response_handler.device'],
                $app['twig'],
                $app['validator']
            );
        };

        $app['app.controllers.saml'] = function (Application $app) {
            return new SamlController($app['url_generator']);
        };

        $app['app.controllers.apsa'] = function (Application $app) {
            return new AppleAppSiteAssociationController();
        };
        $app['app.controllers.androidmanifest'] = function (Application $app) {
            return new AndroidManifestController();
        };

        $app['app.controllers.fdiemail'] = function (Application $app) {
            return new FDIEmailController(
                $app['api.request.fdiemail'],
                $app['api.response_handler.fdiemail'],
                $app['twig'],
                $app['validator']
            );
        };

        // ROUTES
        $controllers = $app['controllers_factory'];

        $controllers->get('/apple-app-site-association', 'app.controllers.apsa:index')
            ->method('GET')
            ->bind('apple-app-site-association');

        $controllers->get('/manifest.json', 'app.controllers.androidmanifest:index')
            ->method('GET')
            ->bind('android-manifest-json');

        $controllers->get('/info/index', function () {
            if (file_exists(ROOT . 'VERSION')) {
                $version = \json_decode(\file_get_contents(ROOT . 'VERSION'), true);
                return JsonResponse::create([
                    'data' => $version
                ]);
            }
        });

        $controllers->get('/{_locale}', 'app.controllers.home:index')
            ->bind('home')
            ->value('_locale', 'en');

        $controllers->match('/{_locale}/card-activation', 'app.controllers.card_activation:activate')
            ->method('GET|POST')
            ->bind('card_activation');

        $controllers->match('/{_locale}/login-help', 'app.controllers.login_help:help')
            ->method('GET|POST')
            ->bind('login_help');

        $controllers->match('/{_locale}/profile', 'app.controllers.profile:profile')
            ->method('GET|POST')
            ->bind('profile');

        $controllers->match('/{_locale}/register', 'app.controllers.register:register')
            ->method('GET|POST')
            ->bind('register');

        $controllers->match('/{_locale}/reset-password', 'app.controllers.reset_password:reset')
            ->method('GET|POST')
            ->bind('reset-password');

        $controllers->get('/{_locale}/activate', 'app.controllers.activate:verify')
            ->method('GET|POST')
            ->bind('activate-account');

        $controllers->get('/{_locale}/verify-email', 'app.controllers.email:verify')
            ->method('GET|POST')
            ->bind('verify-email');

        $controllers->get('/{_locale}/verify-new-email', 'app.controllers.fdiemail:verify')
            ->method('GET|POST')
            ->bind('verify-new-email');

        $controllers->get('/{_locale}/verify-device', 'app.controllers.device:verify')
            ->method('GET|POST')
            ->bind('verify-device');

        $controllers->get('/{_locale}/loggedout', 'app.controllers.home:loggedout')
            ->method('GET')
            ->bind('loggedout');

        $controllers->post('/sml/acs', 'app.controllers.saml:acs')
            ->method('GET|POST')
            ->bind('saml_acs');

        $controllers->get('/sml/slo', 'app.controllers.saml:slo')
            ->bind('GET|POST')
            ->bind('saml_slo');

        $controllers->get('/sml/metadata', 'app.controllers.saml:metadata')
            ->method('GET')
            ->bind('saml_metadata');

        return $controllers;
    }
}