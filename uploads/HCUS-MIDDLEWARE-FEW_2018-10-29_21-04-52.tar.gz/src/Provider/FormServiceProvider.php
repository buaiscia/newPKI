<?php

namespace HomeCredit\Provider;

use HomeCredit\Form\Extension\HelpTextTypeExtension;
use HomeCredit\Form\Type\CardActivationFormType;
use HomeCredit\Form\Type\ChangePasswordFormType;
use HomeCredit\Form\Type\ChangeEmailFormType;
use HomeCredit\Form\Type\ChangeUsernameFormType;
use HomeCredit\Form\Type\ForgotPasswordFormType;
use HomeCredit\Form\Type\ForgotUsernameFormType;
use HomeCredit\Form\Type\RegisterFormType;
use HomeCredit\Form\Type\ResetPasswordFormType;
use Pimple\Container;
use Pimple\ServiceProviderInterface;
use Silex\Provider\CsrfServiceProvider;
use Silex\Provider\FormServiceProvider as SymfonyFormServiceProvider;
use Silex\Provider\ValidatorServiceProvider;
use Symfony\Component\Config\Definition\Builder\ValidationBuilder;
use Symfony\Component\Validator\ValidatorBuilderInterface;

/**
 * Class FormServiceProvider
 * @package HomeCredit\Provider
 */
class FormServiceProvider implements ServiceProviderInterface
{
    /**
     * @param Container $app
     */
    public function register(Container $app)
    {
        $app->register(new ValidatorServiceProvider());
        $app->extend('validator.builder', function (ValidatorBuilderInterface $builder) {
            $builder->setTranslationDomain('messages');

            return $builder;
        });
        if (!($app['config']['debug'] && $app['config']['test'])) {
            $app->register(new CsrfServiceProvider());
        }

        $app->register(new SymfonyFormServiceProvider());

        $app->extend('form.type.extensions', function ($extensions) use ($app) {
            $extensions[] = new HelpTextTypeExtension();

            return $extensions;
        });

        $app['app.form.forgot_password'] = function ($app) {
            return $app['form.factory']->create(ForgotPasswordFormType::class);
        };

        $app['app.form.forgot_username'] = function ($app) {
            return $app['form.factory']->create(ForgotUsernameFormType::class);
        };
        
        $app['app.form.register'] = function ($app) {
            return $app['form.factory']->create(RegisterFormType::class);
        };

        $app['app.form.card_activation'] = function ($app) {
            return $app['form.factory']->create(CardActivationFormType::class);
        };

        $app['app.form.reset_password'] = function ($app) {
            return $app['form.factory']->create(ResetPasswordFormType::class);
        };

        $app['app.form.change_password'] = function ($app) {
            return $app['form.factory']->create(ChangePasswordFormType::class);
        };

        $app['app.form.change_username'] = function ($app) {
            return $app['form.factory']->create(ChangeUsernameFormType::class);
        };

        $app['app.form.change_email'] = function ($app) {
            return $app['form.factory']->create(ChangeEmailFormType::class);
        };
    }
}