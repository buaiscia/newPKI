<?php

namespace HomeCredit\Provider;

use GuzzleHttp\Client;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\MessageFormatter;
use GuzzleHttp\Middleware;
use GuzzleHttp\RequestOptions;
use HomeCredit\Api\Request\ActivateRequest;
use HomeCredit\Api\Request\CardActivationRequest;
use HomeCredit\Api\Request\ChangeEmailRequest;
use HomeCredit\Api\Request\ChangePasswordRequest;
use HomeCredit\Api\Request\ChangeUsernameRequest;
use HomeCredit\Api\Request\DeviceRequest;
use HomeCredit\Api\Request\EmailRequest;
use HomeCredit\Api\Request\FDIEmailRequest;
use HomeCredit\Api\Request\ForgotPasswordRequest;
use HomeCredit\Api\Request\ForgotUsernameRequest;
use HomeCredit\Api\Request\RefreshTokenRequest;
use HomeCredit\Api\Request\RegistrationRequest;
use HomeCredit\Api\Request\ResetPasswordRequest;
use HomeCredit\Api\Request\UserIndexRequest;
use HomeCredit\Api\Response\ActivateResponseHandler;
use HomeCredit\Api\Response\CardActivationResponseHandler;
use HomeCredit\Api\Response\ChangeEmailResponseHandler;
use HomeCredit\Api\Response\ChangePasswordResponseHandler;
use HomeCredit\Api\Response\ChangeUsernameResponseHandler;
use HomeCredit\Api\Response\DeviceResponseHandler;
use HomeCredit\Api\Response\EmailResponseHandler;
use HomeCredit\Api\Response\FDIEmailResponseHandler;
use HomeCredit\Api\Response\ForgotPasswordResponseHandler;
use HomeCredit\Api\Response\ForgotUsernameResponseHandler;
use HomeCredit\Api\Response\RefreshTokenResponseHandler;
use HomeCredit\Api\Response\RegistrationResponseHandler;
use HomeCredit\Api\Response\ResetPasswordResponseHandler;
use HomeCredit\Api\Response\UserIndexResponseHandler;
use Pimple\Container;
use Pimple\ServiceProviderInterface;
use Psr\Log\LogLevel;

/**
 * Class ApiServiceProvider
 * @package HomeCredit\Provider
 */
class ApiServiceProvider implements ServiceProviderInterface
{
    /**
     * @param Container $app
     */
    public function register(Container $app)
    {
        $app['guzzle'] = function (Container $app) {
            return new Client([
                'base_uri' => $app['config']['api']['base_url'],
                'handler' => $app['guzzle.handler_stack'],
                RequestOptions::VERIFY => $app['config']['api']['tls_verify'],
                RequestOptions::HEADERS => [
                    'Accept-Language' => $app['locale'],
                ]
            ]);
        };

        $app['guzzle.handler_stack'] = function (Container $app) {
            $handlerStack = HandlerStack::create();

            $handlerStack->push(
                Middleware::log(
                    $app['logger'],
                    new MessageFormatter('Guzzle Sent: {method} {uri} {req_headers} {req_body} | Server Returned: {code} {res_body}'),
                    LogLevel::DEBUG
                )
            );

            return $handlerStack;
        };

        $app['api.request.activate'] = function (Container $app) {
            return new ActivateRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.activate'] = function () {
            return new ActivateResponseHandler();
        };

        $app['api.request.device'] = function (Container $app) {
            return new DeviceRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.device'] = function () {
            return new DeviceResponseHandler();
        };

        $app['api.request.email'] = function (Container $app) {
            return new EmailRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.email'] = function () {
            return new EmailResponseHandler();
        };

        $app['api.request.fdiemail'] = function (Container $app) {
            return new FDIEmailRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.fdiemail'] = function () {
            return new FDIEmailResponseHandler();
        };


        $app['api.request.forgot_password'] = function (Container $app) {
            return new ForgotPasswordRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.forgot_password'] = function () {
            return new ForgotPasswordResponseHandler();
        };

        $app['api.request.forgot_username'] = function (Container $app) {
            return new ForgotUsernameRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.forgot_username'] = function () {
            return new ForgotUsernameResponseHandler();
        };

        $app['api.request.registration'] = function (Container $app) {
            return new RegistrationRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.registration'] = function () {
            return new RegistrationResponseHandler();
        };

        $app['api.request.card_activation'] = function (Container $app) {
            return new CardActivationRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.card_activation'] = function () {
            return new CardActivationResponseHandler();
        };

        $app['api.request.reset_password'] = function (Container $app) {
            return new ResetPasswordRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.reset_password'] = function () {
            return new ResetPasswordResponseHandler();
        };

        $app['api.request.change_password'] = function (Container $app) {
            return new ChangePasswordRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.change_password'] = function () {
            return new ChangePasswordResponseHandler();
        };

        $app['api.request.change_email'] = function (Container $app) {
            return new ChangeEmailRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.change_email'] = function () {
            return new ChangeEmailResponseHandler();
        };

        $app['api.request.change_username'] = function (Container $app) {
            return new ChangeUsernameRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.change_username'] = function () {
            return new ChangeUsernameResponseHandler();
        };
        
        $app['api.request.refresh_token'] = function (Container $app) {
            return new RefreshTokenRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.refresh_token'] = function (Container $app) {
            return new RefreshTokenResponseHandler();
        };

        $app['api.request.user_index'] = function (Container $app) {
            return new UserIndexRequest($app['guzzle'], $app['session']);
        };
        $app['api.response_handler.user_index'] = function (Container $app) {
            return new UserIndexResponseHandler();
        };
    }
}