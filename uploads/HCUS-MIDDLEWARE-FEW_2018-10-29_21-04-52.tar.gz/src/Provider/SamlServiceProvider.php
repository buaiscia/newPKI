<?php

namespace HomeCredit\Provider;

use Silex\Application;
use Pimple\Container;
use Pimple\ServiceProviderInterface;

/**
 * Class SamlServiceProvider
 * @package HomeCredit\Provider
 */
final class SamlServiceProvider implements ServiceProviderInterface
{
    /**
     * @param Container $app
     */
    public function register(Container $app)
    {
        $app['saml.settings'] = function (Application $app) {
            define('TOOLKIT_PATH', ROOT . '/vendor/onelogin/php-saml/');
            require_once TOOLKIT_PATH . '/_toolkit_loader.php';

            $config = [
                'compress' => [
                    'requests' => !$app['debug'],
                    'responses' => !$app['debug']
                ],
                'security' => [
                    'nameIdEncrypted' => true,
                    'authnRequestsSigned' => true,
                    'logoutRequestSigned' => true,
                    'logoutResponseSigned' => true,
                    'signMetadata' => true,
                    'wantMessagesSigned' => true,
                    'wantAssertionsEncrypted' => true,
                    'wantAssertionsSigned' => true,
                ],
                'strict' => !$app['debug'],
                'debug' => $app['debug'],
                'sp' => [
                    'entityId' => $app['config']['saml']['sp']['entityId'],
                    'AuthnRequestsSigned' => true,
                    'assertionConsumerService' => [
                        'url' => $app['config']['web']['base_url'] . 'saml/acs',
                        'binding' => 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST',
                    ],
                    'singleLogoutService' => [
                        'url' => $app['config']['web']['base_url'] . 'saml/slo',
                        'binding' => 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect',
                    ],
                    'NameIDFormat' => 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
                    'x509cert' => \file_get_contents(ROOT . '/config/certs/sp.crt'),
                    'privateKey' => \file_get_contents(ROOT . '/config/certs/sp.key'),
                ],
                'idp' => [
                    'entityId' => $app['config']['saml']['idp']['entityId'],
                    'singleSignOnService' => [
                        'url' => $app['config']['api']['base_url'] . 'saml/saml2/idp/SSOService.php',
                        'binding' => 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST',
                    ],
                    'singleLogoutService' => [
                        'url' => $app['config']['api']['base_url'] . 'saml/saml2/idp/SingleLogoutService.php',
                        'binding' => 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect',
                    ],
                    'x509cert' => \file_get_contents(ROOT . '/config/certs/' . $app['config']['saml']['idp']['certificate'])
                ]
            ];

            return new \OneLogin_Saml2_Auth($config);
        };
    }
}