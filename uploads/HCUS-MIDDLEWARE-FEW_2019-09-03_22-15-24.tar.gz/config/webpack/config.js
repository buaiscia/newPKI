'use strict';
let webpack = require('webpack'),
    path = require('path'),
    autoprefixer = require('autoprefixer'),
    AssetsPlugin = require('assets-webpack-plugin');

let appRoot = process.env.PWD;

module.exports = {
    entry: {
        main: [`${appRoot}/app/assets/js/main.js`],
    },
    output: {
        path: `${appRoot}/web`,
        publicPath: '/',
        filename: 'dist/js/[name].js'
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: [{
                    loader: 'babel-loader',
                    options: {
                        presets: ['es2015']
                    }
                }]
            },
            {
                test: /\.(jpg|png|ico|xml|json|svg)$/,
                use: [{
                    loader: 'file-loader',
                    options: {
                        context: path.resolve(__dirname, '../../app/assets/'),
                        name: '[path][name].[ext]',
                        outputPath: 'dist/'
                    }
                }]
            },
            {
                test: /\.woff$/,
                use: [{
                    loader: 'url-loader',
                    options: {
                        limit: 10000,
                        mimetype: 'application/font-woff',
                        name: 'dist/fonts/[name].[ext]'
                    }
                }]
            },
            {
                test: /\.woff2$/,
                use: [{
                    loader: 'url-loader',
                    options: {
                        limit: 10000,
                        mimetype: 'application/font-woff2',
                        name: 'dist/fonts/[name].[ext]'
                    }
                }]

            },
            {
                test: /\.(eot|ttf)$/,
                use: [{
                    loader: 'file-loader',
                    options: {
                        'limit': 10000,
                        'name': 'dist/fonts/[name].[ext]'
                    }
                }]
            }
        ]
    },
    resolve: {
        extensions: ['.js', '.scss'],
        alias: {
            'styles' : `${appRoot}/app/assets/scss/main`,
            'favicons' : `${appRoot}/app/assets/img/favicons/`,
            'email-imgs' : `${appRoot}/app/assets/img/email/`
        }
    },
    plugins: [
        new webpack.LoaderOptionsPlugin({
            options: {
                'postcss': function () {
                    return [autoprefixer({browsers: ['last 3 versions', 'iOS 8']})];
                }
            }
        }),
        new AssetsPlugin({filename: 'web/dist/assets.json'})
    ]
};
