<?php

use HomeCredit\Provider\ApiServiceProvider;
use HomeCredit\Provider\AuthenticationServiceProvider;
use HomeCredit\Provider\FormServiceProvider;
use HomeCredit\Provider\SamlServiceProvider;
use HomeCredit\Twig\Extension\VersionedAssetExtension;
use Knp\Provider\ConsoleServiceProvider;
use Silex\Application;
use Silex\Provider\HttpFragmentServiceProvider;
use Silex\Provider\LocaleServiceProvider;
use Silex\Provider\MonologServiceProvider;
use Silex\Provider\ServiceControllerServiceProvider;
use Silex\Provider\TranslationServiceProvider;
use Silex\Provider\TwigServiceProvider;
use Silex\Provider\WebProfilerServiceProvider;
use Symfony\Component\Translation\Loader\PoFileLoader;
use Symfony\Component\Translation\Loader\YamlFileLoader;
use Symfony\Component\Translation\Translator;
use Symfony\Component\Yaml\Yaml;
use Silex\Provider\SerializerServiceProvider;

require_once dirname(__DIR__) . '/vendor/autoload.php';

if (!defined("ROOT")) {
    define("ROOT", __DIR__ . "/../");
}

$app = new Application();

// Config
$app['config'] = function (Application $app) {
    $config = Yaml::parse(file_get_contents(__DIR__ . '/../config/default.yml'));

    if (file_exists(__DIR__ . '/../config/local.yml')) {
        $config = array_replace_recursive(
            $config,
            Yaml::parse(file_get_contents(__DIR__ . '/../config/local.yml'))
        );
    }

    return $config;
};


// Debug mode?
$app['debug'] = $app['config']['debug'];
if ($app['debug']) {
    ini_set('display_errors', 'true');
    error_reporting(-1);
}

// Console Commands
$app->register(
    new ConsoleServiceProvider(),
    [
        'console.name' => $app['config']['name'],
        'console.version' => $app['config']['version'],
        'console.project_directory' => dirname(__DIR__),
    ]
);

// Logging
$app->register(
    new MonologServiceProvider(),
    [
        'monolog.logfile' => __DIR__ . '/logs/app.log',
        'monolog.level' => constant('\Monolog\Logger::' . $app['config']['log']['level']),
        'monolog.name' => $app['config']['name'],
    ]
);

// Localization
$app->register(new LocaleServiceProvider());

// API
$app->register(new ApiServiceProvider());

// Auth
$app->register(new AuthenticationServiceProvider);

// SAML 2
$app->register(new SamlServiceProvider());

// Forms
$app->register(new FormServiceProvider());

// Serializer
$app->register(new SerializerServiceProvider());

// Translations
$app->register(new TranslationServiceProvider(), [
    'locale_fallbacks' => ['en'],
    'translator.cache_dir' => __DIR__ . '/cache/',
]);

// SAML Login URL
$app['saml_login'] = $app->protect(function (array $config, $locale) {
    $samlLogin = $config['api']['base_url'] . 'api/v1/info/login?language=' . $locale . '&spentityid=';

    if (isset($config['saml']['sp']['eCSEntityId'])) {
        $samlLogin .= $config['saml']['sp']['eCSEntityId'];
    } else {
        $samlLogin .= $config['saml']['sp']['entityId'];
    }

    return $samlLogin;
});

$app->extend('translator', function (Translator $translator) {
    $translator->addLoader('po', new PoFileLoader());

    $translator->addResource('po', __DIR__ . '/translations/messages.en.po', 'en', 'messages');
    $translator->addResource('po', __DIR__ . '/translations/messages.es.po', 'es', 'messages');

    return $translator;
});

$app->register(new ServiceControllerServiceProvider());
$app->register(new HttpFragmentServiceProvider());

// Templates
$app->register(
    new TwigServiceProvider(),
    [
        'twig.path' => dirname(__DIR__) . '/app/templates',
        'twig.options' => [
            'cache' => __DIR__ . '/cache/',
        ],
    ]
);

// web profiler
if ($app['config']['profiler']['enable'] && $app['debug']) {
    $app->register(new WebProfilerServiceProvider(), [
        'profiler.cache_dir' => ROOT . '/app/cache/profiler',
    ]);
}

// Adds versioned_asset function, e.g. versioned_asset('main.css')
$app->extend('twig', function (Twig_Environment $twig, Application $app) {
    $twig->addExtension(
        new VersionedAssetExtension(
            dirname(__DIR__) . '/web/dist/assets.json'
        )
    );
    $twig->addGlobal('modal_visible', false);
    $twig->addGlobal('modal_title', null);
    $twig->addGlobal('modal_text', null);
    $twig->addGlobal('modal_close', $app['translator']->trans('Close'));

    $twig->addFunction(new Twig_Function('saml_login', $app['saml_login']));

    $md = new Mobile_Detect;
    $twig->addFunction(new Twig_Function('is_ios', function () use ($md) {
        return $md->isIOS();
    }));

    $twig->addFunction(new Twig_Function('is_android_os', function () use ($md) {
        return $md->isAndroidOS();
    }));

    $twig->addFilter(new Twig_Filter('hash', function (string $string) {
        return hash('sha256', $string);
    }));

    return $twig;
});


/**
 * In order to get auto-complete in IDEs like PHPStorm,
 * uncomment this line and process a request.
 * This will dump a pimple.json file into the root folder.
 *
 * More Info:
 * Pimple Dumper: https://github.com/Sorien/silex-pimple-dumper
 * PHPStorm Plugin: https://github.com/Sorien/silex-idea-plugin
 */
//$app->register(new Sorien\Provider\PimpleDumpProvider());

return $app;
