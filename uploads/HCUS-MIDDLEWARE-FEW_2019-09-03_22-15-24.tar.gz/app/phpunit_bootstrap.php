<?php

if (file_exists($file = __DIR__.'/bootstrap.php')) {
    require_once $file;
}