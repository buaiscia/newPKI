<?php

namespace HomeCredit\Api\Exception;

use Exception;

/**
 * Class BadConnectionException
 * @package HomeCredit\Api\Exception
 */
class BadConnectionException extends Exception
{
}