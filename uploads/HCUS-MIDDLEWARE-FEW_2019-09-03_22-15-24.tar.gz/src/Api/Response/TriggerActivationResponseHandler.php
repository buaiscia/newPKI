<?php

namespace HomeCredit\Api\Response;

use HomeCredit\Api\Exception\BadConnectionException;
use Psr\Http\Message\ResponseInterface;

/**
 * Class TriggerActivationResponseHandler
 * @package HomeCredit\Api\Response
 */
final class TriggerActivationResponseHandler extends AbstractResponseHandler
{
}