<?php

namespace HomeCredit\Api\Response;

/**
 * Class CardActivationResponseHandler
 * @package HomeCredit\Api\Response
 */
final class CardActivationResponseHandler extends AbstractResponseHandler
{
}