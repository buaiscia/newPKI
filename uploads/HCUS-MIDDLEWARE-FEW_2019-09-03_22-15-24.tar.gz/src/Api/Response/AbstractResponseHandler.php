<?php

namespace HomeCredit\Api\Response;

use HomeCredit\Api\Exception\BadConnectionException;
use Psr\Http\Message\ResponseInterface;

/**
 * Interface AbstractResponseHandler
 * @package HomeCredit\Api\Response
 */
abstract class AbstractResponseHandler
{
    /**
     * @var bool
     */
    protected $ok;
    /**
     * @var array
     */
    protected $data;

    /**
     * @var array
     */
    protected $errors;

    /**
     * @param ResponseInterface $response
     * @return void
     * @throws BadConnectionException
     */
    public function handle(ResponseInterface $response): void
    {
        $responseJson = \json_decode($response->getBody(), true);

        if (\json_last_error() !== JSON_ERROR_NONE) {
            throw new BadConnectionException();
        }

        if (!empty($responseJson['data'])) {
            $this->ok = true;
            $this->data = $responseJson['data'];
        }
        if (!empty($responseJson['error'])) {
            foreach ($responseJson['error'] as $key => $value) {
                $this->errors[str_replace(['[', ']'], '', $key)] = $value;
            }
        }
    }

    /**
     * @return null|array
     */
    public function getData(): ?array
    {
        return $this->data;
    }

    /**
     * @return null|array
     */
    public function getErrors(): ?array
    {
        return $this->errors;
    }

    /**
     * @return bool
     */
    public function isOk(): bool
    {
        return (bool) $this->ok;
    }
}
