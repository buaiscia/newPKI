<?php

namespace HomeCredit\Api\Request;

use DateTime;
class CardActivationRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'cardnumber',
        'cvv',
        'expiration',
        'social',
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v1/card/activate';

    /**
     * @var string
     */
    protected $version = '20170711';

    /**
     * @inheritdoc
     */
    public function setData(array $data): void
    {
        parent::setData($data);
        if (!empty($this->data['expiration'])) {
            $this->data['expiration'] = (DateTime::createFromFormat('m/y', $this->data['expiration']))->format('m-y');
        }
    }
}