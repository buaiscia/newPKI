<?php

namespace HomeCredit\Api\Request;

/**
 * Class RegistrationRequest
 * @package HomeCredit\Api\Request
 */
class RegistrationRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'email',
        'password',
        'password_verify',
        'accept_terms',
        'social',
        'username',
        'welcomecode',
        'token'
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v3/customer/register';

    /**
     * @var string
     */
    protected $version = '20190218';

    /**
     * @param array $data
     */
    public function setData(array $data): void
    {
        $data['password_verify'] = $data['password'];

        parent::setData($data);
    }
}