<?php

namespace HomeCredit\Api\Request;

/**
 * Class ResetPasswordRequest
 * @package HomeCredit\Api\Request
 */
class ResetPasswordRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'reset_token',
        'password',
        'password_verify',
    ];

    protected $uri = 'api/v1/user/resetpassword';

    /**
     * @param array $data
     */
    public function setData(array $data): void
    {
        $data['password_verify'] = $data['password'];

        parent::setData($data);
    }
}