<?php

namespace HomeCredit\Api\Request;

/**
 * Class EmailValidateRequest
 * @package HomeCredit\Api\Request
 */
class EmailValidateRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'token'
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v3/user/validateEmail';
}
