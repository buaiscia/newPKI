<?php

namespace HomeCredit\Api\Request;

/**
 * Class ChangeEmailRequest
 * @package HomeCredit\Api\Request
 */
class ChangeEmailRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'password',
        'email'
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v1/user/index';
}