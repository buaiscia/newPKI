<?php

namespace HomeCredit\Api\Request;

/**
 * Class DeviceRequest
 * @package HomeCredit\Api\Request
 */
class DeviceRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'token',
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v1/user/verifydevice';

    /**
     * @inheritdoc
     */
    public function setData(array $data): void
    {
        parent::setData($data);

        // Set the token in the query parameter
        $filtered = array_filter($data, [$this, 'isAcceptedKey'], ARRAY_FILTER_USE_KEY);
        $this->uri .= '?token=' . $filtered['token'];

        // Empty data to reduce request size
        $this->data = [];
    }
}