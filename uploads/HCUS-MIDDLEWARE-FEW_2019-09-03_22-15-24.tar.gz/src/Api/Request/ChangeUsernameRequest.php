<?php

namespace HomeCredit\Api\Request;

/**
 * Class ChangeUsernameRequest
 * @package HomeCredit\Api\Request
 */
class ChangeUsernameRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'password',
        'username'
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v1/user/index';
}