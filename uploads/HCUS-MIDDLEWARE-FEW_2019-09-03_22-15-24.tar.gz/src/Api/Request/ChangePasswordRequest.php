<?php

namespace HomeCredit\Api\Request;

/**
 * Class ChangePasswordRequest
 * @package HomeCredit\Api\Request
 */
class ChangePasswordRequest extends AbstractRequest
{
    /**
     * @var array
     */
    protected $acceptedKeys = [
        'password',
        'new_password',
        'new_password_verify'
    ];

    /**
     * @var string
     */
    protected $uri = 'api/v1/user/index';

    /**
     * @param array $data
     */
    public function setData(array $data): void
    {
        $data['new_password_verify'] = $data['new_password'];

        parent::setData($data);
    }
}