<?php

namespace HomeCredit\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

class RegisterFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->addEventListener(FormEvents::PRE_SUBMIT, function (FormEvent $event) {
                $data = $event->getData();
                $form = $event->getForm();

                if (isset($data['welcomecode'])) {
                    $data['welcomecode'] = str_replace(" ", "", $data['welcomecode']);
                    $event->setData($data);
                }
            })
            ->add('username', TextType::class, [
                'label' => 'Create Username',
                'required' => true,
                'help_text' => 'Your username should be at least 8 characters and may consist of letters or numbers.',
                'help_title' => 'Pick a Username',
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 8, 'max' => 255]),
                    new Assert\Regex([
                        'pattern' => '/^[a-zA-Z0-9]*$/',
                        'message' => 'Your username may only consist of letters and numbers.',
                    ]),
                ],
                'attr' => [
                    'maxlength' => 255,
                    'minlength' => 8,
                ],
            ])
            ->add('password', RepeatedType::class, [
                'type' => PasswordType::class,
                'invalid_message' => 'The password fields must match.',
                'required' => true,
                'first_options' => [
                    'label' => 'Create Password',
                    'attr' => [
                        'maxlength' => 255,
                        'minlength' => 8,
                        'class' => 'pw-strength',
                        'pattern' => '^(?=.*[a-z])(?=.*[A-Z])(?=.*(\d|(_|[^\w]))).+$',
                    ],
                ],
                'second_options' => [
                    'label' => 'Retype Password',
                    'attr' => [
                        'maxlength' => 255,
                        'minlength' => 8,
                    ],
                ],
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 8, 'max' => 255]),
                    new Assert\NotBlank(),
                    new Assert\Callback(function ($object, ExecutionContextInterface $context, $payload) {
                        $addViolation = false;
                        $regex = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*(\d|(_|[^\w]))).+$/';
                        if (!preg_match($regex, $object)) {
                            $addViolation = true;
                        }

                        if ($addViolation) {
                            $context->buildViolation('Your password must contain a combination of upper and lower case letters, and at least one number.')
                                ->addViolation();
                        }
                    }),
                ],
            ])
            ->add('welcomecode', TextType::class, [
                'label' => 'Credit Card Number',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\CardScheme([
                        'schemes' => ['VISA'],
                        'message' => 'Invalid credit card number. Please enter the number provided in your welcome packet.',
                    ]),
                ],
            ])
            ->add('token', HiddenType::class, [
                'required' => false,
            ])
            ->add('social', PasswordType::class, [
                'label' => 'SSN (Last Four)',
                'required' => true,
                'constraints' => [
                    new Assert\Regex([
                        'pattern' => '/^\d{4}$/',
                        'message' => 'Please enter the last four digits of your Social Security Number.',
                    ]),
                ],
                'help_text' => 'We use your social security number to identify you and keep your account safe. We never store it.',
                'help_title' => 'Why do you need my SSN?',
                'help_button_text' => 'Got It',
                'attr' => [
                    'maxlength' => 4,
                    'minlength' => 4,
                    'pattern' => '^\d{4}$',
                    'title' => 'Please enter the last four digits of your Social Security Number.',
                ],
            ])
            ->add('accept_terms', CheckboxType::class, [
                'required' => true,
                'label' => false,
                'label_attr' => [
                    'class' => 'checkbox-label',
                ],
            ])
            ->add('create', SubmitType::class, [
                'label' => 'Create My Account',
            ]);
    }
}
