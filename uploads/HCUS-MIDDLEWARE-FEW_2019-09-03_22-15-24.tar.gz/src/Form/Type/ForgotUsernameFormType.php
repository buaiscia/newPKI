<?php

namespace HomeCredit\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class ForgotUsernameFormType
 * @package HomeCredit\Form\Type
 */
class ForgotUsernameFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('welcomecode', TextType::class, [
                'label' => 'Account Number',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\CardScheme([
                        'schemes' => ['VISA'],
                    ]),
                ],
            ])
            ->add('social', TextType::class, [
                'label' => 'SSN (Last Four)',
                'required' => true,
                'constraints' => [
                    new Assert\Regex([
                        'pattern' => '/^\d{4}$/',
                        'message' => 'Please enter the last four digits of your Social Security Number.',
                    ]),
                ],
                'help_text' => 'We use your social security number to identify you and keep your account safe. We never store it.',
                'help_title' => 'Why do you need my SSN?',
                'help_button_text' => 'Got It',
                'attr' => [
                    'maxlength' => 4,
                    'minlength' => 4,
                    'pattern' => '^\d{4}$',
                    'title' => 'Please enter the last four digits of your Social Security Number.',
                ]
            ])
            ->add('verify', SubmitType::class);
    }
}