<?php

namespace HomeCredit\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class ChangeEmailFormType
 * @package HomeCredit\Form\Type
 */
class ChangeEmailFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('email', RepeatedType::class, [
                'required' => true,
                'first_options' => [
                    'label' => 'New Email',
                ],
                'second_options' => [
                    'label' => 'Retype New Email',
                ],
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Email(),
                    new Assert\Length(['max' => 50]),
                ],
                'attr' => [
                    'maxlength' => 50,
                ],
            ])
            ->add('password', PasswordType::class, [
                'label' => 'Current Password',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 8, 'max' => 255]),
                ],
                'attr' => [
                    'maxlength' => 255,
                    'minlength' => 8,
                ],
            ])
            ->add('submit', SubmitType::class, [
                'label' => 'Change Email',
                'attr' => [
                    'class' => 'btn-text-small',
                ]
            ]);
    }
}