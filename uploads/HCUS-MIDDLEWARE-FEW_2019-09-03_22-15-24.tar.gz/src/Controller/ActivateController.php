<?php

namespace HomeCredit\Controller;

use HomeCredit\Api\Exception\BadConnectionException;
use HomeCredit\Api\Exception\BadRequestException;
use HomeCredit\Api\Request\AbstractRequest;
use HomeCredit\Api\Response\AbstractResponseHandler;
use Symfony\Component\Validator\Constraints\Uuid;
use Symfony\Component\Validator\Validator\RecursiveValidator;
use Symfony\Component\HttpFoundation\Request;
use Twig_Environment;

/**
 * Class ActivateController
 * @package HomeCredit\Controller
 */
class ActivateController
{
    /**
     * @var AbstractRequest
     */
    private $request;

    /**
     * @var AbstractResponseHandler
     */
    private $responseHandler;

    /**
     * @var Twig_Environment
     */
    private $twig;

    /**
     * @var RecursiveValidator
     */
    private $validator;

    /**
     * ActivateController constructor.
     * @param AbstractRequest $request
     * @param AbstractResponseHandler $responseHandler
     * @param Twig_Environment $twig
     * @param RecursiveValidator $validator
     */
    public function __construct(
        AbstractRequest $request,
        AbstractResponseHandler $responseHandler,
        Twig_Environment $twig,
        RecursiveValidator $validator
    ) {
        $this->twig = $twig;
        $this->validator = $validator;
        $this->request = $request;
        $this->responseHandler = $responseHandler;
    }

    /**
     * @param string $token
     * @return string
     */
    public function verify(Request $request)
    {
        $viewData = ['error' => null, 'success' => false];
        $token = $request->get('token');

        if (!empty($token)) {
            $this->request->setData(['activation_token' => $token]);

            try {
                $this->responseHandler->handle(
                    $this->request->send()
                );

                if ($this->responseHandler->isOk()) {
                    $viewData['success'] = true;
                }
            } catch (BadRequestException $e) {
                $viewData['error'] = 'Invalid Token';
            } catch (BadConnectionException $e) {
                $viewData['modal_visible'] = true;
                $viewData['modal_title'] = 'Connection Error';
                $viewData['modal_text'] = 'We are unable to process your request at this time.';
            }
        } else {
            $viewData['error'] = 'Invalid Token';
        }

        return $this->twig->render('pages/activate.html.twig', $viewData);
    }
}