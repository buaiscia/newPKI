<?php

namespace HomeCredit\Controller;

use HomeCredit\Api\Exception\BadConnectionException;
use HomeCredit\Api\Exception\BadRequestException;
use HomeCredit\Api\Request\AbstractRequest;
use HomeCredit\Api\Response\AbstractResponseHandler;
use Symfony\Component\Form\Exception\OutOfBoundsException;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Generator\UrlGenerator;
use Twig_Environment;

/**
 * Class RegisterController
 * @package HomeCredit\Controller
 */
final class RegisterController
{
    /**
     * @var Form
     */
    private $form;

    /**
     * @var AbstractRequest
     */
    private $registerRequest;

    /**
     * @var AbstractResponseHandler
     */
    private $registerResponseHandler;

    /**
     * @var AbstractRequest
     */
    private $triggerActivationRequest;

    /**
     * @var AbstractResponseHandler
     */
    private $triggerActivationResponseHandler;

    /**
     * @var Twig_Environment
     */
    private $twig;

    /**
     * @var UrlGenerator
     */
    private $urlGenerator;

    /**
     * @var string
     */
    private $locale;

    /**
     * RegisterController constructor.
     * @param Form $form
     * @param string $locale
     * @param AbstractRequest $request
     * @param AbstractResponseHandler $responseHandler
     * @param Twig_Environment $twig
     * @param UrlGenerator $urlGenerator
     */
    public function __construct(
        Form $form,
        string $locale,
        AbstractRequest $registerRequest,
        AbstractResponseHandler $registerResponseHandler,
        AbstractRequest $triggerActivationRequest,
        AbstractResponseHandler $triggerActivationResponseHandler,
        Twig_Environment $twig,
        UrlGenerator $urlGenerator
    ) {
        error_reporting(-1);
        ini_set('display_errors', 'true');
        $this->form = $form;
        $this->registerRequest = $registerRequest;
        $this->registerResponseHandler = $registerResponseHandler;
        $this->triggerActivationRequest = $triggerActivationRequest;
        $this->triggerActivationResponseHandler = $triggerActivationResponseHandler;
        $this->twig = $twig;
        $this->urlGenerator = $urlGenerator;
        $this->locale = $locale;
    }

    /**
     * @param Request $request
     * @return string
     */
    public function register(Request $request)
    {
        $viewData = [];
        $viewData['form_errors'] = null;

        $token = $request->query->get('token');

        // some tokens may contain a plus sign
        // replace plus sign with a space symbol
        // HCUR-3080
        $token = str_replace(" ", "+", $token);

        if ($token) {
            // customer is registering using a Day-1-Registration invitation URL
            // hide credit card number field
            $this->form->remove('welcomecode');
        }

        $this->form->handleRequest($request);

        if ($request->isMethod("GET")) {
            $this->form->get('token')->setData($token);
        }

        if ($this->form->isValid()) {
            $data = $this->form->getData();
            if (isset($data['welcomecode'])) {
                $data['welcomecode'] = str_replace(" ", "", $data['welcomecode']);
            }
            $this->registerRequest->setData($data);

            try {
                $this->registerResponseHandler->handle(
                    $this->registerRequest->send()
                );

                if ($this->registerResponseHandler->isOk()) {
                    // After customer is successfully registered, we need to send a new request to initiate an activation email
                    $this->triggerActivationRequest->setData([
                        'username' => $data['username'],
                        'contactMethod' => 'email',
                    ]);

                    $this->triggerActivationResponseHandler->handle(
                        $this->triggerActivationRequest->send()
                    );

                    if ($this->triggerActivationResponseHandler->isOk()) {
                        return new RedirectResponse(
                            $this->urlGenerator->generate('home', [
                                'registered' => '1',
                            ])
                        );
                    }
                }
            } catch (BadRequestException $e) {
                foreach ($e->getErrors() as $key => $value) {
                    try {
                        if ($key == "token") {
                            // HCUR-2989
                            $this->form->get($key)->addError(new FormError("Something went wrong. Please try again by clicking the Create Your Login link above and providing your credit card number to register your account."));
                        } else {
                            $this->form->get($key)->addError(new FormError($value));
                        }
                    } catch (OutOfBoundsException $e) {
                        $this->form->addError(new FormError($value));
                    }
                }
            } catch (BadConnectionException $e) {
                $viewData['modal_visible'] = true;
                $viewData['modal_title'] = 'Connection Error';
                $viewData['modal_text'] = 'We are unable to process your request at this time.';
            }
        } elseif ($this->form->isSubmitted()) {
            $viewData['form_errors'] = json_encode($this->getFormErrors($this->form));
        }

        $viewData['register_form'] = $this->form->createView();

        return $this->twig->render('pages/register.html.twig', $viewData);
    }

    /**
     * List all errors of a given bound form.
     *
     * @param Form $form
     * @return array
     */
    protected function getFormErrors(Form $form)
    {
        $errors = array();

        // Global
        foreach ($form->getErrors() as $error) {
            $errors[$form->getName()][] = $error->getMessage();
        }

        // Fields
        foreach ($form as $child/** @var Form $child */) {
            if (!$child->isValid()) {
                foreach ($child->getErrors() as $error) {
                    $errors[$child->getName()][] = $error->getMessage();
                }
            }
        }

        return $errors;
    }
}
