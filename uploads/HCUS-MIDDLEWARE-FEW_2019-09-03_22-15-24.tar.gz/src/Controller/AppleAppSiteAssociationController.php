<?php

namespace HomeCredit\Controller;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class AppleAppSiteAssociationController
 * @package HomeCredit\Controller
 */
final class AppleAppSiteAssociationController
{
    /**
     * Returns the /apple-app-site-association file for deep links
     * @param Application $app
     * @param Request $request
     * @return JsonResponse
     */
    public function index(Application $app, Request $request)
    {
        return JsonResponse::create([
            'applinks' => [
                'apps' => [],
                'details' => [
                    [
                        'appID' => $app['config']['apple-app-site-association']['appID'],
                        'paths' => $app['config']['apple-app-site-association']['paths']
                    ]
                ]
            ]
        ]);
    }
}