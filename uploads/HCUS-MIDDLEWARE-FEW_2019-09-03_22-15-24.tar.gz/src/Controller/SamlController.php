<?php

namespace HomeCredit\Controller;

use Exception;
use OneLogin_Saml2_Error;
use Silex\Application;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\Routing\Generator\UrlGenerator;

/**
 * Class SamlController
 * @package HomeCredit\Controller
 */
final class SamlController
{
    /**
     * @var UrlGenerator
     */
    protected $urlGenerator;

    /**
     * Constructor
     * @param URLGenerator $urlGenerator
     */
    public function __construct($urlGenerator)
    {
        $this->urlGenerator = $urlGenerator;
    }

    /**
     * Outputs the SAML2 SP XML Metadata file
     * @param Application $app
     * @param Request $request
     */
    public function acs(Application $app, Request $rquest)
    {
        // This is the authentication entry point.
        // Authentication is handled by AuthenticationServiceProvider, and SamlAuthenticator.
        // See those 2 classes for more details
    }

    /**
     * Outputs the SAML2 SP XML Metadata file
     * @param Application $app
     * @param Request $request
     * @return Response
     * @throws HttpException
     */
    public function metadata(Application $app)
    {
        try {
            $settings = $app['saml.settings']->getSettings();
            $metadata = $settings->getSPMetadata();
            $errors = $settings->validateMetadata($metadata);
            if (empty($errors)) {
                return Response::create(
                    $metadata,
                    200,
                    [
                        'Content-Type' => 'text/xml'
                    ]
                );
            } else {
                throw new OneLogin_Saml2_Error(
                    'Invalid SP metadata: ' . implode(', ', $errors),
                    OneLogin_Saml2_Error::METADATA_SP_INVALID
                );
            }
        } catch (Exception $e) {
            throw new HttpException(500, $e->getMessage());
        }
    }

    /**
     * SLO de-authentication
     * After initiating a SLO from the iDP, the iDP will redirect the user to this endpoint for further handling
     * @param Application $app
     * @param Request $request
     * @return Response
     * @throws HttpException
     */
    public function slo(Application $app, Request $request)
    {
        // Invalidates the active user's session
        $request->getSession()->invalidate(1);

        // Redirect the user to the (en|es)/loggedout
        return new RedirectResponse($this->urlGenerator->generate('loggedout'));
    }
}