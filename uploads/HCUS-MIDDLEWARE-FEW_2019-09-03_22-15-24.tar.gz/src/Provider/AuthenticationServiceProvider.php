<?php

namespace HomeCredit\Provider;

use HomeCredit\Security\SamlAuthenticator;
use HomeCredit\Security\UserProvider;
use Pimple\Container;
use Pimple\ServiceProviderInterface;
use Silex\Provider\SecurityServiceProvider;
use Silex\Provider\SessionServiceProvider;

class AuthenticationServiceProvider implements ServiceProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function register(Container $app)
    {
        $app->register(
            new SessionServiceProvider(),
            [
                'session.storage.options' => [
                    'cookie_httponly' => true,
                    'cookie_domain' => \parse_url($app['config']['web']['base_url'], PHP_URL_HOST),
                    'cookie_lifetime' => 900, // Force the session to expire after 15 minutes to keep it in-line with the SAML session
                    'cookie_secure' => true,
                    'name' => 'HomeCreditUS-web',
                ],
                'session.storage.handler' => null,
            ]
        );

        $app->register(
            new SecurityServiceProvider(),
            [
                'security.firewalls' => [
                    'main' => [
                        'anonymous' => true,
                        'guard' => [
                            'authenticators' => [
                                'app.security.saml_authenticator',
                            ],
                            'entry_point' => 'app.security.saml_authenticator',
                        ],
                        'users' => function () use ($app) {
                            return new UserProvider($app['api.request.user_index'], $app['api.response_handler.user_index']);
                        },
                        'logout' => [
                            'logout_path' => '/logout',
                            'target_url' => $app['config']['api']['base_url'] . 'saml/saml2/idp/SingleLogoutService.php?ReturnTo=' . $app['config']['web']['base_url'] . $app['locale'] . '/loggedout',
                            'invalidate_session' => true,
                        ],
                    ]
                ]
            ]
        );

        $app['security.role_hierarchy'] = [
            'ROLE_CUSTOMER' => ['ROLE_AUTHENTICATED'],
        ];

        $app['security.access_rules'] = [
            ['^/(en|es)/profile$', 'ROLE_AUTHENTICATED'],
            ['^/activate-account', 'IS_AUTHENTICATED_ANONYMOUSLY'],
            ['^/verify-device', 'IS_AUTHENTICATED_ANONYMOUSLY'],
            ['^/reset-password', 'IS_AUTHENTICATED_ANONYMOUSLY'],
            ['/saml/acs', 'IS_AUTHENTICATED_ANONYMOUSLY'],
            ['/', 'IS_AUTHENTICATED_ANONYMOUSLY'],
        ];

        $app['app.security.saml_authenticator'] = function (Container $app) {
            return new SamlAuthenticator(
                $app['logger'],
                $app['saml.settings'],
                $app['url_generator'],
                $app['saml_login'],
                $app['config'],
                $app['locale'],
                $app['api.request.user_index'],
                $app['api.response_handler.user_index']
            );
        };
    }
}