<?php

namespace HomeCredit\Security;

use Exception;
use HomeCredit\Repository\ApiRepository;
use HomeCredit\Api\Exception\BadConnectionException;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationServiceException;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;
use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\Security\Core\Exception\CredentialsExpiredException;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;

/**
 * Class UserProvider
 * @package HomeCredit\Security
 */
class UserProvider implements UserProviderInterface
{
    /**
     * @var AbstractRequest $request
     */
    private $request;

    /**
     * @var AbstractResponseHandler $responseHandler
     */
    private $responseHandler;

    /**
     * Constructor
     * @param AbstractRequest $request
     * @param AbstractResponseHandler $response
     */
    public function __construct($request, $responseHandler)
    {
        $this->request = $request;
        $this->responseHandler = $responseHandler;
    }

    /**
     * {@inheritdoc}
     */
    public function loadUserByUsername($username)
    {
    }

    /**
     * {@inheritdoc}
     */
    public function refreshUser(UserInterface $user)
    {
        if (!$user instanceof User) {
            throw new UnsupportedUserException();
        }

        try {
            $this->responseHandler->handle(
                $this->request->get(false)
            );
            return $user;
        } catch (BadCredentialsException $e) {
            // If the credentials are not good, log the user out
            throw new CredentialsExpiredException();
        } catch (\Exception $e) {
            throw new UnsupportedUserException();
        }
    }

    /**
     * {@inheritdoc}
     */
    public function supportsClass($class)
    {
        return $class === User::class;
    }
}