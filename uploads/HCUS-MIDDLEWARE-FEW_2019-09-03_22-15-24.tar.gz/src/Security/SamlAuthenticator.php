<?php

namespace HomeCredit\Security;

use Closure;
use OneLogin_Saml2_Auth;
use HomeCredit\Api\Request\AbstractRequest;
use HomeCredit\Api\Response\AbstractResponseHandler;
use HomeCredit\Api\Exception\BadConnectionException;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Generator\UrlGenerator;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Guard\AbstractGuardAuthenticator;

class SamlAuthenticator extends AbstractGuardAuthenticator
{
    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Closure
     */
    protected $loginURL;

    /**
     * @var array
     */
    protected $config;

    /**
     * @var string
     */
    protected $locale;

    /**
     * @var OneLogin_Saml2_Auth
     */
    protected $saml;

    /**
     * @var UrlGenerator
     */
    protected $urlGenerator;

    /**
     * @var $request
     */
    protected $request;

    /**
     * @var $response
     */
    protected $responseHandler;

    /**
     * FormAuthenticator constructor.
     * @param LoggerInterface $logger
     * @param UrlGenerator $urlGenerator
     * @param Closure $loginURL
     * @param array $config
     * @param string $locale
     * @param AbstractRequest $request
     * @param AbstractResponseHandler $responseHandler
     */
    public function __construct(
        LoggerInterface $logger,
        OneLogin_Saml2_Auth $samlSettings,
        UrlGenerator $urlGenerator,
        Closure $loginURL,
        array $config,
        string $locale,
        AbstractRequest $request,
        AbstractResponseHandler $responseHandler
    ) {
        $this->logger = $logger;
        $this->loginURL = $loginURL;
        $this->config = $config;
        $this->locale = $locale;
        $this->saml = $samlSettings;
        $this->urlGenerator = $urlGenerator;
        $this->request = $request;
        $this->responseHandler = $responseHandler;
    }

    /**
     * @param Request $request
     * @param AuthenticationException|null $authException
     * @return RedirectResponse
     */
    public function start(Request $request, AuthenticationException $authException = null)
    {
        $this->logger->info('User not authenticated, redirecting to login page');

        return new RedirectResponse(($this->loginURL)($this->config, $this->locale));
    }

    /**
     * @param Request $request
     * @return array|null
     */
    public function getCredentials(Request $request)
    {
        // Supress mcrypt errors on this page in case the server configuration is set to show them
        ini_set('display_errors', 'false');

        // Intercept the URL
        if ($request->getPathInfo() === $this->urlGenerator->generate('saml_acs')) {
            $this->logger->info('Authentication from SAML endpoint initiated');

            $session = $request->getSession();
            if ($session->has('AuthNRequestID')) {
                $requestID = $session->get('AuthNRequestID');
            } else {
                $requestID = null;
            }

            try {
                $this->saml->processResponse($requestID);
            } catch (\Exception $e) {
                return  null;
            }
            
            $errors = $this->saml->getErrors();

            if (!empty($errors)) {
                return null;
            }

            if (!$this->saml->isAuthenticated()) {
                return null;
            }

            return $this->saml->getAttributes();
        }

        return null;
    }

    /**
     * @param mixed $credentials
     * @param UserProviderInterface $userProvider
     * @return null|User|UserInterface
     */
    public function getUser($credentials, UserProviderInterface $userProvider)
    {
        $this->logger->debug('Session identifier with credentials', [
            'credentials' => $credentials
        ]);

        return User::createFromSamlResponse($credentials);
    }

    /**
     * @param mixed $credentials
     * @param UserInterface $user
     * @return bool
     */
    public function checkCredentials($credentials, UserInterface $user)
    {
        try {
            $this->responseHandler->handle(
                $this->request->get(false, $credentials)
            );
            return true;
        } catch (BadConnectionException $e) {
            $this->logger->error('Unable to connect to API');
            return false;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Handles authentication errors
     * @param Request $request
     * @param AuthenticationException $exception
     */
    public function onAuthenticationFailure(Request $request, AuthenticationException $exception)
    {
        // Construct the appropriate relay url
        $components = \parse_url(($this->loginURL)($this->config, $this->locale));
        unset($components['query']);
        $components['path'] = \str_replace('api/v1/info/login', 'saml/saml2/idp/SingleLogoutService.php', $components['path']);
        $redirectUrl = $components['scheme'] . '://' . $components['host'] . $components['path'] . '?ReturnTo=' . ($this->loginURL)($this->config, $this->locale);

        // Destroy the current session
        $request->getSession()->invalidate(1);

        return new RedirectResponse($redirectUrl);

    }

    /**
     * @param Request $request
     * @param TokenInterface $token
     * @param string $providerKey
     * @return RedirectResponse
     */
    public function onAuthenticationSuccess(Request $request, TokenInterface $token, $providerKey)
    {
        $this->logger->info('Authentication successful');

        /** @var User $user */
        $user = $token->getUser();
        $session = $request->getSession();
        $session->set('app.security.roles', \implode(',', $user->getRoles()));
        $session->set('app.security.refresh_token', $user->getRefreshToken());
        $session->set('app.security.access_token', $user->getAccessToken());
        $session->set('app.security.ikm', $user->getIkm());
        $session->set('app.security.username', $user->getUsername());
        $session->set('app.security.cid', $user->getCid());

        $session->migrate();

        return new RedirectResponse($this->urlGenerator->generate('profile'));
    }

    /**
     * @return bool
     */
    public function supportsRememberMe()
    {
        return false;
    }
}