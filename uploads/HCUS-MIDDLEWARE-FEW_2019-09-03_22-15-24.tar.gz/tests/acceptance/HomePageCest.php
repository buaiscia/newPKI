<?php

namespace tests\acceptance;

use AcceptanceTester;

class HomePageCest
{
    public function indexTest(\AcceptanceTester $I)
    {
        $I->amOnPage('/en');
        $I->see('My Home Credit');
    }
}
