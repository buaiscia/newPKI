document.addEventListener('DOMContentLoaded', function () {
    window.location = document.querySelector('#redirect');
});
