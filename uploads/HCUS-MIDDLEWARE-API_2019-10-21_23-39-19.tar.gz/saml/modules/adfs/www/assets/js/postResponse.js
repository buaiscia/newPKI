document.addEventListener('DOMContentLoaded', function () {
    document.forms[0].submit();
});
