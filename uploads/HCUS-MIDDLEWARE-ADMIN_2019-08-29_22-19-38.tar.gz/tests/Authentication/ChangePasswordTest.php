<?php

namespace tests\unit\Controller;

use GuzzleHttp\Client;
use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use HomeCredit\Test\AbstractTestCase;
use Silex\Application;

class ChangePasswordTest extends AbstractTestCase
{
    /**
     * @dataProvider roleProvider
     */
    public function testShowFormAndValidation($role)
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh response
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh response
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs([$role]);

        // go to profile page
        $crawler = $client->request('GET', '/profile');

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#change_profile_password_form'));

        $form = $crawler->selectButton('Save')->form();
        $form['change_profile_password_form[current_password]'] = '';
        $form['change_profile_password_form[new_password][first]'] = 'short';
        $form['change_profile_password_form[new_password][second]'] = 'short';


        $crawler = $client->submit($form);
        $this->assertTrue($client->getResponse()->isOk());

        $errorBlocks = $crawler->filter('.has-error .help-block li');
        $this->assertCount(2, $errorBlocks);
        $this->assertContains('This value should not be blank.', $errorBlocks->eq(0)->text());
        $this->assertContains('This value is too short.', $errorBlocks->eq(1)->text());
    }

    /**
     * @dataProvider roleProvider
     */
    public function testChangePasswordApiErrors($role)
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh response
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh response
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // change password response
                new RequestException(
                    'Server Error.',
                    new Request('POST', '/api/v1/supporter/password'),
                    new Response(500, [], json_encode([
                        'data' => [
                            'error'
                        ]
                    ]))
                ),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs([$role]);

        $crawler = $client->request('GET', '/profile');
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#change_profile_password_form'));

        $form = $crawler->selectButton('Save')->form();
        $form['change_profile_password_form[current_password]'] = 'good_password';
        $form['change_profile_password_form[new_password][first]'] = 'good_password';
        $form['change_profile_password_form[new_password][second]'] = 'good_password';

        $crawler = $client->submit($form);
        $this->assertTrue($client->getResponse()->isOk());

        $alert = $crawler->filter('.alert');
        $this->assertCount(1, $alert);
        $this->assertContains('Unable to save your new password. Please try again later.', $alert->text());
    }

    /**
     * @dataProvider roleProvider
     */
    public function testChangePasswordApiValidationErrors($role)
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh response
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh response
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // change password error response
                RequestException::create(
                    new Request('POST', '/api/v1/supporter/password'),
                    new Response(400, [], json_encode([
                        'error' => [
                            'description' => [
                                '[password]' => 'Invalid password, man',
                                '[new_password]' => 'Invalid new password, man',
                                '[new_password_verify]' => 'Invalid verify new password, man',
                            ],
                        ],
                    ]))
                ),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs([$role]);

        // go to profile page
        $crawler = $client->request('GET', '/profile');
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#change_profile_password_form'));

        $form = $crawler->selectButton('Save')->form();
        $form['change_profile_password_form[current_password]'] = 'OK_PASSWORD';
        $form['change_profile_password_form[new_password][first]'] = 'OK_PASSWORD';
        $form['change_profile_password_form[new_password][second]'] = 'OK_PASSWORD';

        // submit change password form
        $crawler = $client->submit($form);
        $this->assertTrue($client->getResponse()->isOk());

        $alerts = $crawler->filter('.has-error .help-block li');
        $this->assertCount(3, $alerts);
        $this->assertContains('Invalid password, man', $alerts->eq(0)->text());
        $this->assertContains('Invalid new password, man', $alerts->eq(1)->text());
        $this->assertContains('Invalid verify new password, man', $alerts->eq(2)->text());
    }

    /**
     * @dataProvider roleProvider
     */
    public function testChangePasswordSuccessfully($role)
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh response
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh response
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh response
                new Response(200, [], json_encode([
                    'data' => true
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs([$role]);

        // go to profile page
        $crawler = $client->request('GET', '/profile');
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#change_profile_password_form'));

        $form = $crawler->selectButton('Save')->form();
        $form['change_profile_password_form[current_password]'] = 'OK_PASSWORD';
        $form['change_profile_password_form[new_password][first]'] = 'OK_PASSWORD';
        $form['change_profile_password_form[new_password][second]'] = 'OK_PASSWORD';

        // submit change password form
        $client->submit($form);
        $this->assertTrue($client->getResponse()->isRedirect('/'));
    }

    public function roleProvider()
    {
        return [
            ['ROLE_SUPPORTER'],
            ['ROLE_ADMINISTRATOR'],
        ];
    }
}
