<?php

namespace tests\unit\Controller;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use HomeCredit\Test\AbstractTestCase;
use Pimple\Container;
use Silex\Application;

class LoginTest extends AbstractTestCase
{
    public function testValidationErrors()
    {
        $client = $this->createClient();

        // view login page
        $crawler = $client->request('GET', '/');
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#login_form'));

        // submit form with bad data
        $form = $crawler->selectButton('Submit')->form();
        $form['login_form[username]'] = '';
        $form['login_form[password]'] = 'asdf';

        $crawler = $client->submit($form);

        // get error messages and confirm they are shown
        $alerts = $crawler->filter('.has-error .help-block li');
        $this->assertCount(2, $alerts);
        $this->assertContains('This value should not be blank.', $alerts->eq(0)->text());
        $this->assertContains('This value is too short.', $alerts->eq(1)->text());
    }

    public function testInvalidCredentials()
    {
        // api returns 401 status code from authenticate endpoint
        $this->app->extend('app.client.api', function () {
            $mockHandler = new MockHandler([
                new RequestException(
                    'Invalid credentials',
                    new Request('GET', '/api/v1/user/authenticate'),
                    new Response(401)
                ),
            ]);

            return new Client([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        // view login page
        $crawler = $client->request('GET', '/');
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#login_form'));

        // submit form
        $form = $crawler->selectButton('Submit')->form();
        $form['login_form[username]'] = 'asdfasdf';
        $form['login_form[password]'] = 'asdfasdf';

        $client->submit($form);
        $crawler = $client->followRedirect();

        // get errors
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertContains('Invalid credentials.', $crawler->filter('.alert')->text());
    }

    public function testServerError()
    {
        // api returns 500 status code from authenticate endpoint
        $this->app->extend('app.client.api', function () {
            $mockHandler = new MockHandler([
                new RequestException(
                    'Invalid credentials',
                    new Request('GET', '/api/v1/user/authenticate'),
                    new Response(500)
                ),
            ]);

            return new Client([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        // view login page
        $crawler = $client->request('GET', '/');
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#login_form'));

        // submit form
        $form = $crawler->selectButton('Submit')->form();
        $form['login_form[username]'] = 'asdfasdf';
        $form['login_form[password]'] = 'asdfasdf';

        $client->submit($form);
        $crawler = $client->followRedirect();

        // get errors
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertContains('Server error. Please try again.', $crawler->filter('.alert')->text());
    }

    public function testInvalidRoleReturned()
    {
        // api returns auth credentials
        $this->app->extend('app.client.api', function () {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'role' => 1, // customer role
                        'expires_at' => time(),
                    ]
                ])),
            ]);

            return new Client([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        // view login page
        $crawler = $client->request('GET', '/');
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#login_form'));

        // submit form
        $form = $crawler->selectButton('Submit')->form();
        $form['login_form[username]'] = 'asdfasdf';
        $form['login_form[password]'] = 'asdfasdf';

        $client->submit($form);
        $crawler = $client->followRedirect();

        // get errors
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertContains('Invalid credentials.', $crawler->filter('.alert')->text());
    }

    /**
     * @param int $roleId
     * @param string $redirectUri
     * @dataProvider roleIdProvider
     */
    public function testSuccessfulRoleLogin($roleId, $redirectUri)
    {
        $this->app['test.role.id'] = $roleId;

        // api returns auth credentials
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'role' => $app['test.role.id'],
                        'expires_at' => time(),
                    ]
                ])),
            ]);

            return new Client([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        // view login page
        $crawler = $client->request('GET', '/');
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#login_form'));

        // submit form
        $form = $crawler->selectButton('Submit')->form();
        $form['login_form[username]'] = 'asdfasdf';
        $form['login_form[password]'] = 'asdfasdf';

        $client->submit($form);
        $this->assertTrue($client->getResponse()->isRedirect($redirectUri));
    }

    public function roleIdProvider()
    {
        return [
            [2, '/customer/search'],
            [3, '/support/staff'],
        ];
    }

}
