<?php

namespace tests\unit\Controller;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use HomeCredit\Security\User;
use HomeCredit\Test\AbstractTestCase;
use Silex\Application;
use Symfony\Component\Security\Guard\Token\PostAuthenticationGuardToken;

class RefreshTokenTest extends AbstractTestCase
{
    public function testTokensAreRefreshedOnEachPageLoad()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh token response
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'new_access_token',
                        'refresh_token' => 'new_refresh_token',
                        'ikm' => 'new_ikm',
                        'expires_at' => time(),
                        // no role when refreshing
                    ]
                ])),
            ]);

            return new Client([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_SUPPORTER']);

        // view dashboard
        $crawler = $client->request('GET', '/customer/search');
        $this->assertContains('Search Form', $crawler->filter('h2')->eq(0)->text());

        // check token values after refresh
        /** @var PostAuthenticationGuardToken $currentToken */
        $currentToken = unserialize($this->app['session']->get('_security_main'));

        /** @var User $currentUser */
        $currentUser = $currentToken->getUser();

        $this->assertEquals('new_access_token', $currentUser->getAccessToken());
        $this->assertEquals('new_refresh_token', $currentUser->getRefreshToken());
        $this->assertEquals('new_ikm', $currentUser->getIkm());
    }

    public function testFailedRefreshTokenAttempt()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh token response (generic error)
                new RequestException(
                    'Invalid credentials.',
                    new Request('POST', '/api/v1/user/refresh')
                ),
                // refresh token response (generic error)
                new RequestException(
                    'Invalid credentials.',
                    new Request('POST', '/api/v1/user/refresh')
                ),
            ]);

            return new Client([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_SUPPORTER']);

        // view dashboard
        $client->request('GET', '/customer/search');
        $this->assertTrue($client->getResponse()->isRedirect('/'));

        // refresh failed, back to login page to invalidate
        $crawler = $client->followRedirect();

        // verify error
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertContains('Your credentials have expired.', $crawler->filter('.alert')->text());

        // verify you can't access the dashboard anymore
        $client->request('GET', '/customer/search');
        $this->assertTrue($client->getResponse()->isRedirect('/'));

        // and back to the login page once more
        $crawler = $client->followRedirect();

        // get errors
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertContains('Your credentials have expired.', $crawler->filter('.alert')->text());
    }
}
