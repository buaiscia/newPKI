<?php

namespace tests\Admin;

use HomeCredit\Test\AbstractTestCase;
use GuzzleHttp\Client;
use Silex\Application;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\RequestException;

class UpdateStaffMemberTest extends AbstractTestCase
{
    public function testFormShows()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff/1');

        $this->assertTrue($client->getResponse()->isOk());
        
        $updateForm = $crawler->filter('#update_staff_member_form');
        $this->assertCount(1, $updateForm);
        $this->assertContains('Update Staff Member', $crawler->filter('h1')->text());
    }   

    public function testValidationErrorsDisplay()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // update staff member response
                new RequestException(
                    'Server Error.',
                    new Request('POST', '/api/v1/admin/index?id=4'),
                    new Response(400, [], json_encode([
                        'error' => [
                            'description' => [
                                '[email]' => 'Invalid email, man',
                                '[new_password]' => 'Invalid new password, man',
                                '[new_password_verify]' => 'Invalid new password verify, man',
                                '[password]' => 'Invalid password, man',
                            ],
                        ],
                    ]))
                ),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff/1');

        $this->assertTrue($client->getResponse()->isOk());
        
        $updateForm = $crawler->filter('#update_staff_member_form')->parents()->eq(0)->form();
        $updateForm['update_staff_member_form[email]'] = 'john.doe@punchkick.com';
        $updateForm['update_staff_member_form[password][first]'] = 'somepass';
        $updateForm['update_staff_member_form[password][second]'] = 'somepass';
        $updateForm['update_staff_member_form[your_password]'] = 'somepass';

        $crawler = $client->submit($updateForm);
        
        $this->assertTrue($client->getResponse()->isOk());
        $errors = $crawler->filter('.has-error .help-block li');
        $this->assertCount(4, $errors);
        $this->assertContains('Invalid email, man', $errors->eq(0)->text());
        $this->assertContains('Invalid new password, man', $errors->eq(1)->text());
        $this->assertContains('Invalid new password verify, man', $errors->eq(2)->text());
        $this->assertContains('Invalid password, man', $errors->eq(3)->text());
    }

    public function testServerErrorDisplays()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // update staff member response
                new RequestException(
                    'Server Error.',
                    new Request('POST', '/api/v1/admin/index?id=4'),
                    new Response(500)
                ),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff/1');

        $this->assertTrue($client->getResponse()->isOk());
        
        $updateForm = $crawler->filter('#update_staff_member_form')->parents()->eq(0)->form();
        $updateForm['update_staff_member_form[email]'] = 'john.doe@punchkick.com';
        $updateForm['update_staff_member_form[password][first]'] = 'somepass';
        $updateForm['update_staff_member_form[password][second]'] = 'somepass';
        $updateForm['update_staff_member_form[your_password]'] = 'somepass';

        $crawler = $client->submit($updateForm);
        
        $this->assertTrue($client->getResponse()->isOk());
        $errors = $crawler->filter('.alert');
        $this->assertCount(1, $errors);
        $this->assertContains('Unable to save changes.', $errors->text());
    }

    public function testSubmitsSuccessfully()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // update staff member response
                new Response(200, [], json_encode([
                    'data' => true,
                ]))
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff/1');

        $this->assertTrue($client->getResponse()->isOk());
        
        $updateForm = $crawler->filter('#update_staff_member_form')->parents()->eq(0)->form();
        $updateForm['update_staff_member_form[email]'] = 'john.doe@punchkick.com';
        $updateForm['update_staff_member_form[password][first]'] = 'somepass';
        $updateForm['update_staff_member_form[password][second]'] = 'somepass';
        $updateForm['update_staff_member_form[your_password]'] = 'somepass';

        $crawler = $client->submit($updateForm);
        
        $this->assertTrue($client->getResponse()->isOk());
        $successMessage = $crawler->filter('.alert');
        $this->assertCount(1, $successMessage);
        $this->assertContains('Staff member updated successfully', $successMessage->text());
        
    }
}


