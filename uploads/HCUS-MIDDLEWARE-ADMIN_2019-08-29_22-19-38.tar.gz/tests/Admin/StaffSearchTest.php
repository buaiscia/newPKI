<?php

namespace tests\Admin;

use HomeCredit\Test\AbstractTestCase;
use GuzzleHttp\Client;
use Silex\Application;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\RequestException;

class StaffSearchTest extends AbstractTestCase
{
    public function testSearchFormShows()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // get staff response
                new Response(200, [], json_encode([
                    'data' => [
                        '1' => [
                            'email' => 'john.doe@punchkick.com',
                            'username' => 'johndoe555',
                        ],
                    ],
                ])),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });


        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff');

        $this->assertTrue($client->getResponse()->isOk());
        
        $searchField = $crawler->filter('input[placeholder="Email Search"]');
        $this->assertCount(1, $searchField);
        $this->assertContains('Support Staff', $crawler->filter('h1')->text());
    }

    public function testServerErrors()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // get staff response
                new RequestException(
                    'Server Error.',
                    new Request('POST', '/api/v1/admin/index'),
                    new Response(500)
                ),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });


        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff');

        $this->assertTrue($client->getResponse()->isOk());
        
        $this->assertContains('Unable to communicate with server.', $crawler->filter('.alert')->text());
    }

    public function testNoResults()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // get staff response
                new Response(200, [], json_encode([
                    'data' => [],
                ])),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });


        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff');

        $this->assertTrue($client->getResponse()->isOk());

        $this->assertContains('No staff members found.', $crawler->filter('tbody tr td')->text());

    }

    public function testResults()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // get staff response
                new Response(200, [], json_encode([
                    'data' => [
                        '1' => [
                            'email' => 'john.doe@punchkick.com',
                            'username' => 'johndoe555',
                        ],
                    ],
                ])),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });


        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff');

        $this->assertTrue($client->getResponse()->isOk());
        
        $this->assertContains('john.doe@punchkick.com', $crawler->filter('tbody tr td:first-child')->text());
        $this->assertContains('johndoe555', $crawler->filter('tbody tr td:nth-child(2)')->text());
    }
}
