<?php

namespace tests\Admin;

use HomeCredit\Test\AbstractTestCase;
use GuzzleHttp\Client;
use Silex\Application;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\RequestException;

class DeleteStaffMemberTest extends AbstractTestCase
{
    public function testFormRendered()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // get staff response
                new Response(200, [], json_encode([
                    'data' => [
                        '1' => [
                            'email' => 'john.doe@punchkick.com',
                            'username' => 'johndoe555',
                        ],
                    ],
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff');

        $this->assertTrue($client->getResponse()->isOk());
        
        $deleteForm = $crawler->filter('#delete_staff_member_form');
        $this->assertCount(1, $deleteForm);
        $this->assertContains('Support Staff', $crawler->filter('h1')->text());
    }   

    public function testServerErrorReturned()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // get staff response
                new Response(200, [], json_encode([
                    'data' => [
                        '1' => [
                            'email' => 'john.doe@punchkick.com',
                            'username' => 'johndoe555',
                        ],
                    ],
                ])),
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // error returned from delete request
                new RequestException(
                    'Server Error.',
                    new Request('POST', '/api/v1/admin/index'),
                    new Response(500)
                ),
                // get staff response
                new Response(200, [], json_encode([
                    'data' => [
                        '1' => [
                            'email' => 'john.doe@punchkick.com',
                            'username' => 'johndoe555',
                        ],
                    ],
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff');

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertContains('Support Staff', $crawler->filter('h1')->text());
        
        $deleteForm = $crawler->filter('#delete_staff_member_form')->parents()->eq(0);

        $deleteForm = $deleteForm->form();
        $deleteForm['delete_staff_member_form[id]'] = '1';
        $deleteForm['delete_staff_member_form[password]'] = 'somepass';

        $crawler = $client->submit($deleteForm);
        $this->assertContains('Support Staff', $crawler->filter('h1')->text());
        $this->assertContains('Unable to delete user.', $crawler->filter('.alert')->text());
    }

    public function testDeletesSuccessfully()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // get staff response
                new Response(200, [], json_encode([
                    'data' => [
                        '1' => [
                            'email' => 'john.doe@punchkick.com',
                            'username' => 'johndoe555',
                        ],
                    ],
                ])),
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // delete response
                new Response(200, [], json_encode([
                    'data' => true
                ])),
                // get staff response
                new Response(200, [], json_encode([
                    'data' => [
                        '1' => [
                            'email' => 'john.doe@punchkick.com',
                            'username' => 'johndoe555',
                        ],
                    ],
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff');

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertContains('Support Staff', $crawler->filter('h1')->text());
        
        $deleteForm = $crawler->filter('#delete_staff_member_form')->parents()->eq(0);

        $deleteForm = $deleteForm->form();
        $deleteForm['delete_staff_member_form[id]'] = '1';
        $deleteForm['delete_staff_member_form[password]'] = 'somepass';

        $crawler = $client->submit($deleteForm);
        $this->assertContains('Support Staff', $crawler->filter('h1')->text());
        $this->assertContains('Staff member deleted successfully.', $crawler->filter('.alert')->text());
    }
}

