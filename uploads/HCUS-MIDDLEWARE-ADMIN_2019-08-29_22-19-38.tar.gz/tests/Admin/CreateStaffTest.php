<?php

namespace tests\Admin;

use HomeCredit\Test\AbstractTestCase;
use GuzzleHttp\Client;
use Silex\Application;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\RequestException;

class CreateStaffTest extends AbstractTestCase
{
    public function testFormShows()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff/create');

        $this->assertTrue($client->getResponse()->isOk());
        
        $createForm = $crawler->filter('#create_staff_member_form');
        $this->assertCount(1, $createForm);
        $this->assertContains('Create Staff Member', $crawler->filter('h1')->text());
    }

    public function testShowsValidationErrors()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // submit form response with validation errors
                new RequestException(
                    'Bad Request.',
                    new Request('POST', '/api/v1/admin/index'),
                    new Response(400, [], json_encode([
                        'error' => [
                            'description' => [
                                '[email]' => 'Invalid email, friend',
                                '[username]' => 'Invalid username, friend',
                                '[role]' => 'Invalid role, friend',
                            ],
                        ],
                    ]))
                ),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff/create');

        $this->assertTrue($client->getResponse()->isOk());
        $createForm = $crawler->filter('#create_staff_member_form');
        $this->assertCount(1, $createForm);
        $this->assertContains('Create Staff Member', $crawler->filter('h1')->text());
        
        $form = $crawler->selectButton('Create')->form();
        $form['create_staff_member_form[email]'] = 'john.doe@punchkick.com';
        $form['create_staff_member_form[username]'] = 'johndoe555';
        $form['create_staff_member_form[role]'] = '2';

        $crawler = $client->submit($form);
        $this->assertTrue($client->getResponse()->isOk());
        $errors = $crawler->filter('.has-error .help-block li');
        $this->assertCount(3, $errors);
        $this->assertContains('Invalid email, friend', $errors->eq(0)->text());
        $this->assertContains('Invalid username, friend', $errors->eq(1)->text());
        $this->assertContains('Invalid role, friend', $errors->eq(2)->text());
    }

    public function testShowsServerError()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // submit form response with server error
                new RequestException(
                    'Bad Request.',
                    new Request('POST', '/api/v1/admin/index'),
                    new Response(500)
                ),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff/create');

        $this->assertTrue($client->getResponse()->isOk());
        $createForm = $crawler->filter('#create_staff_member_form');
        $this->assertCount(1, $createForm);
        $this->assertContains('Create Staff Member', $crawler->filter('h1')->text());
        
        $form = $crawler->selectButton('Create')->form();
        $form['create_staff_member_form[email]'] = 'john.doe@punchkick.com';
        $form['create_staff_member_form[username]'] = 'johndoe555';
        $form['create_staff_member_form[role]'] = '2';

        $crawler = $client->submit($form);
        $this->assertTrue($client->getResponse()->isOk());
        $errors = $crawler->filter('.alert');
        $this->assertCount(1, $errors);
        $this->assertContains('Unable to save your new password.', $errors->text());
    }

    public function testCreatesNewUserSuccessfully()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // refresh session
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // submit form response with success
                new Response(200, [], json_encode([
                    'data' => [
                        'id' => 1,
                        'email' => 'john.doe@punchkick.com',
                        'username' => 'johndoe555',
                        'role' => 2,
                        'password' => 'somepass',
                    ],
                ])),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_ADMINISTRATOR']);

        $crawler = $client->request('GET', '/support/staff/create');

        $this->assertTrue($client->getResponse()->isOk());
        $createForm = $crawler->filter('#create_staff_member_form');
        $this->assertCount(1, $createForm);
        $this->assertContains('Create Staff Member', $crawler->filter('h1')->text());
        
        $form = $crawler->selectButton('Create')->form();
        $form['create_staff_member_form[email]'] = 'john.doe@punchkick.com';
        $form['create_staff_member_form[username]'] = 'johndoe555';
        $form['create_staff_member_form[role]'] = '2';

        $crawler = $client->submit($form);
        $this->assertTrue($client->getResponse()->isOk());
        $successMessage = $crawler->filter('.alert');
        $this->assertCount(1, $successMessage);
        $this->assertContains('The new member\'s password will be:', $successMessage->text());
    }
}
