<?php

namespace tests\Customer;

use HomeCredit\Test\AbstractTestCase;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Client;
use Silex\Application;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Client as GuzzleClient;

class ResetCustomerPasswordTest extends AbstractTestCase
{
    public function testResetPasswordButtonShows()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'customer' =>  [ 
                            'id' => 1,
                            'type' => 'Primary',
                            'firstName' => 'John',
                            'lastName' => 'Doe',
                            'email' => 'john.doe@punchkick.com',
                            'created_at' => 1472668281,
                        ],
                    ]
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $crawler = $client->request('GET', '/customer/search');
        $this->assertTrue($client->getResponse()->isOk());

        // submit form
        $form = $crawler->selectButton('Search')->form();
        $form['customer_search_form[account_number]'] = '4111222233334444';

        $crawler = $client->submit($form);

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#reset-password-button'));
    }

    public function testResetPasswordAjaxCallReturnsValidationErrors()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $client->request('POST', '/customer/reset-password', ['email' => false]);
        $this->assertEquals(400, $client->getResponse()->getStatusCode());
        $this->assertContains('Please provide email', $client->getResponse()->getContent());
    }

    public function testResetPasswordAjaxCallReturnsInvalidEmailAddress()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new RequestException(
                    'Bad Request',
                    new Request('POST', '/api/v1/customer/resetpassword'),
                    new Response(400)
                ),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $client->request('POST', '/customer/reset-password', ['email' => 'john.doe@punchkick.com']);
        $this->assertEquals(400, $client->getResponse()->getStatusCode());
        $this->assertContains('Invalid email address', $client->getResponse()->getContent());
    }

    public function testResetPasswordAjaxRequestReturnsServerError()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new RequestException(
                    'Bad Request',
                    new Request('POST', '/api/v1/customer/resetpassword'),
                    new Response(500)
                ),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $client->request('POST', '/customer/reset-password', ['email' => 'john.doe@punchkick.com']);
        $this->assertEquals(500, $client->getResponse()->getStatusCode());
        $this->assertContains('Unable to complete your request', $client->getResponse()->getContent());
    }

    public function testResetPasswordAjaxRequestReturnsFalse()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => false,
                ]))
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });
        
        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $client->request('POST', '/customer/reset-password', ['email' => 'john.doe@punchkick.com']);
        $this->assertEquals(500, $client->getResponse()->getStatusCode());
        $this->assertContains('Server error', $client->getResponse()->getContent());
    }


    public function testResetPasswordAjaxRequestReturnsSuccess()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => true,
                ]))
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });
        
        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $client->request('POST', '/customer/reset-password', ['email' => 'john.doe@punchkick.com']);
        $this->assertEquals(202, $client->getResponse()->getStatusCode());
    }
}

