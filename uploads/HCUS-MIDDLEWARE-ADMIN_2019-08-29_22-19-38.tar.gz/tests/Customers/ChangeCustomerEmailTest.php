<?php

namespace tests\Customer;

use HomeCredit\Test\AbstractTestCase;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Client;
use Silex\Application;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Client as GuzzleClient;

class ChangeCustomerEmailTest extends AbstractTestCase
{
    public function testFormShown()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'customer' =>  [ 
                            'id' => 1,
                            'type' => 'Primary',
                            'firstName' => 'John',
                            'lastName' => 'Doe',
                            'email' => 'john.doe@punchkick.com',
                            'created_at' => 1472668281,
                        ],
                    ]
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $crawler = $client->request('GET', '/customer/search');
        $this->assertTrue($client->getResponse()->isOk());

        $form = $crawler->selectButton('Search')->form();
        $form['customer_search_form[account_number]'] = '4111222233334444';

        $crawler = $client->submit($form);

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#customer_email_form'));
    }

    public function testApiReturnsServerError()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'customer' =>  [ 
                            'id' => 1,
                            'type' => 'Primary',
                            'firstName' => 'John',
                            'lastName' => 'Doe',
                            'email' => 'john.doe@punchkick.com',
                            'created_at' => 1472668281,
                        ],
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // change password response
                new RequestException(
                    'Server Error.',
                    new Request('POST', '/api/v1/supporter/password'),
                    new Response(500, [], json_encode([
                        'data' => [
                            'error'
                        ]
                    ]))
                ),
                new Response(200, [], json_encode([
                    'data' => [
                        'customer' =>  [ 
                            'id' => 1,
                            'type' => 'Primary',
                            'firstName' => 'John',
                            'lastName' => 'Doe',
                            'email' => 'john.doe@punchkick.com',
                            'created_at' => 1472668281,
                        ],
                    ]
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });
        
        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $crawler = $client->request('GET', '/customer/search');
        $this->assertTrue($client->getResponse()->isOk());

        $form = $crawler->selectButton('Search')->form();
        $form['customer_search_form[account_number]'] = '4111222233334444';

        $crawler = $client->submit($form);

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#customer_email_form'));
        
        $form = $crawler->selectButton('Save')->form();
        $form['customer_email_form[id]'] = '1';
        $form['customer_email_form[account_number]'] = '4111222233334444';
        $form['customer_email_form[email]'] = 'john.doe@punchkick.com';
        $form['customer_email_form[password]'] = 'somepass';

        $crawler = $client->submit($form);
        $this->assertTrue($client->getResponse()->isOk());
        $this->assertContains('Unable to update user email.', $crawler->filter('.alert')->text());
    }

    public function testApiReturnsValidationMessages()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // load customer search page
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // perform search
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'customer' =>  [ 
                            'id' => 1,
                            'type' => 'Primary',
                            'firstName' => 'John',
                            'lastName' => 'Doe',
                            'email' => 'john.doe@punchkick.com',
                            'created_at' => 1472668281,
                        ],
                    ]
                ])),
                // perform change customer email 
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // change customer error response
                RequestException::create(
                    new Request('POST', '/api/v1/supporter/password'),
                    new Response(400, [], json_encode([
                        'error' => [
                            'description' => [
                                '[email]' => 'Invalid email, man',
                                '[password]' => 'Invalid password, man',
                            ],
                        ],
                    ]))
                ),
                // redo search
                new Response(200, [], json_encode([
                    'data' => [
                        'customer' =>  [ 
                            'id' => 1,
                            'type' => 'Primary',
                            'firstName' => 'John',
                            'lastName' => 'Doe',
                            'email' => 'john.doe@punchkick.com',
                            'created_at' => 1472668281,
                        ],
                    ]
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });
        
        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $crawler = $client->request('GET', '/customer/search');
        $this->assertTrue($client->getResponse()->isOk());

        $form = $crawler->selectButton('Search')->form();
        $form['customer_search_form[account_number]'] = '4111222233334444';

        $crawler = $client->submit($form);

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#customer_email_form'));
        
        $form = $crawler->selectButton('Save')->form();
        $form['customer_email_form[id]'] = '1';
        $form['customer_email_form[account_number]'] = '4111222233334444';
        $form['customer_email_form[email]'] = 'john.doe@punchkick.com';
        $form['customer_email_form[password]'] = 'somepass';

        $crawler = $client->submit($form);

        $this->assertTrue($client->getResponse()->isOk());
        $alerts = $crawler->filter('.has-error .help-block li');
        $this->assertCount(2, $alerts);
        $this->assertContains('Invalid email, man', $alerts->eq(0)->text());
        $this->assertContains('Invalid password, man', $alerts->eq(1)->text());
    }

    public function testEmailChangedSuccessfully()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                // load customer search page
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // perform search
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'customer' =>  [ 
                            'id' => 1,
                            'type' => 'Primary',
                            'firstName' => 'John',
                            'lastName' => 'Doe',
                            'email' => 'john.doe@punchkick.com',
                            'created_at' => 1472668281,
                        ],
                    ]
                ])),
                // perform change customer email 
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                // change customer successful response
                new Response(200, [], json_encode([
                    'data' => true
                ])),
                // redo search
                new Response(200, [], json_encode([
                    'data' => [
                        'customer' =>  [ 
                            'id' => 1,
                            'type' => 'Primary',
                            'firstName' => 'John',
                            'lastName' => 'Doe',
                            'email' => 'john.doe@punchkick.com',
                            'created_at' => 1472668281,
                        ],
                    ]
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });
        
        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $crawler = $client->request('GET', '/customer/search');
        $this->assertTrue($client->getResponse()->isOk());

        $form = $crawler->selectButton('Search')->form();
        $form['customer_search_form[account_number]'] = '4111222233334444';

        $crawler = $client->submit($form);

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#customer_email_form'));
        
        $form = $crawler->selectButton('Save')->form();
        $form['customer_email_form[id]'] = '1';
        $form['customer_email_form[account_number]'] = '4111222233334444';
        $form['customer_email_form[email]'] = 'john.doe@punchkick.com';
        $form['customer_email_form[password]'] = 'somepass';

        $crawler = $client->submit($form);

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(0, $crawler->filter('.has-error .help-block li'));
        $this->assertCount(0, $crawler->filter('.alert-danger'));
        $successAlert = $crawler->filter('.alert-success');
        $this->assertCount(1, $successAlert);
        $this->assertContains('Customer email address updated successfully', $successAlert->text());
    }

}
