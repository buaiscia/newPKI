<?php

namespace tests\Customer;


use HomeCredit\Test\AbstractTestCase;
use GuzzleHttp\Client;
use Silex\Application;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\RequestException;

class SearchTest extends AbstractTestCase
{
    public function testShowsSearchFormAndValidationErrors()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new RequestException(
                    'Server Error.',
                    new Request('POST', '/api/v1/supporter/customer?account_number=4111222233334444'),
                    new Response(400)
                ),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new RequestException(
                    'Server Error.',
                    new Request('POST', '/api/v1/supporter/customer?account_number=4111222233334444'),
                    new Response(403)
                ),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();

        $this->loginAs(['ROLE_SUPPORTER']);

        // testing 400 returned from search
        $crawler = $client->request('GET', '/customer/search');

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#customer_search_form'));

        $form = $crawler->selectButton('Search')->form();
        $form['customer_search_form[account_number]'] = '4111222233334444';

        $crawler = $client->submit($form);
        $this->assertTrue($client->getResponse()->isOk());
        $alert = $crawler->filter('.alert');
        $this->assertCount(1, $alert);
        $this->assertContains('Account number not found', $alert->eq(0)->text());
    }

    public function test403ReturnedFromSearch()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new RequestException(
                    'Server Error.',
                    new Request('POST', '/api/v1/supporter/customer?account_number=4111222233334444'),
                    new Response(400)
                ),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new RequestException(
                    'Server Error.',
                    new Request('POST', '/api/v1/supporter/customer?account_number=4111222233334444'),
                    new Response(403)
                ),
            ]);
            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        // testing 403 returned from search
        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);
        
        $crawler = $client->request('GET', '/customer/search');

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertCount(1, $crawler->filter('#customer_search_form'));

        $form = $crawler->selectButton('Search')->form();
        $form['customer_search_form[account_number]'] = '4111222233334444';

        $crawler = $client->submit($form);
        
        $this->assertTrue($client->getResponse()->isOk());
        $alert = $crawler->filter('.alert');
        $this->assertCount(1, $alert);
        $this->assertContains('Account number not found', $alert->eq(0)->text());
    }

    public function testSearchShowsCustomerData()
    {
        $this->app->extend('app.client.api', function (Client $client, Application $app) {
            $mockHandler = new MockHandler([
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'access_token' => 'access_token',
                        'refresh_token' => 'refresh_token',
                        'ikm' => 'ikm',
                        'expires_at' => time(),
                    ]
                ])),
                new Response(200, [], json_encode([
                    'data' => [
                        'customer' =>  [ 
                            'id' => 1,
                            'type' => 'Primary',
                            'firstName' => 'John',
                            'lastName' => 'Doe',
                            'email' => 'john.doe@punchkick.com',
                            'created_at' => 1472668281,
                        ],
                    ]
                ])),
            ]);

            return new GuzzleClient([
                'handler' => $mockHandler,
            ]);
        });

        $client = $this->createClient();
        $this->loginAs(['ROLE_SUPPORTER']);

        $crawler = $client->request('GET', '/customer/search');
        $this->assertTrue($client->getResponse()->isOk());
        
        // submit form
        $form = $crawler->selectButton('Search')->form();
        $form['customer_search_form[account_number]'] = '4111222233334444';

        $crawler = $client->submit($form);

        $this->assertTrue($client->getResponse()->isOk());
        $this->assertContains('Customer', $crawler->filter('h2')->eq(1)->text());
        $this->assertContains('John', $crawler->filter('#customer-definition dd')->eq(0)->text());
        $this->assertContains('Doe', $crawler->filter('#customer-definition dd')->eq(1)->text());
        $this->assertContains('john.doe@punchkick.com', $crawler->filter('#customer-definition dd')->eq(2)->text());
        $this->assertContains('08/31/2016', $crawler->filter('#customer-definition dd')->eq(3)->text());
        $this->assertContains('Change Email', $crawler->filter('h2')->eq(2)->text());
    }
}
