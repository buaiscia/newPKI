<?php
namespace tests\API;

use GuzzleHttp\Exception\RequestException;
use HomeCredit\Test\AbstractTestCase;

class ConnectionTest extends AbstractTestCase
{
    public function testCanConnect()
    {
        try {
            $this->app['app.client.api']->get('/');
        } catch (RequestException $e) {
            $this->assertEquals(404, $e->getCode());
            $this->assertEquals(
                '{"data":null,"error":{"status":404,"description":"No route found for \u0022GET \/\u0022"}}',
                $e->getResponse()->getBody()->getContents()
            );
            $this->assertEquals('application/json', $e->getResponse()->getHeader('CONTENT-TYPE')[0]);
        }
    }
}
