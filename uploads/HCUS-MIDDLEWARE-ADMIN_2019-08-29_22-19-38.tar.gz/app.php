<?php

use HomeCredit\Provider\Controller\AdminControllerProvider;
use HomeCredit\Provider\Controller\AuthControllerProvider;
use HomeCredit\Provider\Controller\CustomerControllerProvider;
use HomeCredit\Provider\Controller\LPFConfigControllerProvider;
use HomeCredit\Provider\Controller\ProductControllerProvider;
use HomeCredit\Provider\Controller\ResendWelcomeMessageControllerProvider;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

require_once __DIR__ . '/vendor/autoload.php';
$app = require __DIR__ . '/config/bootstrap.php';

// Routes
$app->mount('/', new AuthControllerProvider());
$app->mount('/customer', new CustomerControllerProvider());
$app->mount('/resend_welcome_message', new ResendWelcomeMessageControllerProvider());
$app->mount('/support', new AdminControllerProvider());
$app->mount('/product', new ProductControllerProvider());
$app->mount('/lpf_config', new LPFConfigControllerProvider());

// Error handler
$app->error(function (Exception $e, Request $request, $code) use ($app) {
    if (!$app['debug']) { // if in debug mode, use the normal error handler
        if ($e instanceof NotFoundHttpException) { // 404
            $template = '404.html.twig';
        } else { // 500
            $template = '500.html.twig';
        }

        return $app['twig']->render($template, [
            'code' => $e->getCode(),
        ]);
    }
});

$app->after(function (Request $request, Response $response, Application $app) {
    $response->headers->set('Pragma', 'no-cache');
    $response->headers->set('Cache-Control', 'no-cache, private');
});

return $app;
