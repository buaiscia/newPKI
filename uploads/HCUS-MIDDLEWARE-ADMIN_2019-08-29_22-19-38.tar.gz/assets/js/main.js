'use strict';

import "../styles/style";
import "bootstrap-sass/assets/javascripts/bootstrap";
import TimeoutWarning from "./modules/timeout-warning";
import ResetCustomerPassword from "./modules/reset-customer-password";
import SupporterSearchForm from "./modules/supporter-search-form";
import SupporterDelete from "./modules/supporter-delete";
import ActivateUser from "./modules/activate-user";
import ValidateUserEmail from "./modules/validate-user-email";
import "./modules/manage-product-rewards";
import "./modules/manage-lpf-configs";
// global timeout warning, triggered after 12 min of inactivity
new TimeoutWarning(
    document.getElementById('timeout-warning-modal'),
    document.getElementById('timeout-warning-timer')
);

// supporter button to reset a customer's password
let confirmationModal = document.getElementById('confirmation-modal'),
    resetPasswordButton = document.getElementById('reset-password-button');
if (resetPasswordButton) {
    let customerDefinition = document.getElementById('customer-definition');

    if (confirmationModal && customerDefinition) {
        new ResetCustomerPassword(
            resetPasswordButton,
            confirmationModal,
            customerDefinition.dataset.username
        );
    }
}

let activateUserButton = document.getElementById('activate-user-button');
if (activateUserButton) {
    let customerDefinition = document.getElementById('customer-definition');
    new ActivateUser(activateUserButton, customerDefinition.dataset.id);
}

// Email validatation
let emailValidateButton = document.getElementById('validate-user-email-button');
if (emailValidateButton && confirmationModal) {
    let customerDefinition = document.getElementById('customer-definition');
    new ValidateUserEmail(emailValidateButton, confirmationModal, customerDefinition.dataset.id);
}

// admin button to flip to the next page of supporters
let supporterSearchForm = document.getElementById('supporter-search-form');
if (supporterSearchForm) {
    let prevSupporterPage = document.getElementById('prev-supporter-page'),
        nextSupporterPage = document.getElementById('next-supporter-page'),
        searchInput = document.getElementById('supporter_search_form_keyword'),
        submitButton = document.getElementById('supporter-search-submit'),
        pageInput = document.getElementById('supporter_search_form_page');

    if ((nextSupporterPage || prevSupporterPage) && pageInput && searchInput) {
        new SupporterSearchForm(prevSupporterPage, nextSupporterPage, searchInput, pageInput, submitButton, supporterSearchForm);
    }
}


let supporterDeleteModal = document.getElementById('delete-member-modal');

let deleteIdField = null;
if (document.querySelector('.lpf-config-page')) {
    deleteIdField = document.getElementById('delete_lpf_config_form_id');
} else {
    deleteIdField = document.getElementById('delete_staff_member_form_id');
}

if (deleteIdField) {
    let supporterDeleteButtons = document.querySelectorAll('.member-delete-btn');
    new SupporterDelete(supporterDeleteButtons, supporterDeleteModal, deleteIdField);
}