if (document.querySelector('.product-page .exclusions-list')) {

    const exclusionsListElement = document.querySelector('.product-page .exclusions-list');
    const criteriaListElement = document.querySelector('.product-page .criteria-list');
    const rewardsTranslationsElement = document.querySelector('.product-page .rewards_translations');
    const partnerIDTranslationsElement = document.querySelector('.product-page .partner_id_translations');

    const updateCriteriaListCount = () => {
        criteriaListElement.dataset.current_count = criteriaListElement.dataset.current_count ? criteriaListElement.dataset.current_count : document.querySelectorAll('.product-page .criteria-list input').length;
        criteriaListElement.dataset.current_count = parseInt(criteriaListElement.dataset.current_count, 10) + 1;
    };

    const updateExclusionsListCount = () => {
        exclusionsListElement.dataset.current_count = exclusionsListElement.dataset.current_count ? exclusionsListElement.dataset.current_count : document.querySelectorAll('.product-page .exclusions-list input').length;
        exclusionsListElement.dataset.current_count = parseInt(exclusionsListElement.dataset.current_count, 10) + 1;
    };

    const updateTranslationsListCount = () => {
        rewardsTranslationsElement.dataset.current_count = rewardsTranslationsElement.dataset.current_count ? rewardsTranslationsElement.dataset.current_count : document.querySelectorAll('.product-page .rewards_translations input').length;
        rewardsTranslationsElement.dataset.current_count = parseInt(rewardsTranslationsElement.dataset.current_count, 10) + 1;
    };

    const updateProgramIDTranslationsListCount = () => {
        partnerIDTranslationsElement.dataset.current_count = partnerIDTranslationsElement.dataset.current_count ? partnerIDTranslationsElement.dataset.current_count : document.querySelectorAll('.product-page .partner_id_translations input').length;
        partnerIDTranslationsElement.dataset.current_count = parseInt(partnerIDTranslationsElement.dataset.current_count, 10) + 1;
    };

    updateExclusionsListCount();
    updateCriteriaListCount();
    updateTranslationsListCount();
    updateProgramIDTranslationsListCount();

    // activate delete buttons
    const addRemoveEventListeners = () => {
        document.querySelectorAll('.product-page .delete-button').forEach(button => {
            button.addEventListener("click", ({ target }) => {
                target.parentNode.parentNode.remove();
            });
        });
    };

    addRemoveEventListeners();

    // activate 'add new exclusion' buttons
    // user a template provided by symfony to generate the "widget"
    document.querySelector('.product-page #update_product_form_rewards_exclusions .add-new').addEventListener("click", ({ target }) => {
        const div = document.createElement('div');
        div.innerHTML = `
            <div class="row no-margin-top">
                <div class="col-xs-12 col-sm-6 dynamic-input">
                    ${document.querySelector('#update_product_form_rewards_exclusions').dataset.prototype}
                    <div class="delete-button"></div>
                </div>
            </div>
        ` ;
        ;
        div.innerHTML = div.innerHTML.replace(/__name__/g, exclusionsListElement.dataset.current_count);
        exclusionsListElement.appendChild(div.firstElementChild);
        updateExclusionsListCount();
        addRemoveEventListeners();
    });

    // activate 'add new criteria' buttons
    // user a template provided by symfony to generate the "widget"
    document.querySelector('.product-page #update_product_form_rewards_criteria .add-new').addEventListener("click", ({ target }) => {
        const div = document.createElement('div');
        div.innerHTML = `
            <div class="row no-margin-top">
                <div class="col-xs-12 col-sm-6 dynamic-input">
                    ${document.querySelector('#update_product_form_rewards_criteria').dataset.prototype}
                    <div class="delete-button"></div>
                </div>
            </div>
        ` ;
        ;
        div.innerHTML = div.innerHTML.replace(/__name__/g, criteriaListElement.dataset.current_count);
        criteriaListElement.appendChild(div.firstElementChild);
        updateCriteriaListCount();
        addRemoveEventListeners();
    });

    document.querySelector('.product-page #update_product_form_rewards_translations .add-new').addEventListener("click", ({ target }) => {
        const div = document.createElement('div');
        div.innerHTML = `
            <div class="row no-margin-top">
                <div class="col-xs-12 col-sm-6 dynamic-input">
                    ${document.querySelector('#update_product_form_rewards_translations').dataset.prototype}
                    <div class="delete-button"></div>
                </div>
            </div>
        ` ;
        ;
        div.innerHTML = div.innerHTML.replace(/__name__/g, rewardsTranslationsElement.dataset.current_count);
        rewardsTranslationsElement.appendChild(div.firstElementChild);

        updateTranslationsListCount();
        addRemoveEventListeners();
    });

    document.querySelector('.product-page #update_product_form_partner_id_translations .add-new').addEventListener("click", ({ target }) => {
        const div = document.createElement('div');
        div.innerHTML = `
            <div class="row no-margin-top">
                <div class="col-xs-12 col-sm-6 dynamic-input">
                    ${document.querySelector('#update_product_form_partner_id_translations').dataset.prototype}
                    <div class="delete-button"></div>
                </div>
            </div>
        ` ;
        ;
        div.innerHTML = div.innerHTML.replace(/__name__/g, partnerIDTranslationsElement.dataset.current_count);
        partnerIDTranslationsElement.appendChild(div.firstElementChild);

        updateProgramIDTranslationsListCount();
        addRemoveEventListeners();
    });

    // change password field type to password
    document.querySelector('#create_product_form_sms_password, #update_product_form_sms_password').type = 'password';
}