'use strict';

import $ from 'jquery';

let customerId;
let button;
export default class ActivateUser {
    constructor(btn, id) {
        customerId = id;
        button = btn;
        button.addEventListener('click', e => this.activate(e));
    }

    activate(e) {
        button.innerHTML = `<i class="glyphicon glyphicon-refresh gly-spin"></i> Activate User`;
        $.ajax({
            type: 'POST',
            url: '/customer/activate',
            data: {
                id: customerId
            }
        }).then(function () {
            document.querySelector("#customer_search_form_search").click();
        }, function (response) {
            button.innerHTML = `<i class="glyphicon glyphicon-exclamation-sign"></i> Activate User`;
            button.className = button.className.replace(/button-danger/, 'button-danger');
        }).complete(function() {
            button.innerHTML = `Activate User`;
        })
    }
}
