'use strict';

let modalElm;
let timerElm;

export default class TimeoutWarning {

    constructor(inputModalElm, inputTimerElm) {
        modalElm = inputModalElm;
        timerElm = inputTimerElm;

        this.startTimer();
    }

    startTimer() {
        window.setTimeout(this.showDialog.bind(this), 720e3); // 720s = 12m
    }

    showDialog() {
        $(modalElm).modal();

        this.startTimerDisplay();
        this.startRefreshTimer();
    }

    startTimerDisplay() {
        window.setTimeout(function () {
            $(timerElm).text('2 minutes');
        }, 60e3); // 1 min
        window.setTimeout(function () {
            $(timerElm).text('1 minute');
        }, 120e3); // 2 min
    }

    startRefreshTimer() {
        window.setTimeout(function () {
            location.reload();
        }, 180e3); // 3 min
    }

}