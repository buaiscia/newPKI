'use strict';

let button;
let modal;
let username;
let openDialogListener;

export default class ResetCustomerPassword {

    constructor(inputButton, inputModal, inputUsername) {
        button = inputButton;
        modal = inputModal;
        username = inputUsername;

        openDialogListener = e => this.openDialog(e);
        button.addEventListener('click', openDialogListener);
    }

    openDialog(e) {
        // replace confirm button to be sure there aren't multiple click events
        let confirmButton = modal.querySelector('.confirmation-confirm-button');
        let confirmButtonClone = confirmButton.cloneNode(true);
        confirmButtonClone.addEventListener('click', e => this.confirmReset(e));
        confirmButton.parentNode.replaceChild(confirmButtonClone, confirmButton);

        modal.querySelector('.modal-body')
            .textContent = 'The customer will receive an email with instructions on how to reset their password.';

        $(modal).modal();
    }

    confirmReset(e) {
        // disable the button and use it as a success indicator
        button.removeEventListener('click', openDialogListener);
        button.innerHTML = `<i class="glyphicon glyphicon-envelope"></i> Sending Email`;
        button.className = button.className.replace(/btn-default/, 'btn-danger');

        $.ajax({
            type: 'POST',
            url: '/customer/reset-password',
            data: {
                username: username
            }
        }).then(function () {
            button.innerHTML = `<i class="glyphicon glyphicon-ok"></i> Email Sent`;
            button.className = button.className.replace(/btn-danger/, 'btn-success');
        }, function (response) {
            button.innerHTML = `<i class="glyphicon glyphicon-exclamation-sign"></i> ${response.responseJSON.error}`;
            button.className = button.className.replace(/btn-danger/, 'btn-primary');
        });

        $(modal).modal('hide');
    }

}