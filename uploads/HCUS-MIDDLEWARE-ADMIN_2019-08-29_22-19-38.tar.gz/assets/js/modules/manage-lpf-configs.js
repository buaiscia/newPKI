const toggleLpfcontainerFlags = (target, valuesContianers, configContainer) => {
    if (target.checked) {
        valuesContianers.forEach(item => item.classList.remove("hidden"));
        configContainer.classList.add("config-on");
    } else {
        valuesContianers.forEach(item => item.classList.add("hidden"));
        configContainer.classList.remove("config-on");
    }
};

const initLpfCongigEnableCheckboxes = () => {
    document.querySelectorAll(".config-container").forEach(configContainer => {
        let valuesEnableCheckbox = configContainer.querySelector(".checkbox input");
        let valuesContianers = configContainer.querySelectorAll(".config-values");

        toggleLpfcontainerFlags(valuesEnableCheckbox, valuesContianers, configContainer);
        valuesEnableCheckbox.addEventListener("click", ({ target }) => toggleLpfcontainerFlags(target, valuesContianers, configContainer));
    });
};

if (document.querySelector('.lpf-config-page .edit-lpf-config')) {
    initLpfCongigEnableCheckboxes();
}

