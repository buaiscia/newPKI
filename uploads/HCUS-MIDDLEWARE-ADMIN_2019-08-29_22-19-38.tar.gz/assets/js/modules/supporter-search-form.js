'use strict';

let pageInput,
    form;

/**
 * This class adds event listeners to the next and previous page buttons.
 * When clicked, they'll increment a page input field and then submit the
 * search form.
 *
 * Why don't you just use query parameters for search and page?
 * Because it's sensitive data like email addresses and i don't think it should
 * show up in the browser history
 */
export default class SupporterSearchForm {

    constructor(prevButton, nextButton, searchInput, inputPageInput, submitButton, searchForm) {
        if (prevButton) {
            prevButton.addEventListener('click', () => this.prevPage());
        }
        if (nextButton) {
            nextButton.addEventListener('click', () => this.nextPage());
        }

        // if user presses enter to submit form while in the search field, reset page number to 1
        searchInput.addEventListener('keydown', (e) => this.searchInputKeyPress(e));

        // if user directly presses the submit button, reset page number to 1
        submitButton.addEventListener('click', () => this.resetPage());

        form = searchForm;
        pageInput = inputPageInput;
    }

    submitForm() {
        form.submit();
    }

    resetPage() {
        pageInput.value = 1;
    }

    searchInputKeyPress(e) {
        if (e.keyCode == 13) {
            this.resetPage();
        }
    }

    prevPage() {
        let newPage = Number(pageInput.value) - 1;
        if (!newPage) {
            newPage = 1;
        }
        pageInput.value = newPage;

        this.submitForm();
    }

    nextPage() {
        pageInput.value = Number(pageInput.value) + 1;

        this.submitForm();
    }
}