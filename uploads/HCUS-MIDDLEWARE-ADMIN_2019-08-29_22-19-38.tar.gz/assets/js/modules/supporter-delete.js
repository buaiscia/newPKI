'use strict';

import $ from 'jquery';


let modal;
let idField;

export default class SupporterDelete {
    constructor(deleteButtons, inputModal, inputIdField) {
        modal = inputModal;
        idField = inputIdField;

        for (let i=0; i < deleteButtons.length; i++) {
            deleteButtons[i].addEventListener('click', (e, button) => this.openModal(e, deleteButtons[i]));
        }
    }

    openModal(e, button) {
        e.preventDefault();

        idField.value = button.dataset.id;

        $(modal).modal();
    }
}
