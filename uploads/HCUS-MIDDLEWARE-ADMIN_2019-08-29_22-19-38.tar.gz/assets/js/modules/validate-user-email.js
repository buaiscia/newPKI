'use strict';

let button;
let modal;
let customerId;
let openDialogListener;

export default class ValidateUserEmail {

    constructor(inputButton, inputModal, id) {
        button = inputButton;
        modal = inputModal;
        customerId = id;

        openDialogListener = e => this.openDialog(e);
        button.addEventListener('click', openDialogListener);
    }

    openDialog(e) {
        // replace confirm button to be sure there aren't multiple click events
        let confirmButton = modal.querySelector('.confirmation-confirm-button');
        let confirmButtonClone = confirmButton.cloneNode(true);
        confirmButtonClone.addEventListener('click', e => this.confirmReset(e));
        confirmButton.parentNode.replaceChild(confirmButtonClone, confirmButton);

        modal.querySelector('.modal-body')
            .textContent = `The customer's email will be set as validated.`;

        $(modal).modal();
    }

    confirmReset(e) {
        // disable the button and use it as a success indicator
        button.removeEventListener('click', openDialogListener);
        button.innerHTML = `<i class="glyphicon glyphicon-refresh gly-spin"></i> Validating Email`;
        button.className = button.className.replace(/btn-default/, 'btn-danger');

        $.ajax({
            type: 'POST',
            url: '/customer/emailValidate',
            data: {
                id: customerId
            }
        }).then(function (response) {
            button.innerHTML = `<i class="glyphicon glyphicon-ok"></i> Email Validated`;
            button.className = button.className.replace(/btn-danger/, 'btn-success');
        }, function (response) {
            button.innerHTML = `<i class="glyphicon glyphicon-exclamation-sign"></i> ${response.responseJSON.error}`;
            button.className = button.className.replace(/btn-danger/, 'btn-primary');
        });

        $(modal).modal('hide');
    }
}
