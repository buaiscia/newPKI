<?php

/** @var \Silex\Application $app */
$app = require_once dirname(__DIR__) . '/app.php';

$app->run();