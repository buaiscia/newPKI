<?php

namespace HomeCredit\Provider\Controller;

use HomeCredit\Controller\CustomerController;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;

/**
 * Class CustomerControllerProvider
 * @package HomeCredit\Provider\Controller
 */
class CustomerControllerProvider implements ControllerProviderInterface
{
    /**
     * @param Application $app
     * @return mixed|ControllerCollection
     */
    public function connect(Application $app)
    {
        $app['app.controller.customer'] = function (Application $app) {
            return new CustomerController(
                $app['logger'],
                $app['app.repo.api'],
                $app['app.form.customer_search'],
                $app['app.form.customer_email'],
                $app['twig']
            );
        };

        $factory = $app['controllers_factory'];

        $factory->match('search', 'app.controller.customer:search')
            ->method('GET|POST')
            ->bind('customer_search');

        $factory->post('reset-password', 'app.controller.customer:resetPassword')
            ->bind('customer_password_reset');

        $factory->post('activate', 'app.controller.customer:activate')
            ->bind('customer_activate');
            
        $factory->post('emailValidate', 'app.controller.customer:emailValidate')
            ->bind('validate_email');
        return $factory;
    }
}
