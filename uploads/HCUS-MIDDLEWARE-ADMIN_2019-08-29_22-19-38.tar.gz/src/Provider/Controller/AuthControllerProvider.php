<?php

namespace HomeCredit\Provider\Controller;

use HomeCredit\Controller\AuthController;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;

class AuthControllerProvider implements ControllerProviderInterface
{

    /**
     * {@inheritdoc}
     */
    public function connect(Application $app)
    {
        $app['app.controller.auth'] = function (Application $app) {
            return new AuthController(
                $app['app.repo.api'],
                $app['twig'],
                $app['logger'],
                $app['app.form.login'],
                $app['app.form.profile'],
                $app['app.form.reset'],
                $app['url_generator']
            );
        };

        $controllers = $app['controllers_factory'];

        $controllers->match('/', 'app.controller.auth:login')
            ->method('GET|POST')
            ->bind('auth_login');

        $controllers->match('/reset', 'app.controller.auth:reset')
            ->method('GET|POST')
            ->bind('auth_reset');

        $controllers->match('/profile', 'app.controller.auth:profile')
            ->method('GET|POST')
            ->bind('auth_profile');

        return $controllers;
    }
}