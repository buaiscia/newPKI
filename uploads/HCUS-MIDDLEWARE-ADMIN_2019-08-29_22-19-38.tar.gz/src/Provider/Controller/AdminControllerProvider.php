<?php

namespace HomeCredit\Provider\Controller;

use HomeCredit\Controller\AdminController;
use Pimple\Container;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;

class AdminControllerProvider implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $app['app.controller.admin'] = function (Container $app) {
            return new AdminController($app['app.repo.api'], $app['form.factory'], $app['twig'], $app['user']);
        };

        $controllers = $app['controllers_factory'];

        $controllers->match('/staff', 'app.controller.admin:staff')
            ->method('GET|POST')
            ->bind('admin_staff');

        $controllers->match('/staff/create', 'app.controller.admin:createSupporter')
            ->method('GET|POST')
            ->bind('admin_create');

        $controllers->match('/staff/{id}', 'app.controller.admin:updateStaffMember')
            ->assert('id', '\d+') // id must be numbers only
            ->method('GET|POST')
            ->bind('admin_staff_update');

        return $controllers;
    }

}
