<?php

namespace HomeCredit\Provider\Controller;

use HomeCredit\Controller\ResendWelcomeMessageController;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;
use Silex\ControllerCollection;

/**
 * Class ResendWelcomeMessageControllerProvider
 * @package HomeCredit\Provider\Controller
 */
class ResendWelcomeMessageControllerProvider implements ControllerProviderInterface
{
    /**
     * @param Application $app
     * @return mixed|ControllerCollection
     */
    public function connect(Application $app)
    {
        $app['app.controller.resend_welcome_message'] = function (Application $app) {
            return new ResendWelcomeMessageController(
                $app['logger'],
                $app['app.repo.api'],
                $app['app.form.resend_welcome_message'],
                $app['twig']
            );
        };

        $factory = $app['controllers_factory'];

        $factory->match('', 'app.controller.resend_welcome_message:search')
            ->method('GET|POST')
            ->bind('resend_welcome_message');
        return $factory;
    }
}
