<?php

namespace HomeCredit\Provider\Controller;

use HomeCredit\Controller\ProductController;
use Pimple\Container;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;

class ProductControllerProvider implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $app['app.controller.product'] = function (Container $app) {
            return new ProductController($app['app.repo.api'], $app['form.factory'], $app['twig']);
        };

        $controllers = $app['controllers_factory'];

        $controllers->match('/', 'app.controller.product:product')
            ->method('GET')
            ->bind('products');

        $controllers->match('/create', 'app.controller.product:createProduct')
            ->method('GET|POST')
            ->bind('product_create');

        $controllers->match('/{id}', 'app.controller.product:updateProduct')
            ->assert('id', '\d+') // id must be numbers only
            ->method('GET|POST')
            ->bind('product_update');

        return $controllers;
    }

}
