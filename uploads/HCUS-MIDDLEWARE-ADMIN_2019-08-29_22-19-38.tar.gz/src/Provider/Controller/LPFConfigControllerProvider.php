<?php

namespace HomeCredit\Provider\Controller;

use HomeCredit\Controller\LpfConfigController;
use Pimple\Container;
use Silex\Api\ControllerProviderInterface;
use Silex\Application;

class LPFConfigControllerProvider implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $app['app.controller.lpf_config'] = function (Container $app) {
            return new LpfConfigController($app['app.repo.api'], $app['form.factory'], $app['twig']);
        };

        $controllers = $app['controllers_factory'];

        $controllers->match('/', 'app.controller.lpf_config:listLpfConfigs')
            ->method('GET|POST')
            ->bind('lpf_config');

        $controllers->match('/create', 'app.controller.lpf_config:createLpfConfig')
            ->method('GET|POST')
            ->bind('lpf_config_create');

        $controllers->match('/{id}', 'app.controller.lpf_config:updateLpfConfig')
            ->assert('id', '\d+') // id must be numbers only
            ->method('GET|POST')
            ->bind('lpf_config_update');

        return $controllers;
    }
}
