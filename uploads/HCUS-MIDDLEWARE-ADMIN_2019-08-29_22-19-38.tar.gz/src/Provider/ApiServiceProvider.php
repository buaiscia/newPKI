<?php

namespace HomeCredit\Provider;

use GuzzleHttp\Client;
use GuzzleHttp\RequestOptions;
use GuzzleHttp\MessageFormatter;
use GuzzleHttp\Middleware;
use HomeCredit\Repository\ApiRepository;
use HomeCredit\Security\User;
use Pimple\Container;
use Pimple\ServiceProviderInterface;
use Concat\Http\Middleware\Logger;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Handler\CurlHandler;
use Psr\Log\LogLevel;

/**
 * Class ApiServiceProvider
 * @package HomeCredit\Provider
 */
class ApiServiceProvider implements ServiceProviderInterface
{
    /**
     * @param Container $app
     */
    public function register(Container $app)
    {
        // request logging middleware
        $app['app.client.api.logger'] = function (Container $app) {
            return new Logger($app['logger']);
        };
        
        // request handler stack
        $app['app.client.api.handler_stack'] = function (Container $app) {
            $handlerStack = HandlerStack::create();

            $handlerStack->push(
                Middleware::log(
                    $app['logger'],
                    new MessageFormatter('Guzzle Sent: {method} {uri} {req_headers} | Server Returned: {code}'),
                    LogLevel::DEBUG
                )
            );

            return $handlerStack;
        };

        // guzzle client
        $app['app.client.api'] = function (Container $app) {
            return new Client([
                'handler' => $app['app.client.api.handler_stack'],
                'base_uri' => $app['config']['api']['base_uri'],
                'timeout' => $app['config']['api']['timeout'],
                 RequestOptions::VERIFY => $app['config']['api']['tls_verify'],
            ]);
        };

        // api repo
        $app['app.repo.api'] = function (Container $app) {
            return new ApiRepository(
                $app['logger'],
                $app['security.token_storage'],
                $app['app.client.api']
            );
        };
    }
}
