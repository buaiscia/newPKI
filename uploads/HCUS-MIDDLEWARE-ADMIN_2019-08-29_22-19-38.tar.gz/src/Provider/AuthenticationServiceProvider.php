<?php

namespace HomeCredit\Provider;

use HomeCredit\FormType\LoginFormType;
use HomeCredit\FormType\ResetFormType;
use HomeCredit\Security\FormAuthenticator;
use HomeCredit\Security\RefreshTokenAuthenticator;
use HomeCredit\Security\UserProvider;
use Pimple\Container;
use Pimple\ServiceProviderInterface;
use Silex\Provider\SecurityServiceProvider;
use Silex\Provider\SessionServiceProvider;

class AuthenticationServiceProvider implements ServiceProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function register(Container $app)
    {
        $app->register(
            new SessionServiceProvider(),
            [
                'session.storage.options' => [
                    'cookie_httponly' => true,
                    'cookie_domain' => \parse_url($_SERVER['SERVER_NAME'], PHP_URL_HOST),
                    'cookie_lifetime' => 900, // Force the session to expire after 15 minutes to keep it in-line with the SAML session
                    'cookie_secure' => true,
                    'name' => 'HomeCreditUS-Admin',
                ],
                'session.storage.handler' => null,
            ]
        );

        $app->register(
            new SecurityServiceProvider(), [
                'security.firewalls' => [
                    'main' => [
                        'anonymous' => true,
                        'guard' => [
                            'authenticators' => [
                                'app.security.form_authenticator',
                                'app.security.refresh_token_authenticator',
                            ],
                            'entry_point' => 'app.security.form_authenticator',
                        ],
                        'users' => function (Container $app) {
                            return new UserProvider($app['app.repo.api'], $app['logger'], $app['session']);
                        },
                        'logout' => [
                            'logout_path' => '/logout',
                            'invalidate_session' => true,
                        ],
                    ]
                ]
            ]
        );

        $app['security.role_hierarchy'] = [
            'ROLE_SUPPORTER' => ['ROLE_AUTHENTICATED'],
            'ROLE_ADMINISTRATOR' => ['ROLE_AUTHENTICATED'],
            'ROLE_SUPERVISOR' => ['ROLE_AUTHENTICATED'],
        ];

        $app['security.access_rules'] = [
            ['^/customer', 'ROLE_SUPPORTER'],
            ['^/admin', 'ROLE_ADMINISTRATOR'],
            ['^/admin', 'ROLE_SUPERVISOR'],
            ['^/profile', 'ROLE_AUTHENTICATED'],
            ['^/(reset)?$', 'IS_AUTHENTICATED_ANONYMOUSLY'], // login/reset pages
        ];

        $app['app.security.form_authenticator'] = function (Container $app) {
            return new FormAuthenticator(
                $app['app.repo.api'],
                $app['logger'],
                $app['app.form.login'],
                $app['app.form.reset'],
                $app['url_generator']
            );
        };
        $app['app.security.refresh_token_authenticator'] = function (Container $app) {
            return new RefreshTokenAuthenticator(
                $app['app.repo.api'],
                $app['url_generator']
            );
        };

        $app['app.form.login'] = function (Container $app) {
            return $app['form.factory']->create(LoginFormType::class);
        };
        $app['app.form.reset'] = function (Container $app) {
            return $app['form.factory']->create(ResetFormType::class);
        };
    }
}