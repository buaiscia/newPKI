<?php
namespace HomeCredit\Provider;

use Pimple\Container;
use Pimple\ServiceProviderInterface;
use Silex\Application;
use Symfony\Component\Yaml\Yaml;

/**
 * Class YAMLConfigProvider
 * @package HomeCredit\Provider
 */
class YAMLConfigServiceProvider implements ServiceProviderInterface
{
    /**
     * @param Container $app
     */
    public function register(Container $app)
    {
        $app['config'] = function (Container $app) {
            $config = Yaml::parse(file_get_contents($app['config.dir'] . '/default.yml'));
            if (file_exists($app['config.dir'] . '/local.yml')) {
                $localConfig = Yaml::parse(file_get_contents($app['config.dir'] . '/local.yml'));
                $config = array_replace_recursive($config, $localConfig);
            }

            return $config;
        };
    }
}