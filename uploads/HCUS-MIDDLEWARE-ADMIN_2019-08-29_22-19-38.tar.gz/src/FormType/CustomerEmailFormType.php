<?php

namespace HomeCredit\FormType;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class CustomerEmailFormType
 * @package HomeCredit\FormType
 */
class CustomerEmailFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id', HiddenType::class, [
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Range(['min' => 0])
                ]
            ])
            ->add('account_number', HiddenType::class, [
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\CardScheme([
                        'schemes' => ['VISA'],
                        'message' => 'Invalid account number format',
                    ])
                ]
            ])
            ->add('email', EmailType::class, [
                'label' => 'New Email',
                'required' => true,
                'attr' => [
                    'autocomplete' => 'off'
                ],
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Email(),
                ],
            ])
            ->add('password', PasswordType::class, [
                'label' => 'Your Password',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 8,]),
                ]
            ])
            ->add('save', SubmitType::class);
    }
}