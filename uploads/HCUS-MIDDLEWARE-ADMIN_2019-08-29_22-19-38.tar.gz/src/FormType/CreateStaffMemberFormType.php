<?php

namespace HomeCredit\FormType;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotNull;
use Symfony\Component\Validator\Constraints\Regex;

class CreateStaffMemberFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('email', EmailType::class, [
                'constraints' => [
                    new NotNull(),
                    new Email(),
                ]
            ])
            ->add('username', TextType::class, [
                'constraints' => [
                    new NotNull(),
                    new Length(['min' => 8]),
                    new Regex([
                        'pattern' => '/^[A-Za-z0-9]+$/',
                        'message' => 'Username should be only letters and numbers'
                    ])
                ]
            ])
            ->add('role', ChoiceType::class, [
                'choices' => isset($options['data']) && $options['data']['includeAdministrator'] == true ?
                [
                    'Support' => 2,
                    'Admin' => 3,
                    'Supervisor' => 4,
                ]
                :
                [
                    'Support' => 2,
                    'Supervisor' => 4,
                ],
            ])
            ->add('create', SubmitType::class);
    }
}
