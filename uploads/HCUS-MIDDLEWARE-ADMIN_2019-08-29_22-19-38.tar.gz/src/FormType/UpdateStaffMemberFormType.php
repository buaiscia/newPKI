<?php

namespace HomeCredit\FormType;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotNull;

class UpdateStaffMemberFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('email', EmailType::class, [
                'label' => 'Staff Member Email',
                'required' => false,
                'constraints' => [
                    new Email(),
                ],
            ])
            ->add('password', RepeatedType::class, [
                'required' => false,
                'type' => PasswordType::class,
                'invalid_message' => 'The password fields must match.',
                'first_options' => ['label' => 'Staff Member Password'],
                'second_options' => ['label' => 'Confirm Staff Member Password'],
            ])
            ->add('your_password', PasswordType::class, [
                'label' => 'Your Password',
                'constraints' => [
                    new NotNull(),
                ]
            ])
            ->add('submit', SubmitType::class);
    }
}
