<?php

namespace HomeCredit\FormType;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;

class UpdateLpfConfigFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('configuration_name', TextType::class, [
                'label' => 'Configuration Name',
                'required' => true
            ]);

        $this->addLpfConfigForm($builder, "account_status", "Ineligible codes:", "Example: B,L,U");
        $this->addLpfConfigForm($builder, "card_status", "Ineligible codes:", "Example: A,C,D");
        $this->addLpfConfigForm($builder, "product_type", "Eligible products:", "Example: 501,312");
        $this->addLpfConfigForm($builder, "principal_identifier", "Eligible principal identifiers:", "Example: 0000,1000,2000,3000,4000");
        $this->addLpfConfigForm($builder, "agent_identifier", "Eligible system identifiers:", "Example: 3837");
        $this->addLpfConfigForm($builder, "account_origination", "Ineligible account originations:", "Example: ZZZZ,BAZZ");

        $builder
            ->add('campaign_enrollment_enabled_flag', CheckboxType::class, [
                'label' => 'Enable filter?',
                'required' => false,
            ])
            ->add('campaign_enrollment_values', TextType::class, [
                'label' => "Pattern to match account's MISC_TWO_ID value:",
                'required' => false,
                'attr' => [
                    'placeholder' => "Example: _Z___",
                ]
            ]);
    
        $this->addLpfConfigForm($builder, "behavior_score_identifier", "Ineligible behavior score identifier:", "Example: 122,872");

        $builder
            ->add('transaction_amount_enabled_flag', CheckboxType::class, [
                'label' => 'Enable filter?',
                'required' => false,
            ])
            ->add('transaction_amount_min_values', TextType::class, [
                'label' => "Minimum Amount:",
                'required' => false,
                'attr' => [
                    'placeholder' => "Example: 500",
                ],
            ])
            ->add('transaction_amount_max_values', TextType::class, [
                'label' => "Maximum Amount:",
                'required' => false,
                'attr' => [
                    'placeholder' => "Example: 2500",
                ],
            ]);

        $this->addLpfConfigForm($builder, "transaction_category_code", "Eligible codes:", "Example: 00321,10020");
        $this->addLpfConfigForm($builder, "transaction_merchant_description", "Eligible merchant names:", "Example: CASH,WALMART");

        $builder
            ->add('transaction_date_enabled_flag', CheckboxType::class, [
                'label' => 'Enable filter?',
                'required' => false,
            ])
            ->add('transaction_date_value', TextType::class, [
                'label' => "Transactions are ineligible if older than X days:",
                'required' => false,
                'attr' => [
                    'placeholder' => "Example: 90",
                ],
            ]);

        $this->addLpfConfigForm($builder, "transaction_code", "Eligible codes:", "Example: 253,251");
        $this->addLpfConfigForm($builder, "account_promotional_balance", "Eligible values:", "Example: 1825401,0000000");

        $builder
            ->add('submit', SubmitType::class);
    }

    private function addLpfConfigForm(FormBuilderInterface $builder, $key, $configName, $placeholder) : FormBuilderInterface
    {
        return $builder
            ->add($key . '_enabled_flag', CheckboxType::class, [
                'label' => 'Enable filter?',
                'required' => false,
            ])
            ->add($key . '_values', TextType::class, [
                'label' => $configName,
                'required' => false,
                'attr' => [
                    'placeholder' => $placeholder,
                ],
            ]);
    }
}
