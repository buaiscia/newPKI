<?php

namespace HomeCredit\FormType;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints\CardScheme;
use Symfony\Component\Validator\Constraints\NotBlank;

/**
 * Class ResendWelcomeMessageFormType
 * @package HomeCredit\FormType
 */
class ResendWelcomeMessageFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('account_id', TextType::class, [
                'label' => 'Account ID',
                'attr' => [
                    'autocomplete' => 'off',
                ],
                'constraints' => [
                    new NotBlank(),
                    new CardScheme([
                        'schemes' => ['VISA'],
                        'message' => 'Invalid account number format',
                    ]),
                ],
                'required' => true,
            ])
            ->add('contact_method', ChoiceType::class, [
                'label' => 'Contact Method',
                'choices' => [
                    'Email and SMS' => 'both',
                    'Email Only' => 'email',
                    'SMS Only' => 'phone',
                ],
                'required' => true,
            ])
            ->add('search', SubmitType::class, [
                'label' => 'Resend Welcome Message',
            ]);
    }
}
