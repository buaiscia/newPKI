<?php

namespace HomeCredit\FormType;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints\CardScheme;
use Symfony\Component\Validator\Constraints\NotBlank;

/**
 * Class CustomerSearchFormType
 * @package HomeCredit\FormType
 */
class CustomerSearchFormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('account_number', TextType::class, [
                'label' => 'Card Number',
                'attr' => [
                    'autocomplete' => 'off',
                ],
                'constraints' => [
                    new NotBlank(),
                    new CardScheme([
                        'schemes' => ['VISA'],
                        'message' => 'Invalid account number format',
                    ])
                ]
            ])
            ->add('search', SubmitType::class);
    }
}