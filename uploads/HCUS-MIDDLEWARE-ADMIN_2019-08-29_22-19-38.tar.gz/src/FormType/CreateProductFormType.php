<?php

namespace HomeCredit\FormType;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;

class CreateProductFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('prin', TextType::class, [
                'label' => 'PRIN (Principal Identifier)',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Length(['min' => 4, 'max' => 4]),
                    new Assert\Regex(['pattern' => '/[0-9]+/', 'message' => 'PRIN should contain only numbers']),
                ],
                'attr' => [
                    'minlength' => '4',
                    'maxlength' => '4',
                    'pattern' => '\d+',
                    'title' => "PRIN should contain only numbers",
                ],
            ])
            ->add('product_name', TextType::class, [
                'label' => 'Product Name',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Regex(['pattern' => '/[A-Za-z0-9 ]+/', 'message' => 'Product name should contain only letters, numbers or spaces']),
                ],
                'attr' => [
                    'pattern' => '[A-Za-z0-9 ]+',
                    'title' => "Product name should contain only letters, numbers or spaces",
                ],
            ])
            ->add('cardmember_agreement_link', UrlType::class, [
                'label' => 'Cardmember Agreement URL',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                ],
            ])
            ->add('qualifying_purchase_link', UrlType::class, [
                'label' => 'Qualifying Purchase URL',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                ],
            ])
            ->add('rewards_terms_conditions_link', UrlType::class, [
                'label' => 'Rewards Terms and Conditions URL',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                ],
            ])
            ->add('rewards_main_program_name', TextType::class, [
                'label' => 'Main Program Name',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Regex(['pattern' => '/[A-Za-z0-9 ]+/', 'message' => 'Rewards main program name should contain only letters, numbers or spaces']),
                ],
                'attr' => [
                    'pattern' => '[A-Za-z0-9 ]+',
                    'title' => "Rewards main program name should contain only letters, numbers or spaces",
                ],
            ])
            ->add('allow_card_credentials', CheckboxType::class, [
                'label' => 'Allow customers to see their virtual card credentials.',
                'required' => false,
            ])
            ->add('rewards_strategy_name', TextType::class, [
                'label' => 'Rewards Strategy Name (BONS_STRT_NM)',
                'required' => false,
            ])
            ->add('rewards_redemption_points', IntegerType::class, [
                'label' => 'Redemption Points',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Regex(['pattern' => '/[0-9]+/', 'message' => 'Rewards redemption points should contain only numbers']),
                ],
                'attr' => [
                    'pattern' => '[0-9]+',
                    'title' => "Rewards redemption points should contain only numbers",
                ],
            ])
            ->add('rewards_redemption_rate', IntegerType::class, [
                'label' => 'Redemption Rate',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Regex(['pattern' => '/[0-9]+/', 'message' => 'Rewards redemption rate should contain only numbers']),
                ],
                'attr' => [
                    'pattern' => '[0-9]+',
                    'title' => "Rewards redemption rate should contain only numbers",
                ],
            ])
            ->add('rewards_minimum_to_redeem', IntegerType::class, [
                'label' => 'Minimum Points To Redeem',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Regex(['pattern' => '/[0-9]+/', 'message' => 'Rewards minimum points to redeem should contain only numbers']),
                ],
                'attr' => [
                    'pattern' => '[0-9]+',
                    'title' => "Rewards minimum points to redeem should contain only numbers",
                ],
            ])
            ->add('rewards_exclusions', CollectionType::class, [
                'label' => 'Rewards Exclusions',
                'entry_type' => TextType::class,
                'entry_options' => [
                    'constraints' => [
                        new Assert\NotBlank(),
                        new Assert\Regex(['pattern' => '/[A-Za-z0-9 ]+/', 'message' => 'Rewards exclusions should contain only letters, numbers or spaces']),
                    ],
                    'attr' => [
                        'pattern' => '[A-Za-z0-9 ]+',
                        'title' => "Rewards exclusions should contain only letters, numbers or spaces",
                    ],
                ],
                'allow_add' => true,
                'allow_delete' => true,
                'delete_empty' => true,
            ])
            ->add('rewards_criteria', CollectionType::class, [
                'label' => 'Rewards Criteria',
                'entry_type' => TextType::class,
                'entry_options' => [
                    'attr' => [
                        'placeholder' => 'DESCRIPTION:CODE',
                        'pattern' => '[A-Za-z0-9_ *]+:[A-Za-z0-9_ *]+',
                        'title' => "Criterium should be in this format: MERCH_DESC:MERCH_CAT_CODE e.g. SPRINT:04814",
                    ],
                    'constraints' => [
                        new Assert\NotBlank(),
                        new Assert\Regex(['pattern' => '/[A-Za-z0-9_ *]+:[A-Za-z0-9_ *]+/', 'message' => 'Criterium should be in this format: MERCH_DESC:MERCH_CAT_CODE e.g. SPRINT:04814']),
                    ],
                ],
                'allow_add' => true,
                'allow_delete' => true,
                'delete_empty' => true,
            ])
            ->add('sms_marketing_short_code', TextType::class, [
                'label' => 'Marketing Short Code',
                'required' => true,
            ])
            ->add('sms_registration_short_code', TextType::class, [
                'label' => 'Account Registration Short Code',
                'required' => true,
            ])
            ->add('sms_device_verific_short_code', TextType::class, [
                'label' => 'Device Verification Short Code',
                'required' => true,
            ])
            ->add('sms_marketing_message', TextType::class, [
                'label' => 'Marketing Message',
                'required' => true,
            ])
            ->add('sms_username', TextType::class, [
                'label' => 'Username',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Regex(['pattern' => '/[A-Za-z0-9 ]+/', 'message' => 'SMS Username should contain only letters, numbers or spaces']),
                ],
                'attr' => [
                    'pattern' => '[A-Za-z0-9 ]+',
                    'title' => "SMS Username should contain only letters, numbers or spaces",
                ],
            ])
            ->add('sms_password', TextType::class, [
                'label' => 'Password',
                'required' => true,
                'constraints' => [
                    new Assert\NotBlank(),
                    new Assert\Regex(['pattern' => '/[A-Za-z0-9 ]+/', 'message' => 'SMS Password should contain only letters, numbers or spaces']),
                ],
                'attr' => [
                    'pattern' => '[A-Za-z0-9 ]+',
                    'title' => "SMS Password should contain only letters, numbers or spaces",
                ],
            ])
            ->add('rewards_translations', CollectionType::class, [
                'label' => 'Rewards Program Names Translations',
                'entry_type' => TextType::class,
                'entry_options' => [
                    'attr' => [
                        'placeholder' => 'PROGRAM_KEY:ENGLISH:SPANISH',
                        'pattern' => '[^:]+:[^:]+:[^:]+',
                        'title' => "Translations should be in this format: PROGRAM_KEY:ENGLISH:SPANISH e.g. SPRTBNUS:Bonus:Bonus",
                    ],
                    'constraints' => [
                        new Assert\NotBlank(),
                        new Assert\Regex(['pattern' => '/[^:]+:[^:]+:[^:]+/', 'message' => 'Translations should be in this format: PROGRAM_KEY:ENGLISH:SPANISH e.g. SPRTBNUS:Bonus:Bonus']),
                    ],
                ],
                'allow_add' => true,
                'allow_delete' => true,
                'delete_empty' => true,
            ])
            ->add('partner_id_translations', CollectionType::class, [
                'label' => 'LPF Partner ID Translations',
                'entry_type' => TextType::class,
                'entry_options' => [
                    'attr' => [
                        'placeholder' => 'SYSTEM_ID:PARTNER_ID',
                        'pattern' => '[^:]+:[^:]+',
                        'title' => "Translations should be in this format: SYSTEM_ID:PARTNER_ID e.g. 3837:HCUS",
                    ],
                    'constraints' => [
                        new Assert\NotBlank(),
                        new Assert\Regex(['pattern' => '/[^:]+:[^:]+/', 'message' => 'Translations should be in this format: SYSTEM_ID:PARTNER_ID e.g. 3837:HCUS']),
                    ],
                ],
                'allow_add' => true,
                'allow_delete' => true,
                'delete_empty' => true,
            ])
            ->add('submit', SubmitType::class);
    }
}
