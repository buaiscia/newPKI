<?php

namespace HomeCredit\Controller;

use HomeCredit\Exception\AccountNumberNotRegisteredException;
use HomeCredit\Repository\ApiRepository;
use Psr\Log\LoggerInterface;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\Request;
use Twig_Environment;

/**
 * Class ResendWelcomeMessageController
 * @package HomeCredit\Controller
 */
class ResendWelcomeMessageController
{
    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var ApiRepository
     */
    protected $apiRepository;

    /**
     * @var Form
     */
    protected $resendWelcomeMessageForm;

    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * CustomerController constructor.
     * @param LoggerInterface $logger
     * @param ApiRepository $apiRepository
     * @param Form $resendWelcomeMessageForm
     * @param Twig_Environment $twig
     */
    public function __construct(
        LoggerInterface $logger,
        ApiRepository $apiRepository,
        Form $resendWelcomeMessageForm,
        Twig_Environment $twig
    ) {
        $this->logger = $logger;
        $this->apiRepository = $apiRepository;
        $this->resendWelcomeMessageForm = $resendWelcomeMessageForm;
        $this->twig = $twig;
    }
    /**
     * @param Request $request
     * @return string
     */
    public function search(Request $request)
    {
        $user = null;
        $successMessage = null;

        $this->resendWelcomeMessageForm->handleRequest($request);

        if ($this->resendWelcomeMessageForm->isValid()) {
            $formData = $this->resendWelcomeMessageForm->getData();

            try {
                $result = $this->isAccountAlreadyRegistered($formData['account_id']);

                if (!$result) {
                    $response = $this->apiRepository->resendWelcomeMessage(
                        $formData['account_id'],
                        $formData['contact_method']
                    );

                    if ($response) {
                        $successMessage = 'A link containing registration information has been sent to the contact methods available for this customer.';
                    }
                } else {
                    $this->resendWelcomeMessageForm->get('account_id')->addError(
                        new FormError("This account is already registered. Navigate to 'Customer Search' to search this account's details.")
                    );
                }
            } catch (InvalidAccountNumberException $e) {
                $this->resendWelcomeMessageForm->get('account_id')->addError(
                    new FormError("Invalid account id.")
                );
            } catch (\Exception $e) {
                $this->resendWelcomeMessageForm->addError(
                    new FormError('Something has gone wrong. Please try again.')
                );
            }
        }

        return $this->twig->render('customers/resend_welcome_message.html.twig', [
            'customer_resend_form' => $this->resendWelcomeMessageForm->createView(),
            'success_message' => $successMessage,
            'user' => $user,
        ]);
    }

    /**
     * @param mixed $accountNumber
     * @return stdClass|null
     */
    protected function isAccountAlreadyRegistered($accountNumber)
    {
        try {
            $this->apiRepository->accountSearch($accountNumber);
        } catch (AccountNumberNotRegisteredException $e) {
            // $this->resendWelcomeMessageForm->addError(new FormError('Customer is not registered'));
            return false;
        }

        return true;
    }
}
