<?php

namespace HomeCredit\Controller;

use Exception;
use HomeCredit\Security\User;
use HomeCredit\Exception\InvalidInputException;
use HomeCredit\FormType\CreateStaffMemberFormType;
use HomeCredit\FormType\DeleteStaffMemberFormType;
use HomeCredit\FormType\UpdateStaffMemberFormType;
use HomeCredit\FormType\SupporterSearchFormType;
use HomeCredit\Repository\ApiRepository;
use Silex\Application;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\ServiceUnavailableHttpException;
use Twig_Environment;

class AdminController
{
    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var ApiRepository
     */
    protected $apiRepository;

    /**
     * @var Form
     */
    protected $formFactory;

    /**
     * @var User
     */
    protected $user;

    /**
     * AdminController constructor.
     * @param ApiRepository $apiRepository
     * @param FormFactory $formFactory
     * @param Twig_Environment $twig
     */
    public function __construct(ApiRepository $apiRepository, FormFactory $formFactory, Twig_Environment $twig, User $user)
    {
        $this->apiRepository = $apiRepository;
        $this->formFactory = $formFactory;
        $this->twig = $twig;
        $this->user = $user;
    }

    /**
     * @param Request $request
     * @param Application $app
     */
    public function staff(Request $request, Application $app)
    {
        $staff = [];
        $loadingError = null;

        $search = '';
        $page = 1;

        $searchForm = $app['form.factory']->create(SupporterSearchFormType::class, ['page' => 1]);

        $searchForm->handleRequest($request);
        if ($searchForm->isValid()) {
            $searchData = $searchForm->getData();
            $search = $searchData['keyword'];
            $page = (int)$searchData['page'];
        }

        $deleteForm = $this->formFactory->create(DeleteStaffMemberFormType::class);

        $deleteForm->handleRequest($request);
        $deleteError = null;
        $deleteSuccess = null;
        if ($deleteForm->isValid()) {
            // send api call, get error messages
            $deleteData = $deleteForm->getData();

            try {
                $deleteResponse = $this->apiRepository->deleteStaffMember((int) $deleteData['id'], $deleteData['password']);
                if ($deleteResponse) {
                    $deleteSuccess = true;
                }
            } catch (InvalidInputException $e) {
                foreach ($e->getErrors() as $field => $error) {
                    $deleteError = $error;
                    break;
                }
            } catch (ServiceUnavailableHttpException $e) {
                $deleteError = 'Unable to delete user. Please try again later.';
            }
        }

        try {
            $staff = $this->apiRepository->getStaff($page, $search);
        } catch (ServiceUnavailableHttpException $e) {
            $loadingError = 'Unable to communicate with server. Please try again.';
        }

        return $this->twig->render('/admin/staff.html.twig', [
            'staff' => $staff,
            'loading_error' => $loadingError,
            'page' => $page,
            'search_form' => $searchForm->createView(),
            'delete_form' => $deleteForm->createView(),
            'delete_error' => $deleteError,
            'delete_success' => $deleteSuccess,
        ]);
    }


    /**
     * @param Request $request
     */
    public function createSupporter(Request $request)
    {
        $newUser = null;

        $createForm = $this->formFactory->create(CreateStaffMemberFormType::class, ['includeAdministrator' => in_array('ROLE_ADMINISTRATOR', $this->user->getRoles())]);
        $createForm->handleRequest($request);

        if ($createForm->isValid()) {
            $formData = $createForm->getData();

            try {
                $result = $this->apiRepository->createStaffMember(
                    $formData['email'],
                    $formData['username'],
                    (int)$formData['role']
                );

                if ($result) {
                    $newUser = $result;
                    $createForm = $this->formFactory->create(CreateStaffMemberFormType::class);
                }
            } catch (InvalidInputException $e) {
                $errors = $e->getErrors();
                if (is_array($errors)) {
                    foreach ($e->getErrors() as $field => $error) {
                        if ($field === '[email]') {
                            $createForm->get('email')->addError(
                                new FormError($error)
                            );
                        } else if ($field === '[username]') {
                            $createForm->get('username')->addError(
                                new FormError($error)
                            );
                        } else if ($field === '[role]') {
                            $createForm->get('role')->addError(
                                new FormError($error)
                            );
                        } else {
                            $createForm->addError(
                                new FormError($error)
                            );
                        }
                    }
                } else if (is_string($errors)) {
                    $createForm->addError(
                        new FormError($errors)
                    );
                } else {
                    $createForm->addError(
                        new FormError('Unable to create the user. Please try again later.')
                    );
                }
            } catch (Exception $e) {
                $createForm->addError(
                    new FormError('Something went wrong. Please try again later.')
                );
            }
        }

        return $this->twig->render('/admin/create.html.twig', [
            'create_form' => $createForm->createView(),
            'new_user' => $newUser,
        ]);

    }

    public function updateStaffMember($id, Request $request)
    {
        $updateForm = $this->formFactory->create(UpdateStaffMemberFormType::class);
        $successMessage = null;

        $updateForm->handleRequest($request);
        if ($updateForm->isValid()) {
            $data = $updateForm->getData();

            if ($data['email'] or $data['password']) {
                try {
                    $apiResponse = $this->apiRepository->updateStaff($id, $data['your_password'], $data['email'], $data['password']);
                    if ($apiResponse) {
                        $successMessage = 'Staff member updated successfully';
                    } else {
                        throw new Exception;
                    }
                } catch (InvalidInputException $e) {
                    foreach ($e->getErrors() as $field => $error) {
                        if ($field === '[email]') {
                            $updateForm->get('email')->addError(
                                new FormError($error)
                            );
                        } else if ($field === '[new_password]') {
                            $updateForm->get('password')->get('first')->addError(
                                new FormError($error)
                            );
                        } else if ($field === '[new_password_verify]') {
                            $updateForm->get('password')->get('second')->addError(
                                new FormError($error)
                            );
                        } else if ($field === '[password]') {
                            $updateForm->get('your_password')->addError(
                                new FormError($error)
                            );
                        } else {
                            $updateForm->addError(
                                new FormError($error)
                            );
                        }
                    }
                } catch (Exception $e) {
                    $updateForm->addError(
                        new FormError('Unable to save changes. Please try again later.')
                    );
                }
            }
        }

        // TODO get staff member and display user name

        return $this->twig->render('/admin/update.html.twig', [
            'update_form' => $updateForm->createView(),
            'success_message' => $successMessage,
        ]);
    }

}
