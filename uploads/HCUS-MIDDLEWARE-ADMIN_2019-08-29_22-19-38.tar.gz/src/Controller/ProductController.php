<?php

namespace HomeCredit\Controller;

use HomeCredit\FormType\CreateProductFormType;
use HomeCredit\FormType\UpdateProductFormType;
use HomeCredit\Repository\ApiRepository;
use Silex\Application;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\ServiceUnavailableHttpException;
use Twig_Environment;

class ProductController
{
    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var ApiRepository
     */
    protected $apiRepository;

    /**
     * @var Form
     */
    protected $formFactory;

    /**
     * AdminController constructor.
     * @param ApiRepository $apiRepository
     * @param FormFactory $formFactory
     * @param Twig_Environment $twig
     */
    public function __construct(ApiRepository $apiRepository, FormFactory $formFactory, Twig_Environment $twig)
    {
        $this->apiRepository = $apiRepository;
        $this->formFactory = $formFactory;
        $this->twig = $twig;
    }

    /**
     * @param Request $request
     * @param Application $app
     */
    public function product(Request $request, Application $app)
    {
        $staff = [];
        $loadingError = null;

        $page = 1;

        try {
            $products = $this->apiRepository->getProducts($page);
        } catch (ServiceUnavailableHttpException $e) {
            $loadingError = 'Unable to communicate with server. Please try again.';
        }

        return $this->twig->render('/admin/product/list.html.twig', [
            'products' => $products,
            'loading_error' => $loadingError,
            'page' => $page,
        ]);
    }

    /**
     * @param Request $request
     */
    public function createProduct(Request $request)
    {
        $newUser = null;

        $createForm = $this->formFactory->create(CreateProductFormType::class);
        $createForm->handleRequest($request);

        $successMessage = null;

        if ($createForm->isValid()) {
            $formData = $createForm->getData();

            try {

                $formData['rewards_criteria'] = array_map(
                    function ($criterium) {
                        return [
                            'description' => explode(':', $criterium)[0],
                            'code' => explode(':', $criterium)[1],
                        ];
                    },
                    $formData['rewards_criteria']
                );

                $formData['rewards_translations'] = array_map(
                    function ($rewards_translation) {
                        return [
                            'program_name' => explode(':', $rewards_translation)[0],
                            'english_translation' => explode(':', $rewards_translation)[1],
                            'spanish_translation' => explode(':', $rewards_translation)[2],
                        ];
                    },
                    $formData['rewards_translations']
                );

                $formData['partner_id_translations'] = array_map(
                    function ($partner_id_translation) {
                        return [
                            'system_id' => explode(':', $partner_id_translation)[0],
                            'partner_id' => explode(':', $partner_id_translation)[1]
                        ];
                    },
                    $formData['partner_id_translations']
                );

                $result = $this->apiRepository->createProduct($formData);

                if ($result) {
                    $successMessage = 'Product created successfully';
                    $createForm = $this->formFactory->create(CreateProductFormType::class);
                }
            } catch (\Exception $e) {
                if (count($e->getErrors()) == 0) {
                    $createForm->addError(
                        new FormError('Unable to save changes. Please try again later.')
                    );
                } else {
                    foreach ($e->getErrors() as $key => $value) {
                        $createForm->addError(
                            new FormError($value)
                        );
                    }
                }
            }
        }

        return $this->twig->render('/admin/product/create.html.twig', [
            'create_form' => $createForm->createView(),
            'success_message' => $successMessage,
        ]);
    }

    public function updateProduct($id, Request $request)
    {

        $product = null;
        $successMessage = null;
        try {
            $product = $this->apiRepository->getProductById($id)[0];
        } catch (ServiceUnavailableHttpException $e) {
            $loadingError = 'Unable to communicate with server. Please try again.';
        }

        $updateForm = $this->formFactory->create(UpdateProductFormType::class);

        if ($product == null) {
            return $this->twig->render('/admin/product/update.html.twig', [
                'update_form' => $updateForm->createView(),
                'product' => $product,
                'success_message' => $successMessage,
            ]);
        }

        // map data arrays to simple strings
        $product['rewards_exclusions'] = array_map(
            function ($exclusion) {
                return $exclusion['name'];
            },
            $product['rewards_exclusions']
        );

        // map data arrays to simple strings
        $product['rewards_criteria'] = array_map(
            function ($criterium) {
                return $criterium['description'] . ":" . $criterium['code'];
            },
            $product['rewards_criteria']
        );

        // map data arrays to simple strings
        $product['rewards_translations'] = array_map(
            function ($translation) {
                return $translation['program_name'] . ":" . $translation['english_translation'] . ":" . $translation['spanish_translation'];
            },
            $product['rewards_translations']
        );

        // map data arrays to simple strings
        $product['partner_id_translations'] = array_map(
            function ($translation) {
                return $translation['system_id'] . ":" . $translation['partner_id'];
            },
            $product['partner_id_translations']
        );

        $updateForm->setData([
            'prin' => $product['prin'],
            'product_name' => $product['product_name'],
            'cardmember_agreement_link' => $product['cardmember_agreement_link'],
            'qualifying_purchase_link' => $product['qualifying_purchase_link'],
            'rewards_terms_conditions_link' => $product['rewards_terms_conditions_link'],
            'allow_card_credentials' => $product['allow_card_credentials'] == '1' ? true : false,
            'rewards_main_program_name' => $product['rewards_main_program_name'],
            'rewards_strategy_name' => $product['rewards_strategy_name'],
            'rewards_redemption_points' => $product['rewards_redemption_points'],
            'rewards_redemption_rate' => $product['rewards_redemption_rate'],
            'rewards_minimum_to_redeem' => $product['rewards_minimum_to_redeem'],
            'rewards_exclusions' => $product['rewards_exclusions'],
            'rewards_criteria' => $product['rewards_criteria'],
            'rewards_translations' => $product['rewards_translations'],
            'partner_id_translations' => $product['partner_id_translations'],
            'sms_marketing_short_code' => $product['sms_marketing_short_code'],
            'sms_registration_short_code' => $product['sms_registration_short_code'],
            'sms_device_verific_short_code' => $product['sms_device_verific_short_code'],
            'sms_marketing_message' => $product['sms_marketing_message'],
            'sms_username' => $product['sms_username'],
            'sms_password' => $product['sms_password'],
        ]);

        $updateForm->handleRequest($request);

        if ($updateForm->isValid()) {
            $data = $updateForm->getData();
            try {
                $data['rewards_criteria'] = array_map(
                    function ($criterium) {
                        return [
                            'description' => explode(':', $criterium)[0],
                            'code' => explode(':', $criterium)[1],
                        ];
                    },
                    $data['rewards_criteria']
                );

                $data['rewards_translations'] = array_map(
                    function ($rewards_translation) {
                        return [
                            'program_name' => explode(':', $rewards_translation)[0],
                            'english_translation' => explode(':', $rewards_translation)[1],
                            'spanish_translation' => explode(':', $rewards_translation)[2],
                        ];
                    },
                    $data['rewards_translations']
                );

                $data['partner_id_translations'] = array_map(
                    function ($partner_id_translations) {
                        return [
                            'system_id' => explode(':', $partner_id_translations)[0],
                            'partner_id' => explode(':', $partner_id_translations)[1]
                        ];
                    },
                    $data['partner_id_translations']
                );

                $apiResponse = $this->apiRepository->updateProduct($id, $data);
                if ($apiResponse) {
                    $successMessage = 'Product updated successfully';
                } else {
                    throw new \Exception;
                }
            } catch (\Exception $e) {
                if (count($e->getErrors()) == 0) {
                    $updateForm->addError(
                        new FormError('Unable to save changes. Please try again later.')
                    );
                } else {
                    foreach ($e->getErrors() as $key => $value) {
                        $updateForm->addError(
                            new FormError($value)
                        );
                    }
                }
            }
        }

        return $this->twig->render('/admin/product/update.html.twig', [
            'update_form' => $updateForm->createView(),
            'product' => $product,
            'success_message' => $successMessage,
        ]);
    }
}
