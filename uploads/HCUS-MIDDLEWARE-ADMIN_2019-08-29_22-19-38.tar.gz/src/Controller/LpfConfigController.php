<?php

namespace HomeCredit\Controller;

use HomeCredit\Exception\InvalidInputException;
use HomeCredit\FormType\CreateLpfConfigFormType;
use HomeCredit\FormType\DeleteLpfConfigFormType;
use HomeCredit\FormType\UpdateLpfConfigFormType;
use HomeCredit\FormType\UpdateProductFormType;
use HomeCredit\Repository\ApiRepository;
use Silex\Application;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\ServiceUnavailableHttpException;
use Twig_Environment;

class LpfConfigController
{
    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var ApiRepository
     */
    protected $apiRepository;

    /**
     * @var Form
     */
    protected $formFactory;

    /**
     * AdminController constructor.
     * @param ApiRepository $apiRepository
     * @param FormFactory $formFactory
     * @param Twig_Environment $twig
     */
    public function __construct(ApiRepository $apiRepository, FormFactory $formFactory, Twig_Environment $twig)
    {
        $this->apiRepository = $apiRepository;
        $this->formFactory = $formFactory;
        $this->twig = $twig;
    }

    /**
     * @param Request $request
     * @param Application $app
     */
    public function listLpfConfigs(Request $request, Application $app)
    {
        $staff = [];
        $loadingError = null;

        $deleteForm = $this->formFactory->create(DeleteLpfConfigFormType::class);

        $deleteForm->handleRequest($request);
        $deleteError = null;
        $deleteSuccess = null;
        if ($deleteForm->isValid()) {
            // send api call, get error messages
            $deleteData = $deleteForm->getData();

            try {
                $deleteResponse = $this->apiRepository->deleteLpfConfigurationById((int)$deleteData['id'], $deleteData['password']);
                if ($deleteResponse) {
                    $deleteSuccess = true;
                }
            } catch (InvalidInputException $e) {
                foreach ($e->getErrors() as $field => $error) {
                    $deleteError = $error;
                    break;
                }
            } catch (ServiceUnavailableHttpException $e) {
                $deleteError = 'Unable to delete LPF configuration. Please try again later.';
            }
        }

        $page = 1;

        try {
            $lpfConfigs = $this->apiRepository->getLpfConfigurations($page);
        } catch (ServiceUnavailableHttpException $e) {
            $loadingError = 'Unable to communicate with server. Please try again.';
        }

        return $this->twig->render('/admin/lpf_config/list.html.twig', [
            'lpfConfigs' => $lpfConfigs,
            'loading_error' => $loadingError,
            'page' => $page,
            'delete_form' => $deleteForm->createView(),
            'delete_error' => $deleteError,
            'delete_success' => $deleteSuccess,
        ]);
    }

    /**
     * @param Request $request
     */
    public function createLPFConfig(Request $request)
    {
        $newUser = null;

        $createForm = $this->formFactory->create(CreateLpfConfigFormType::class);
        $createForm->handleRequest($request);

        $successMessage = null;

        if ($createForm->isValid()) {
            $formData = $createForm->getData();

            try {
                $accountBasedConfig = [
                    "account_status" => [
                        "enabled" => $formData['account_status_enabled_flag'],
                        "values" => explode(",", $formData['account_status_values'])
                    ],
                    "card_status" => [
                        "enabled" => $formData['card_status_enabled_flag'],
                        "values" => explode(",", $formData['card_status_values'])
                    ],
                    "product_type" => [
                        "enabled" => $formData['product_type_enabled_flag'],
                        "values" => explode(",", $formData['product_type_values'])
                    ],
                    "principal_identifier" => [
                        "enabled" => $formData['principal_identifier_enabled_flag'],
                        "values" => explode(",", $formData['principal_identifier_values'])
                    ],
                    "agent_identifier" => [
                        "enabled" => $formData['agent_identifier_enabled_flag'],
                        "values" => explode(",", $formData['agent_identifier_values'])
                    ],
                    "account_origination" => [
                        "enabled" => $formData['account_origination_enabled_flag'],
                        "values" => explode(",", $formData['account_origination_values'])
                    ],
                    "campaign_enrollment" => [
                        "enabled" => $formData['campaign_enrollment_enabled_flag'],
                        "values" => explode(",", $formData['campaign_enrollment_values'])
                    ],
                    "behavior_score_identifier" => [
                        "enabled" => $formData['behavior_score_identifier_enabled_flag'],
                        "values" => explode(",", $formData['behavior_score_identifier_values'])
                    ]
                ];

                $transactionBasedConfig = [
                    'transaction_amount' => [
                        "enabled" => $formData['transaction_amount_enabled_flag'],
                        "values" => [
                            "minimum" => $formData['transaction_amount_min_values'],
                            "maximum" => $formData['transaction_amount_max_values']
                        ]
                    ],
                    'transaction_category_code' => [
                        "enabled" => $formData['transaction_category_code_enabled_flag'],
                        "values" => explode(",", $formData['transaction_category_code_values'])
                    ],
                    'transaction_merchant_description' => [
                        "enabled" => $formData['transaction_merchant_description_enabled_flag'],
                        "values" => explode(",", $formData['transaction_merchant_description_values'])
                    ],
                    'transaction_date' => [
                        "enabled" => $formData['transaction_date_enabled_flag'],
                        "values" => $formData['transaction_date_value']
                    ],
                    'transaction_code' => [
                        "enabled" => $formData['transaction_code_enabled_flag'],
                        "values" => explode(",", $formData['transaction_code_values'])
                    ],
                    'account_promotional_balance' => [
                        "enabled" => $formData['account_promotional_balance_enabled_flag'],
                        "values" => explode(",", $formData['account_promotional_balance_values'])
                    ]
                ];

                $result = $this->apiRepository->createLpfConfiguration($accountBasedConfig, $transactionBasedConfig, $formData['configuration_name']);

                $successMessage = 'LPF Configuration created successfully';
                $createForm = $this->formFactory->create(CreateLpfConfigFormType::class);
            } catch (\Exception $e) {
                // var_dump("sadasd");
                $createForm->addError(
                    new FormError('Unable to create LPF configuration. Please try again later.')
                );
            }
        }

        return $this->twig->render('/admin/lpf_config/create.html.twig', [
            'create_form' => $createForm->createView(),
            'success_message' => $successMessage,
        ]);
    }

    public function updateLpfConfig($id, Request $request)
    {
        $product = null;
        $successMessage = null;
        try {
            $product = $this->apiRepository->getLpfConfigurationById($id)[0];
        } catch (ServiceUnavailableHttpException $e) {
            $loadingError = 'Unable to communicate with server. Please try again.';
        }

        $updateForm = $this->formFactory->create(UpdateLpfConfigFormType::class);

        $updateForm->setData([
            'account_status_enabled_flag' => $product['account_based_config']['account_status']['enabled'],
            'account_status_values' => join(",", $product['account_based_config']['account_status']['values']),
            'card_status_enabled_flag' => $product['account_based_config']['card_status']['enabled'],
            'card_status_values' => join(",", $product['account_based_config']['card_status']['values']),
            'product_type_enabled_flag' => $product['account_based_config']['product_type']['enabled'],
            'product_type_values' => join(",", $product['account_based_config']['product_type']['values']),
            'principal_identifier_enabled_flag' => $product['account_based_config']['principal_identifier']['enabled'],
            'principal_identifier_values' => join(",", $product['account_based_config']['principal_identifier']['values']),
            'agent_identifier_enabled_flag' => $product['account_based_config']['agent_identifier']['enabled'],
            'agent_identifier_values' => join(",", $product['account_based_config']['agent_identifier']['values']),
            'account_origination_enabled_flag' => $product['account_based_config']['account_origination']['enabled'],
            'account_origination_values' => join(",", $product['account_based_config']['account_origination']['values']),
            'campaign_enrollment_enabled_flag' => $product['account_based_config']['campaign_enrollment']['enabled'],
            'campaign_enrollment_values' => join(",", $product['account_based_config']['campaign_enrollment']['values']),
            'behavior_score_identifier_enabled_flag' => $product['account_based_config']['behavior_score_identifier']['enabled'],
            'behavior_score_identifier_values' => join(",", $product['account_based_config']['behavior_score_identifier']['values']),
            'transaction_amount_enabled_flag' => $product['transaction_based_config']['transaction_amount']['enabled'],
            'transaction_amount_min_values' => $product['transaction_based_config']['transaction_amount']['values']['minimum'],
            'transaction_amount_max_values' => $product['transaction_based_config']['transaction_amount']['values']['maximum'],
            'transaction_category_code_enabled_flag' => $product['transaction_based_config']['transaction_category_code']['enabled'],
            'transaction_category_code_values' => join(",", $product['transaction_based_config']['transaction_category_code']['values']),
            'transaction_merchant_description_enabled_flag' => $product['transaction_based_config']['transaction_merchant_description']['enabled'],
            'transaction_merchant_description_values' => join(",", $product['transaction_based_config']['transaction_merchant_description']['values']),
            'transaction_date_enabled_flag' => $product['transaction_based_config']['transaction_date']['enabled'],
            'transaction_date_value' => $product['transaction_based_config']['transaction_date']['values'],
            'transaction_code_enabled_flag' => $product['transaction_based_config']['transaction_code']['enabled'],
            'transaction_code_values' => join(",", $product['transaction_based_config']['transaction_code']['values']),
            'account_promotional_balance_enabled_flag' => $product['transaction_based_config']['account_promotional_balance']['enabled'],
            'account_promotional_balance_values' => join(",", $product['transaction_based_config']['account_promotional_balance']['values']),
            'configuration_name' => $product['configuration_name'],
        ]);

        $updateForm->handleRequest($request);
        if ($updateForm->isValid()) {
            $formData = $updateForm->getData();

            $data = [
                'configuration_name' => $formData['configuration_name'],
                'account_based_config' => [
                    "account_status" => [
                        "enabled" => $formData['account_status_enabled_flag'],
                        "values" => explode(",", $formData['account_status_values'])
                    ],
                    "card_status" => [
                        "enabled" => $formData['card_status_enabled_flag'],
                        "values" => explode(",", $formData['card_status_values'])
                    ],
                    "product_type" => [
                        "enabled" => $formData['product_type_enabled_flag'],
                        "values" => explode(",", $formData['product_type_values'])
                    ],
                    "principal_identifier" => [
                        "enabled" => $formData['principal_identifier_enabled_flag'],
                        "values" => explode(",", $formData['principal_identifier_values'])
                    ],
                    "agent_identifier" => [
                        "enabled" => $formData['agent_identifier_enabled_flag'],
                        "values" => explode(",", $formData['agent_identifier_values'])
                    ],
                    "account_origination" => [
                        "enabled" => $formData['account_origination_enabled_flag'],
                        "values" => explode(",", $formData['account_origination_values'])
                    ],
                    "campaign_enrollment" => [
                        "enabled" => $formData['campaign_enrollment_enabled_flag'],
                        "values" => explode(",", $formData['campaign_enrollment_values'])
                    ],
                    "behavior_score_identifier" => [
                        "enabled" => $formData['behavior_score_identifier_enabled_flag'],
                        "values" => explode(",", $formData['behavior_score_identifier_values'])
                    ]
                ],
                "transaction_based_config" => [
                    'transaction_amount' => [
                        "enabled" => $formData['transaction_amount_enabled_flag'],
                        "values" => [
                            "minimum" => $formData['transaction_amount_min_values'],
                            "maximum" => $formData['transaction_amount_max_values']
                        ]
                    ],
                    'transaction_category_code' => [
                        "enabled" => $formData['transaction_category_code_enabled_flag'],
                        "values" => explode(",", $formData['transaction_category_code_values'])
                    ],
                    'transaction_merchant_description' => [
                        "enabled" => $formData['transaction_merchant_description_enabled_flag'],
                        "values" => explode(",", $formData['transaction_merchant_description_values'])
                    ],
                    'transaction_date' => [
                        "enabled" => $formData['transaction_date_enabled_flag'],
                        "values" => $formData['transaction_date_value']
                    ],
                    'transaction_code' => [
                        "enabled" => $formData['transaction_code_enabled_flag'],
                        "values" => explode(",", $formData['transaction_code_values'])
                    ],
                    'account_promotional_balance' => [
                        "enabled" => $formData['account_promotional_balance_enabled_flag'],
                        "values" => explode(",", $formData['account_promotional_balance_values'])
                    ]
                ]
            ];

            try {
                $apiResponse = $this->apiRepository->updateLpfConfiguration($id, $data);
                if ($apiResponse) {
                    $successMessage = 'LPF configuration updated successfully';
                } else {
                    throw new \Exception;
                }
            } catch (\Exception $e) {
                $updateForm->addError(
                    new FormError('Unable to save changes. Please try again later.')
                );
            }
        }

        return $this->twig->render('/admin/lpf_config/update.html.twig', [
            'update_form' => $updateForm->createView(),
            'product' => $product,
            'success_message' => $successMessage,
        ]);
    }
}
