<?php

namespace HomeCredit\Controller;

use HomeCredit\Exception\InvalidInputException;
use HomeCredit\Repository\ApiRepository;
use Psr\Log\LoggerInterface;
use Silex\Application;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Generator\UrlGenerator;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Core\Security;
use Twig_Environment;
use Symfony\Component\HttpKernel\Exception\ServiceUnavailableHttpException;

/**
 * Class AuthController
 * @package HomeCredit\Controller
 */
class AuthController
{
    /**
     * @var ApiRepository
     */
    protected $apiRepository;

    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Form
     */
    protected $loginForm;

    /**
     * @var Form
     */
    protected $profileForm;

    /**
     * @var Form
     */
    protected $resetForm;

    /**
     * @var UrlGenerator
     */
    protected $urlGenerator;

    /**
     * AuthController constructor.
     * @param ApiRepository $apiRepository
     * @param Twig_Environment $twig
     * @param LoggerInterface $logger
     * @param Form $loginForm
     * @param Form $profileForm
     * @param UrlGenerator $urlGenerator
     */
    public function __construct(
        ApiRepository $apiRepository,
        Twig_Environment $twig,
        LoggerInterface $logger,
        Form $loginForm,
        Form $profileForm,
        Form $resetForm,
        UrlGenerator $urlGenerator
    ) {
        $this->apiRepository = $apiRepository;
        $this->twig = $twig;
        $this->logger = $logger;
        $this->loginForm = $loginForm;
        $this->profileForm = $profileForm;
        $this->resetForm = $resetForm;
        $this->urlGenerator = $urlGenerator;
    }

    /**
     * @param Request $req
     * @param Application $app
     * @return string
     */
    public function login(Request $req, Application $app)
    {
        return $this->twig->render('/auth/login.html.twig', [
            'form' => $this->loginForm->createView(),
            'security_error' => $app['security.last_error']($req),
        ]);
    }

    /**
     * @param Request $req
     * @param Application $app
     * @return string
     */
    public function reset(Request $req, Application $app)
    {
        return $this->twig->render('/auth/login.html.twig', [
            'form' => $this->resetForm->createView(),
            'security_error' => $app['security.last_error']($req),
        ]);
    }

    /**
     * @param Request $req
     * @return string
     */
    public function profile(Request $req)
    {
        $this->profileForm->handleRequest($req);

        if ($this->profileForm->isValid()) {
            $profileFormData = $this->profileForm->getData();

            try {
                $response = $this->apiRepository->updateProfilePassword(
                    $profileFormData['current_password'],
                    $profileFormData['new_password']
                );

                if ($response) {
                    $req->getSession()->remove('_security_main');
                    $req->getSession()->set(
                        Security::AUTHENTICATION_ERROR,
                        new AuthenticationException('Password changed successfully. Please log in again.')
                    );

                    return new RedirectResponse($this->urlGenerator->generate('auth_login'));
                }
            } catch (InvalidInputException $e) {
                foreach ($e->getErrors() as $field => $error) {
                    if ($field === '[password]') {
                        $this->profileForm->get('current_password')->addError(
                            new FormError($error)
                        );
                    } else if ($field === '[new_password]') {
                        $this->profileForm->get('new_password')->get('first')->addError(
                            new FormError($error)
                        );
                    } else if ($field === '[new_password_verify]') {
                        $this->profileForm->get('new_password')->get('second')->addError(
                            new FormError($error)
                        );
                    } else {
                        $this->profileForm->addError(
                            new FormError($error)
                        );
                    }
                }
            } catch (ServiceUnavailableHttpException $e) {
                $this->logger->error('Uncaught exception in profile update', [
                    'msg' => $e->getMessage(),
                    'code' => $e->getCode(),
                ]);

                $this->profileForm->addError(
                    new FormError('Unable to save your new password. Please try again later.')
                );
            }
        }

        return $this->twig->render('/auth/profile.html.twig', [
            'profile_form' => $this->profileForm->createView(),
        ]);
    }
}
