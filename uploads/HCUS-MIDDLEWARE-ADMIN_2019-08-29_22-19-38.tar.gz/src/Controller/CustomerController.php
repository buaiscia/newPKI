<?php

namespace HomeCredit\Controller;

use DateTime;
use Exception;
use HomeCredit\Exception\AccountNumberNotRegisteredException;
use HomeCredit\Exception\InvalidAccountNumberException;
use HomeCredit\Exception\InvalidInputException;
use HomeCredit\Repository\ApiRepository;
use Psr\Log\LoggerInterface;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Twig_Environment;
use Symfony\Component\HttpKernel\Exception\ServiceUnavailableHttpException;

/**
 * Class CustomerController
 * @package HomeCredit\Controller
 */
class CustomerController
{
    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var ApiRepository
     */
    protected $apiRepository;

    /**
     * @var Form
     */
    protected $searchForm;

    /**
     * @var Form
     */
    protected $emailForm;

    /**
     * @var Twig_Environment
     */
    protected $twig;

    /**
     * CustomerController constructor.
     * @param LoggerInterface $logger
     * @param ApiRepository $apiRepository
     * @param Form $searchForm
     * @param Form $emailForm
     * @param Twig_Environment $twig
     */
    public function __construct(
        LoggerInterface $logger,
        ApiRepository $apiRepository,
        Form $searchForm,
        Form $emailForm,
        Twig_Environment $twig
    ) {
        $this->logger = $logger;
        $this->apiRepository = $apiRepository;
        $this->searchForm = $searchForm;
        $this->emailForm = $emailForm;
        $this->twig = $twig;
    }

    public function activate(Request $request)
    {
        return JsonResponse::create([
            'id' => $this->apiRepository->activateCustomer($request->request->get('id', null))
        ]);
    }

    public function emailValidate(Request $request)
    {
        return JsonResponse::create([
            'id' => $this->apiRepository->emailValidateCustomer($request->request->get('id', null))
        ]);
    }

    /**
     * @param Request $request
     * @return string
     */
    public function search(Request $request)
    {
        $user = null;

        $this->emailForm->handleRequest($request);
        $emailSuccessMessage = null;

        $this->searchForm->handleRequest($request);

        if ($this->emailForm->isValid()) {
            $formData = $this->emailForm->getData();

            try {
                $response = $this->apiRepository->changeCustomerEmail(
                    $formData['id'],
                    $formData['email'],
                    $formData['password']
                );

                if ($response) {
                    $emailSuccessMessage = 'Customer email address updated successfully.';
                }
            } catch (InvalidInputException $e) {
                foreach ($e->getErrors() as $field => $error) {
                    if ($field === '[id]') {
                        $this->emailForm->addError(
                            new FormError($error)
                        );
                    } else if ($field === '[email]') {
                        $this->emailForm->get('email')->addError(
                            new FormError($error)
                        );
                    } else if ($field === '[password]') {
                        $this->emailForm->get('password')->addError(
                            new FormError($error)
                        );
                    } else {
                        $this->emailForm->addError(
                            new FormError($error)
                        );
                    }
                }
            } catch (ServiceUnavailableHttpException $e) {
                $this->emailForm->addError(
                    new FormError('Unable to update user email. Please check your inputs try again later.')
                );
            }

            $user = $this->performCustomerSearch($formData['account_number']);

        } else if ($this->searchForm->isValid()) {
            $formData = $this->searchForm->getData();

            $user = $this->performCustomerSearch($formData['account_number']);
            if ($user) {
                $this->emailForm->get('id')->setData($user->id);
                $this->emailForm->get('account_number')->setData($formData['account_number']);
            }
        }

        return $this->twig->render('customers/search.html.twig', [
            'customer_search_form' => $this->searchForm->createView(),
            'customer_email_form' => $this->emailForm->createView(),
            'customer_email_success_message' => $emailSuccessMessage,
            'user' => $user,
        ]);
    }

    /**
     * @param mixed $accountNumber
     * @return stdClass|null
     */
    protected function performCustomerSearch($accountNumber)
    {
        try {
            $results = $this->apiRepository->customerSearch($accountNumber);

            $user = $results->data->customer;

            $user->created_at = DateTime::createFromFormat('U', $user->created_at);

            return $user;
        } catch (InvalidAccountNumberException $e) {
            $this->searchForm->addError(new FormError('Account number not found'));
        } catch (AccountNumberNotRegisteredException $e) {
            $this->searchForm->addError(new FormError('Customer is not registered'));
        }

        return null;
    }

    /**
     * @param Request $req
     * @return JsonResponse
     */
    public function resetPassword(Request $req)
    {
        $username = $req->request->get('username');

        if (empty($username)) {
            return new JsonResponse(['error' => 'Please provide email'], 400);
        }

        try {
            if ($this->apiRepository->resetCustomerPassword($username)) {
                return new JsonResponse(null, 202);
            }
            return new JsonResponse(['error' => 'Server error'], 500);
        } catch (InvalidInputException $e) {
            return new JsonResponse(['error' => 'Invalid email address'], 400);
        } catch (ServiceUnavailableHttpException $e) {
            return new JsonResponse(['error' => 'Unable to complete your request. Please try again.'], 500);
        }
    }
}
