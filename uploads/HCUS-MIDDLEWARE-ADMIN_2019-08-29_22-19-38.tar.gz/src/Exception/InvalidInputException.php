<?php

namespace HomeCredit\Exception;

use Exception;

/**
 * Class InvalidInputException
 * @package HomeCredit\Exception
 */
class InvalidInputException extends Exception
{
    /**
     * @var array
     */
    protected $errors;

    /**
     * @return array
     */
    public function getErrors()
    {
        return $this->errors;
    }

    /**
     * @param array $errors
     */
    public function setErrors(array $errors)
    {
        $this->errors = $errors;
    }

}