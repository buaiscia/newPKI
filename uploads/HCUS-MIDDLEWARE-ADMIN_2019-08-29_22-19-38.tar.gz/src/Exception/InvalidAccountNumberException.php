<?php

namespace HomeCredit\Exception;

use Exception;

/**
 * Class InvalidAccountNumberException
 * @package HomeCredit\Exception
 */
class InvalidAccountNumberException extends Exception
{
    protected $message = 'Invalid account number';
}