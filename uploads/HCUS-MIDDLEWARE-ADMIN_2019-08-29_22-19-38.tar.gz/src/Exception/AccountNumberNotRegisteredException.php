<?php

namespace HomeCredit\Exception;

class AccountNumberNotRegisteredException extends \Exception
{
    protected $message = 'Account number is valid but customer is not registered with an account';
}