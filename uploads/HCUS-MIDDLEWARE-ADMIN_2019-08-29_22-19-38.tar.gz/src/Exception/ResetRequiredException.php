<?php

namespace HomeCredit\Exception;

use Symfony\Component\Security\Core\Exception\BadCredentialsException;

/**
 * Class ResetRequiredException
 * @package HomeCredit\Exception
 */
class ResetRequiredException extends BadCredentialsException
{

}