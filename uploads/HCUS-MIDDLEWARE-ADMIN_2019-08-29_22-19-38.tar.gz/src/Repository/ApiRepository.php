<?php

namespace HomeCredit\Repository;

use DateTime;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\RequestOptions;
use HomeCredit\Exception\AccountNumberNotRegisteredException;
use HomeCredit\Exception\InvalidAccountNumberException;
use HomeCredit\Exception\InvalidInputException;
use HomeCredit\Exception\ResetRequiredException;
use Psr\Log\LoggerInterface;
use stdClass;
use Symfony\Component\HttpKernel\Exception\ServiceUnavailableHttpException;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationServiceException;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;

/**
 * Class ApiRepository
 * @package HomeCredit\Repository
 */
class ApiRepository
{
    /**
     * @var Client
     */
    protected $client;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var TokenStorageInterface
     */
    protected $token;

    /**
     * ApiRepository constructor.
     * @param LoggerInterface $logger
     * @param TokenStorageInterface $token
     * @param Client $client
     */
    public function __construct(LoggerInterface $logger, TokenStorageInterface $token, Client $client)
    {
        $this->logger = $logger;
        $this->token = $token;
        $this->client = $client;
    }

    /**
     * @param $username
     * @param $password
     * @param null|string $newPassword
     * @return mixed
     */
    public function authenticate($username, $password, $newPassword = null)
    {
        $payload = [
            'username' => $username,
            'password' => $password,
            'locale' => 'en-US',
        ];

        if (!empty($newPassword)) {
            $payload['new_password'] = $newPassword;
            $payload['new_password_verify'] = $newPassword;
        }

        try {
            $response = $this->client->post('api/v1/user/authenticate', [
                'json' => $payload,
            ]);

            return json_decode($response->getBody());
        } catch (RequestException $e) {
            if ($e->getCode() === 401) {
                $response = $e->getResponse();

                if ($response) {
                    $decodedResponse = json_decode($response->getBody(), true);
                    if (!empty($decodedResponse['error']['description']['[reset]'])) {
                        throw new ResetRequiredException(
                            "Your current password is only temporary. Please create a new one."
                        );
                    }
                }

                throw new BadCredentialsException('Invalid credentials.');
            }

            throw new AuthenticationServiceException('Server error. Please try again.');
        }
    }

    /**
     * @param string $refreshToken
     * @param string $accessToken
     * @param string $ikm
     * @return null|stdClass
     */
    public function refreshToken($refreshToken, $accessToken, $ikm)
    {
        try {
            $uri = 'api/v1/user/refresh';
            $date = (new DateTime())->format(DateTime::RFC1123);

            $payload = [
                'refresh_token' => $refreshToken,
            ];

            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader(
                        'POST',
                        $uri,
                        json_encode($payload),
                        $date,
                        $accessToken,
                        $ikm
                    ),
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject;
        } catch (RequestException $e) {
            $this->logger->error('Exception from refresh token endpoint', [
                'code' => $e->getCode(),
                'message' => $e->getMessage(),
            ]);

            throw new AuthenticationServiceException('Your credentials have expired. Please log in again.');
        }
    }

    /**
     * Activates a customer given their ID
     * @param integer $id
     * @return array
     */
    public function activateCustomer($id)
    {
        try {
            $payload = ['id' => $id];
            $date = (new DateTime())->format(DateTime::RFC1123);
            $uri = 'api/v1/supporter/activate';
            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $data = json_decode($response->getBody());

            return $data;
        } catch (RequestException $e) {
            if ($e->getCode() === 403) {
                $this->logger->debug('Unauthorized response from customer search');
                throw new UnauthorizedHttpException('You are not authorized to perform this action');
            } else if ($e->getCode() === 422) {
                $this->logger->debug('Bad credentials response from customer search');
                throw new BadCredentialsException('Your login has expired. Please login again.');
            }

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * Validates a user's email given their ID
     * @param integer $id
     * @return array
     */
    public function emailValidateCustomer($id)
    {
        try {
            $payload = ['id' => $id];
            $date = (new DateTime())->format(DateTime::RFC1123);
            $uri = 'api/v3/supporter/validateEmail';
            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $data = json_decode($response->getBody());

            return $data;
        } catch (RequestException $e) {
            if ($e->getCode() === 403) {
                $this->logger->debug('Unauthorized response from validating user\'s email');
                throw new UnauthorizedHttpException('You are not authorized to perform this action');
            } else if ($e->getCode() === 422) {
                $this->logger->debug('Bad credentials response from validating user\'s email');
                throw new BadCredentialsException('Your login has expired. Please login again.');
            }

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param string $cardNumber
     * @return mixed
     * @throws AccountNumberNotRegisteredException
     * @throws InvalidAccountNumberException
     */
    public function customerSearch($cardNumber)
    {
        try {
            $uri = 'api/v1/supporter/customer_info';
            $date = (new DateTime())->format(DateTime::RFC1123);
            $payload = [
                'card_number' => (string) $cardNumber,
            ];
            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $data = json_decode($response->getBody());

            return $data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                $this->logger->debug('Invalid account number response from customer search');
                throw new InvalidAccountNumberException();
            } else if ($e->getCode() === 403) {
                $this->logger->debug('Unauthorized response from customer search');
                throw new UnauthorizedHttpException('You are not authorized to perform this action');
            } else if ($e->getCode() === 404) {
                $this->logger->debug('Account number not registered response from customer search');
                throw new AccountNumberNotRegisteredException();
            } else if ($e->getCode() === 422) {
                $this->logger->debug('Bad credentials response from customer search');
                throw new BadCredentialsException('Your login has expired. Please login again.');
            }

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param string $cardNumber
     * @return mixed
     * @throws AccountNumberNotRegisteredException
     * @throws InvalidAccountNumberException
     */
    public function resendWelcomeMessage($account_id, $contact_method)
    {
        try {
            $uri = 'api/v3/supporter/resend_welcome_message';
            $date = (new DateTime())->format(DateTime::RFC1123);
            $payload = [
                'account_id' => $account_id,
                'contact_method' => $contact_method,
            ];
            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            return json_decode($response->getBody());
        } catch (RequestException $e) {
            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param string $cardNumber
     * @return mixed
     * @throws AccountNumberNotRegisteredException
     * @throws InvalidAccountNumberException
     */
    public function accountSearch($account_id)
    {
        try {
            $uri = 'api/v3/supporter/account';
            $date = (new DateTime())->format(DateTime::RFC1123);
            $payload = [
                'account_id' => (string) $account_id,
            ];
            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $data = json_decode($response->getBody());

            return $data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                $this->logger->debug('Invalid account id.');
                throw new InvalidAccountNumberException();
            } elseif ($e->getCode() === 404) {
                $this->logger->debug('Account number not registered response from customer search');
                throw new AccountNumberNotRegisteredException();
            }

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param $currentPassword
     * @param $newPassword
     * @return bool
     * @throws InvalidInputException
     * @throws ServiceUnavailableHttpException
     */
    public function updateProfilePassword($currentPassword, $newPassword)
    {
        try {
            $uri = 'api/v1/user/index';
            $date = (new DateTime())->format(DateTime::RFC1123);

            $payload = [
                'password' => $currentPassword,
                'new_password' => $newPassword,
                'new_password_verify' => $newPassword,
            ];

            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject->data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                $responseObject = json_decode($e->getResponse()->getBody());

                $this->logger->debug('Bad Request response from update profile password request', [
                    'message' => $e->getMessage(),
                    'body' => $responseObject,
                ]);

                $invalidInputException = new InvalidInputException();
                $error = $responseObject->error;
                if (!empty($error->description)) {
                    if (is_object($error->description)) {
                        $invalidInputException->setErrors((array) $error->description);
                    } else {
                        $invalidInputException->setErrors([$error->description]);
                    }
                }

                throw $invalidInputException;
            }

            $this->logger->error('Uncaught exception thrown from update profile password request', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
            ]);

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param $email
     * @return bool
     * @throws InvalidInputException
     * @throws ServiceUnavailableHttpException
     */
    public function resetCustomerPassword($username)
    {
        try {
            $response = $this->client->post('api/v1/user/resetpassword', [
                'json' => [
                    'username' => $username,
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject->data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                throw new InvalidInputException();
            }

            $this->logger->error('Uncaught exception thrown from reset customer password request', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
            ]);

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param $customerId
     * @param $email
     * @param $password
     * @return mixed
     * @throws InvalidInputException
     */
    public function changeCustomerEmail($customerId, $email, $password)
    {
        $date = (new DateTime())->format(DateTime::RFC1123);
        $uri = 'api/v1/supporter/customer';
        $payload = [
            'id' => $customerId,
            'email' => $email,
            'password' => $password,
        ];

        try {
            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject->data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                $responseObject = json_decode($e->getResponse()->getBody());

                $invalidInputException = new InvalidInputException();
                $error = $responseObject->error;
                if (!empty($error->description)) {
                    if (is_object($error->description)) {
                        $invalidInputException->setErrors((array) $error->description);
                    } else {
                        $invalidInputException->setErrors([$error->description]);
                    }
                }

                throw $invalidInputException;
            }

            $this->logger->error('Uncaught exception thrown from change customer email request', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
            ]);

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param int $page
     * @param $search
     * @return mixed
     */
    public function getStaff($page = 1, $search)
    {
        try {
            $uri = sprintf(
                'api/v1/admin/index?orderBy=email&page=%d&filterBy=email&filter=%s',
                $page,
                urlencode($search)
            );

            $date = (new DateTime())->format(DateTime::RFC1123);

            $response = $this->client->get($uri, [
                RequestOptions::HEADERS => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('GET', $uri, '', $date),
                ],
            ]);

            $data = json_decode($response->getBody(), true);

            return $data['data'];
        } catch (RequestException $e) {
            if ($e->getCode() === 403) {
                $this->logger->debug('Unauthorized response from get staff api request');
                throw new UnauthorizedHttpException('You are not authorized to perform this action');
            } else if ($e->getCode() === 422) {
                $this->logger->debug('Bad credentials response from get staff api request');
                throw new BadCredentialsException('Your login has expired. Please login again.');
            }

            $this->logger->error('Uncaught exception response from get staff api request', [
                'code' => $e->getCode(),
                'message' => $e->getMessage(),
            ]);
            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param int $page
     * @return mixed
     */
    public function getProducts($page = 1)
    {
        try {
            $uri = sprintf(
                'api/v3/admin/product?page=%d',
                $page
            );

            $date = (new DateTime())->format(DateTime::RFC1123);

            $response = $this->client->get($uri, [
                RequestOptions::HEADERS => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('GET', $uri, '', $date),
                ],
            ]);

            $data = json_decode($response->getBody(), true);

            return $data['data'];
        } catch (RequestException $e) {
            if ($e->getCode() === 403) {
                $this->logger->debug('Unauthorized response from get products api request');
                throw new UnauthorizedHttpException('You are not authorized to perform this action');
            } else if ($e->getCode() === 422) {
                $this->logger->debug('Bad credentials response from get staff api request');
                throw new BadCredentialsException('Your login has expired. Please login again.');
            }

            $this->logger->error('Uncaught exception response from get staff api request', [
                'code' => $e->getCode(),
                'message' => $e->getMessage(),
            ]);
            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param int $page
     * @return mixed
     */
    public function getLpfConfigurations($page = 1)
    {
        try {
            $uri = sprintf(
                'api/v3/admin/lpfEligibility?page=%d',
                $page
            );

            $date = (new DateTime())->format(DateTime::RFC1123);

            $response = $this->client->get($uri, [
                RequestOptions::HEADERS => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('GET', $uri, '', $date),
                ],
            ]);

            $data = json_decode($response->getBody(), true);

            return $data['data'];
        } catch (RequestException $e) {
            if ($e->getCode() === 403) {
                $this->logger->debug('Unauthorized response from get products api request');
                throw new UnauthorizedHttpException('You are not authorized to perform this action');
            } else if ($e->getCode() === 422) {
                $this->logger->debug('Bad credentials response from get staff api request');
                throw new BadCredentialsException('Your login has expired. Please login again.');
            }

            $this->logger->error('Uncaught exception response from get staff api request', [
                'code' => $e->getCode(),
                'message' => $e->getMessage(),
            ]);
            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param int $page
     * @param $search
     * @return mixed
     */
    public function getLpfConfigurationById($id)
    {
        try {
            $uri = 'api/v3/admin/lpfEligibility?id=' . $id;

            $date = (new DateTime())->format(DateTime::RFC1123);

            $response = $this->client->get($uri, [
                RequestOptions::HEADERS => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('GET', $uri, '', $date),
                ],
            ]);

            $data = json_decode($response->getBody(), true);

            return $data['data'];
        } catch (RequestException $e) {
            if ($e->getCode() === 403) {
                $this->logger->debug('Unauthorized response from get staff api request');
                throw new UnauthorizedHttpException('You are not authorized to perform this action');
            } else if ($e->getCode() === 422) {
                $this->logger->debug('Bad credentials response from get staff api request');
                throw new BadCredentialsException('Your login has expired. Please login again.');
            }

            $this->logger->error('Uncaught exception response from get staff api request', [
                'code' => $e->getCode(),
                'message' => $e->getMessage(),
            ]);
            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param int $page
     * @param $search
     * @return mixed
     */
    public function deleteLpfConfigurationById($id, $password)
    {
        try {
            $uri = 'api/v3/admin/lpfEligibility?id=' . $id;
            $date = (new DateTime())->format(DateTime::RFC1123);
            $payload = [
                'password' => $password,
            ];

            $response = $this->client->delete($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('DELETE', $uri, json_encode($payload), $date),
                ],
            ]);

            $data = json_decode($response->getBody(), true);

            return $data['data'];
        } catch (RequestException $e) {
            if ($e->getCode() === 403) {
                $this->logger->debug('Unauthorized response from get staff api request');
                throw new UnauthorizedHttpException('You are not authorized to perform this action');
            } else if ($e->getCode() === 422) {
                $this->logger->debug('Bad credentials response from get staff api request');
                throw new BadCredentialsException('Your login has expired. Please login again.');
            }

            $this->logger->error('Uncaught exception response from get staff api request', [
                'code' => $e->getCode(),
                'message' => $e->getMessage(),
            ]);
            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param string $id
     * @param string $yourPassword
     * @param string $email
     * @param string $password
     * @return stdClass
     * @throws InvalidInputException
     */
    public function updateProduct($id, $payload)
    {
        $date = (new DateTime())->format(DateTime::RFC1123);
        $uri = 'api/v3/admin/product?id=' . $id;

        try {

            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject->data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                $responseObject = json_decode($e->getResponse()->getBody());

                $invalidInputException = new InvalidInputException();
                $error = $responseObject->error;
                if (!empty($error->description)) {
                    if (is_object($error->description)) {
                        $invalidInputException->setErrors((array) $error->description);
                    } else {
                        $invalidInputException->setErrors([$error->description]);
                    }
                }

                throw $invalidInputException;
            } else if ($e->getCode() === 403) {
                // invalid "your password" provided
                $invalidInputException = new InvalidInputException;
                $invalidInputException->setErrors(['[password]' => 'Unable to validate your password']);
                throw $invalidInputException;
            }

            $this->logger->error('Uncaught exception thrown from update staff api request', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
            ]);

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param string $email
     * @param string $username
     * @param int $role
     * @return object
     * @throws InvalidInputException
     */
    public function createLpfConfiguration($accountBasedConfig, $transactionBasedConfig, $configurationName)
    {
        try {
            $uri = 'api/v3/admin/lpfEligibility';
            $payload = [
                'account_based_config' => $accountBasedConfig,
                "transaction_based_config" => $transactionBasedConfig,
                "configuration_name" => $configurationName,
            ];

            $date = (new DateTime())->format(DateTime::RFC1123);

            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject->data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                $responseObject = json_decode($e->getResponse()->getBody());

                $invalidInputException = new InvalidInputException();
                $error = $responseObject->error;
                if (!empty($error->description)) {
                    if (is_object($error->description)) {
                        $invalidInputException->setErrors((array) $error->description);
                    } else {
                        $invalidInputException->setErrors([$error->description]);
                    }
                }

                throw $invalidInputException;
            }

            $this->logger->error('Uncaught exception thrown from create staff member request', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
            ]);

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param int $page
     * @param $search
     * @return mixed
     */
    public function getProductById($id)
    {
        try {
            $uri = 'api/v3/admin/product?id=' . $id;

            $date = (new DateTime())->format(DateTime::RFC1123);

            $response = $this->client->get($uri, [
                RequestOptions::HEADERS => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('GET', $uri, '', $date),
                ],
            ]);

            $data = json_decode($response->getBody(), true);

            return $data['data'];
        } catch (RequestException $e) {
            if ($e->getCode() === 403) {
                $this->logger->debug('Unauthorized response from get staff api request');
                throw new UnauthorizedHttpException('You are not authorized to perform this action');
            } else if ($e->getCode() === 422) {
                $this->logger->debug('Bad credentials response from get staff api request');
                throw new BadCredentialsException('Your login has expired. Please login again.');
            }

            $this->logger->error('Uncaught exception response from get staff api request', [
                'code' => $e->getCode(),
                'message' => $e->getMessage(),
            ]);
            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param string $email
     * @param string $username
     * @param int $role
     * @return object
     * @throws InvalidInputException
     */
    public function createStaffMember($email, $username, $role)
    {
        try {
            $uri = 'api/v1/admin/index';
            $date = (new DateTime())->format(DateTime::RFC1123);
            $payload = [
                'email' => $email,
                'username' => $username,
                'role' => $role,
            ];

            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject->data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                $responseObject = json_decode($e->getResponse()->getBody());

                $invalidInputException = new InvalidInputException();
                $error = $responseObject->error;
                if (!empty($error->description)) {
                    if (is_object($error->description)) {
                        $invalidInputException->setErrors((array) $error->description);
                    } else {
                        $invalidInputException->setErrors([$error->description]);
                    }
                }

                throw $invalidInputException;
            }

            $this->logger->error('Uncaught exception thrown from create staff member request', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
            ]);

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param string $email
     * @param string $username
     * @param int $role
     * @return object
     * @throws InvalidInputException
     */
    public function createProduct($payload)
    {
        try {
            $uri = 'api/v3/admin/product';
            $date = (new DateTime())->format(DateTime::RFC1123);

            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject->data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                $responseObject = json_decode($e->getResponse()->getBody());

                $invalidInputException = new InvalidInputException();
                $error = $responseObject->error;
                if (!empty($error->description)) {
                    if (is_object($error->description)) {
                        $invalidInputException->setErrors((array) $error->description);
                    } else {
                        $invalidInputException->setErrors([$error->description]);
                    }
                }

                throw $invalidInputException;
            }

            $this->logger->error('Uncaught exception thrown from create staff member request', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
            ]);

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param int $id
     * @param string $password
     * @return bool
     */
    public function deleteStaffMember($id, $password)
    {
        try {
            $uri = 'api/v1/admin/index?id=' . $id;
            $date = (new DateTime())->format(DateTime::RFC1123);
            $payload = [
                'password' => $password,
            ];

            $response = $this->client->delete($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('DELETE', $uri, json_encode($payload), $date),
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject->data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400 or $e->getCode() === 403) {
                $responseObject = json_decode($e->getResponse()->getBody());

                $invalidInputException = new InvalidInputException();
                $error = $responseObject->error;
                if (!empty($error->description)) {
                    if (is_object($error->description)) {
                        $invalidInputException->setErrors((array) $error->description);
                    } else {
                        $invalidInputException->setErrors([$error->description]);
                    }
                } else if ($e->getCode() === 403) {
                    $invalidInputException->setErrors([
                        '[password]' => 'Unable to validate your password.',
                    ]);
                }

                throw $invalidInputException;
            }

            $this->logger->error('Uncaught exception thrown from delete staff member request', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
            ]);

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }

    }

    /**
     * @param string $id
     * @param string $yourPassword
     * @param string $email
     * @param string $password
     * @return stdClass
     * @throws InvalidInputException
     */
    public function updateStaff($id, $yourPassword, $email, $password)
    {
        $date = (new DateTime())->format(DateTime::RFC1123);
        $uri = 'api/v1/admin/index?id=' . $id;

        $payload = ['password' => $yourPassword];
        if ($email) {
            $payload['email'] = $email;
        }
        if ($password) {
            $payload['new_password'] = $password;
            $payload['new_password_verify'] = $password;
        }

        try {
            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject->data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                $responseObject = json_decode($e->getResponse()->getBody());

                $invalidInputException = new InvalidInputException();
                $error = $responseObject->error;
                if (!empty($error->description)) {
                    if (is_object($error->description)) {
                        $invalidInputException->setErrors((array) $error->description);
                    } else {
                        $invalidInputException->setErrors([$error->description]);
                    }
                }

                throw $invalidInputException;
            } else if ($e->getCode() === 403) {
                // invalid "your password" provided
                $invalidInputException = new InvalidInputException;
                $invalidInputException->setErrors(['[password]' => 'Unable to validate your password']);
                throw $invalidInputException;
            }

            $this->logger->error('Uncaught exception thrown from update staff api request', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
            ]);

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param string $id
     * @param string $yourPassword
     * @param string $email
     * @param string $password
     * @return stdClass
     * @throws InvalidInputException
     */
    public function updateLpfConfiguration($id, $payload)
    {
        $date = (new DateTime())->format(DateTime::RFC1123);
        $uri = 'api/v3/admin/lpfEligibility?id=' . $id;

        try {

            $response = $this->client->post($uri, [
                'json' => $payload,
                'headers' => [
                    'X-DATE' => $date,
                    'Authorization' => $this->getAuthorizationHeader('POST', $uri, json_encode($payload), $date),
                ],
            ]);

            $responseObject = json_decode($response->getBody());

            return $responseObject->data;
        } catch (RequestException $e) {
            if ($e->getCode() === 400) {
                $responseObject = json_decode($e->getResponse()->getBody());

                $invalidInputException = new InvalidInputException();
                $error = $responseObject->error;
                if (!empty($error->description)) {
                    if (is_object($error->description)) {
                        $invalidInputException->setErrors((array) $error->description);
                    } else {
                        $invalidInputException->setErrors([$error->description]);
                    }
                }

                throw $invalidInputException;
            } else if ($e->getCode() === 403) {
                // invalid "your password" provided
                $invalidInputException = new InvalidInputException;
                $invalidInputException->setErrors(['[password]' => 'Unable to validate your password']);
                throw $invalidInputException;
            }

            $this->logger->error('Uncaught exception thrown from update staff api request', [
                'message' => $e->getMessage(),
                'code' => $e->getCode(),
            ]);

            throw new ServiceUnavailableHttpException('Server error. Please try again later.');
        }
    }

    /**
     * @param string $method
     * @param string $uri
     * @param string $payload
     * @param string $date
     * @param null|string $accessToken
     * @param null|string $ikm
     * @return string
     */
    protected function getAuthorizationHeader($method, $uri, $payload, $date, $accessToken = null, $ikm = null)
    {
        // Fill in access token and salt from the session token, if not provided
        if (!$accessToken || !$ikm) {
            $tokenInterface = $this->token->getToken();
            if ($tokenInterface) {
                if (!$accessToken) {
                    $accessToken = $tokenInterface->getUser()->getAccessToken();
                }
                if (!$ikm) {
                    $ikm = $tokenInterface->getUser()->getIkm();
                }
            }
        }

        if (!$ikm || !$accessToken) {
            return '';
        }

        $hkdf = null;
        $salt = \random_bytes(32);
        $hkdf = \hash_hkdf(
            'sha256',
            \base64_decode($ikm),
            32,
            'HMAC|AuthenticationKey',
            $salt
        );

        // Create the signature string
        $signature = \hash('sha256', $payload) . "\n" .
        $method . "+/" . $uri . "\n" .
        $date . "\n" .
        \base64_encode($salt);

        $hmac = \base64_encode(
            \hash_hmac('sha256', $signature, \bin2hex($hkdf), true)
        );

        $authorization = 'HMAC ' . $accessToken . ',' . $hmac . ',' . \base64_encode($salt);
        return $authorization;
    }
}
