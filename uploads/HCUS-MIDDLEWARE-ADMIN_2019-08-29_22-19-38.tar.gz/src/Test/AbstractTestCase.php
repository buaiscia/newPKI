<?php

namespace HomeCredit\Test;

use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use HomeCredit\Security\User;
use Monolog\Handler\NullHandler;
use Monolog\Logger;
use Pimple\Container;
use Silex\Application;
use Silex\WebTestCase;
use Symfony\Component\BrowserKit\Cookie;
use Symfony\Component\HttpKernel\Client;
use Symfony\Component\Security\Guard\Token\PostAuthenticationGuardToken;

abstract class AbstractTestCase extends WebTestCase
{
    /**
     * @var Application
     */
    protected $app;

    public function createApplication()
    {
        /** @var \Silex\Application $app */
        $app = require __DIR__ . '/../../app.php';

        $app->extend('monolog', function ($monolog, $app) {
            $monolog->setHandlers([new NullHandler()]);

            return $monolog;
        });

        // prevent running tests in production
        if (!$app['debug']) {
            throw new \Exception('Attempting to run unit tests with debug disabled.');
        }

        // remove exception handler so we get clean error messages in CLI
        unset($app['exception_handler']);

        return $app;
    }

    /**
     * @param array $roles
     */
    public function loginAs($roles)
    {
        $this->app['session']->set('app.security.refresh_token', 'refresh_token');
        $this->app['session']->set('app.security.access_token', 'access_token');
        $this->app['session']->set('app.security.ikm', 'ikm');
        $this->app['session']->set('app.security.username', 'username');
        $this->app['session']->set('app.security.roles', implode(',', $roles));
    }
}