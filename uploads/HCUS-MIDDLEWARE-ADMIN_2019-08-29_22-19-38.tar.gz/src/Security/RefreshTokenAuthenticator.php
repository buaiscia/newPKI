<?php
namespace HomeCredit\Security;

use HomeCredit\Repository\ApiRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Generator\UrlGenerator;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Guard\AbstractGuardAuthenticator;
use Symfony\Component\Security\Guard\GuardAuthenticatorInterface;

class RefreshTokenAuthenticator extends AbstractAuthenticator
{
    /**
     * @var UrlGenerator
     */
    protected $urlGenerator;

    /**
     * @var ApiRepository
     */
    protected $apiRepository;

    public function __construct(ApiRepository $apiRepository, UrlGenerator $urlGenerator)
    {
        $this->apiRepository = $apiRepository;
        $this->urlGenerator = $urlGenerator;
    }

    public function start(Request $request, AuthenticationException $authException = null)
    {
        // nothing here, not used
    }

    public function getCredentials(Request $request)
    {
        $isAuthEndpoint = in_array($request->getPathInfo(), [
            $this->urlGenerator->generate('auth_login'),
            $this->urlGenerator->generate('auth_reset')
        ]);

        if ($isAuthEndpoint) {
            return null;
        }

        // get credentials from the session and return them
        $session = $request->getSession();

        $refreshToken = $session->get('app.security.refresh_token');
        $accessToken = $session->get('app.security.access_token');
        $ikm = $session->get('app.security.ikm');
        $username = $session->get('app.security.username');
        $roles = $session->get('app.security.roles');

        if ($refreshToken && $accessToken && $ikm && $username && $roles) {
            return [
                'refreshToken' => $refreshToken,
                'accessToken' => $accessToken,
                'ikm' => $ikm,
                'username' => $username,
                'roles' => explode(',', $roles),
            ];
        }

        throw new BadCredentialsException('Your session has expired. Please login again.');
    }

    public function getUser($credentials, UserProviderInterface $userProvider)
    {
        // send api request, create user object
        return User::createFromResponseObject(
            $this->apiRepository->refreshToken(
                $credentials['refreshToken'],
                $credentials['accessToken'],
                $credentials['ikm']
            ),
            $credentials['username'],
            $credentials['roles']
        );
    }

    public function checkCredentials($credentials, UserInterface $user)
    {
        return true;
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token, $providerKey)
    {
        $user = $token->getUser();
        $session = $request->getSession();

        $session->set('app.security.roles', implode(',', $user->getRoles()));
        $session->set('app.security.refresh_token', $user->getRefreshToken());
        $session->set('app.security.access_token', $user->getAccessToken());
        $session->set('app.security.ikm', $user->getIkm());
        $session->set('app.security.username', $user->getUsername());

        return null;
    }

    public function supportsRememberMe()
    {
        return false;
    }

}