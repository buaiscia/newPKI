<?php

namespace HomeCredit\Security;

use DateTime;
use Exception;
use HomeCredit\Exception\ResetRequiredException;
use HomeCredit\Repository\ApiRepository;
use Psr\Log\LoggerInterface;
use Symfony\Component\Form\Form;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Generator\UrlGenerator;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Core\Security;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Guard\AbstractGuardAuthenticator;

/**
 * Class FormAuthenticator
 * @package HomeCredit\Security
 */
class FormAuthenticator extends AbstractAuthenticator
{

    /**
     * @var ApiRepository
     */
    protected $apiRepository;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Form
     */
    protected $loginForm;

    /**
     * @var Form
     */
    protected $resetForm;

    /**
     * FormAuthenticator constructor.
     * @param ApiRepository $apiRepository
     * @param LoggerInterface $logger
     * @param Form $loginForm
     * @param UrlGenerator $urlGenerator
     */
    public function __construct(
        ApiRepository $apiRepository,
        LoggerInterface $logger,
        Form $loginForm,
        Form $resetForm,
        UrlGenerator $urlGenerator
    ) {
        $this->apiRepository = $apiRepository;
        $this->logger = $logger;
        $this->loginForm = $loginForm;
        $this->resetForm = $resetForm;
        $this->urlGenerator = $urlGenerator;
    }

    /**
     * @param Request $request
     * @param AuthenticationException|null $authException
     * @return RedirectResponse
     */
    public function start(Request $request, AuthenticationException $authException = null)
    {
        $request->getSession()->set(Security::AUTHENTICATION_ERROR, $authException);

        return new RedirectResponse($this->urlGenerator->generate('auth_login'));
    }

    /**
     * @param Request $request
     * @return array|null
     */
    public function getCredentials(Request $request)
    {
        if ($request->getPathInfo() === $this->urlGenerator->generate('auth_login') and $request->getMethod() === 'POST') {
            $this->loginForm->handleRequest($request);
            $this->resetForm->handleRequest($request);

            if ($this->loginForm->isValid()) {
                $form = $this->loginForm;
            } elseif ($this->resetForm->isValid()) {
                $form = $this->resetForm;
            } else {
                return null;
            }

            $formData = $form->getData();

            return $formData;
        }

        return null;
    }

    /**
     * @param mixed $credentials
     * @param UserProviderInterface $userProvider
     * @return null|User|UserInterface
     */
    public function getUser($credentials, UserProviderInterface $userProvider)
    {
        $authResponse = $this->apiRepository->authenticate(
            $credentials['username'],
            $credentials['password'],
            !empty($credentials['new_password'])? $credentials['new_password']: null
        );

        if ($authResponse) {
            $user = User::createFromResponseObject($authResponse, $credentials['username']);

            return $user;
        }

        throw new BadCredentialsException('Your login has expired. Please login again.');
    }

    /**
     * @param mixed $credentials
     * @param UserInterface $user
     * @return bool
     */
    public function checkCredentials($credentials, UserInterface $user)
    {
        return true;
    }

    /**
     * @param Request $request
     * @param TokenInterface $token
     * @param string $providerKey
     * @return RedirectResponse
     */
    public function onAuthenticationSuccess(Request $request, TokenInterface $token, $providerKey)
    {
        /** @var User $user */
        $user = $token->getUser();
        $session = $request->getSession();

        $session->set('app.security.roles', implode(',', $user->getRoles()));
        $session->set('app.security.refresh_token', $user->getRefreshToken());
        $session->set('app.security.access_token', $user->getAccessToken());
        $session->set('app.security.ikm', $user->getIkm());
        $session->set('app.security.username', $user->getUsername());

        $session->migrate();
        
        if (in_array('ROLE_ADMINISTRATOR', $user->getRoles()) || in_array('ROLE_SUPERVISOR', $user->getRoles())) {
            return new RedirectResponse($this->urlGenerator->generate('admin_staff'));
        } else {
            return new RedirectResponse($this->urlGenerator->generate('customer_search'));
        }
    }

    /**
     * @return bool
     */
    public function supportsRememberMe()
    {
        return false;
    }
}
