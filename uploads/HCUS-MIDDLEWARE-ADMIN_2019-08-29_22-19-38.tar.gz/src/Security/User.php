<?php

namespace HomeCredit\Security;

use DateTime;
use stdClass;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;

/**
 * Class User
 * @package HomeCredit\Security
 */
class User implements UserInterface
{
    /**
     * @var string
     */
    protected $username;

    /**
     * @var string
     */
    protected $accessToken;

    /**
     * @var string
     */
    protected $refreshToken;

    /**
     * @var string
     */
    protected $ikm;

    /**
     * @var array
     */
    protected $roles;

    /**
     * @var DateTime
     */
    protected $expiresAt;

    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        // arbitrary, unused
        return 'password';
    }

    /**
     * @return string
     */
    public function getSalt()
    {
        // arbitrary, unused
        return 'salt';
    }

    /**
     * @return mixed
     */
    public function getRoles()
    {
        return $this->roles;
    }

    /**
     * @param array $roles
     */
    public function setRoles(array $roles)
    {
        $this->roles = $roles;
    }

    /**
     * @return DateTime
     */
    public function getExpiresAt()
    {
        return $this->expiresAt;
    }

    /**
     * @param DateTime $expiresAt
     */
    public function setExpiresAt($expiresAt)
    {
        $this->expiresAt = $expiresAt;
    }

    /**
     * @return string
     */
    public function getAccessToken()
    {
        return $this->accessToken;
    }

    /**
     * @param string $accessToken
     */
    public function setAccessToken($accessToken)
    {
        $this->accessToken = $accessToken;
    }

    /**
     * @return string
     */
    public function getRefreshToken()
    {
        return $this->refreshToken;
    }

    /**
     * @param string $refreshToken
     */
    public function setRefreshToken($refreshToken)
    {
        $this->refreshToken = $refreshToken;
    }

    /**
     * @return string
     */
    public function getIkm()
    {
        return $this->ikm;
    }

    /**
     * @param string $ikm
     */
    public function setIkm($ikm)
    {
        $this->ikm = $ikm;
    }

    /**
     * @return void
     */
    public function eraseCredentials()
    {
    }

    /**
     * @param stdClass $responseObject
     * @param $username
     * @param null $roles
     * @return static
     */
    public static function createFromResponseObject(stdClass $responseObject, $username, $roles = null)
    {
        $userData = $responseObject->data;

        if (
            empty($userData->access_token) 
            || empty($userData->refresh_token) 
            || empty($userData->ikm) 
            || empty($userData->expires_at)
        ) {
            throw new AuthenticationException('Authentication service unavailable');
        }

        $user = new self();
        $user->setUsername($username);
        $user->setAccessToken($userData->access_token);
        $user->setRefreshToken($userData->refresh_token);
        $user->setIkm($userData->ikm);
        $user->setExpiresAt(DateTime::createFromFormat('U', $userData->expires_at));

        if (!empty($userData->role)) {
            if ($userData->role === 2) {
                $user->setRoles(['ROLE_SUPPORTER']);
            } else if ($userData->role === 3) {
                $user->setRoles(['ROLE_ADMINISTRATOR']);
            } else if ($userData->role === 4) {
                $user->setRoles(['ROLE_SUPERVISOR']);
            } else {
                throw new BadCredentialsException('Invalid credentials.');
            }
        } else if ($roles) {
            $user->setRoles($roles);
        }

        return $user;
    }
}
