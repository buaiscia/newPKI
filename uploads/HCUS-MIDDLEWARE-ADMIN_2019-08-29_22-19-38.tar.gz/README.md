# HCUS Admin

[!["Built with Pantheon"](https://img.shields.io/badge/Build%20With-Pantheon-orange.svg?style=flat-square)]("https://ci.pkiapps.com")
[!["Pantheon-CI"](https://api.ci.pkiapps.com/gitlab/hcus/web-admin.svg)]("https://ci.pkiapps.com")

## This application allows:
- Admins and Supporters to log into their account
- Admins to create Supporters
- Supporters to search User accounts
- Supporters to reset a User's email address.
- Supporters to submit a password reset for a User


## Vagrant Provisioning

Just up the virtual machine. Dependencies will be downloaded and the app 
will be built with standard configuration.

```
vagrant up
```

## Docker Provisioning

Docker support is provided through `compose` and `make` commands. In general, you can provision a complete Docker environment by running the following commands:

```
make build
```

> This configuration requires Docker CE 17.06.0+.

## Configuration

Config files are located in `config/`. 
For local development, create a `config/local.yml` to update defaults in `config/default.yml`.

### API Integration
This app communicates with the backend via an integration with the [Home Credit PKI Middleware](https://git.pkiapps.com/hcus/api). API tokens are stored in the user session and refreshed on every page load.

## Commands

All CLI commands are managed through `make`.

| Command | Description|
|---------|------------|
| `nvm`   | Install [Node Version Manager](https://github.com/creationix/nvm). Note this command does not work on Windows |
| `npm`   | Install NodeJS dependencies. If `NPMCMD` is specified, `npm run  $NPMCMD` will be run. `dist`, and `watch` are valid `NPMCMD` parameters |
| `composer` | Installs Composer dependencies through Docker container |
| `docker` | Creates a Docker environment |
| `vagrant` | Creates a Vagrant environment |
| `tlscerts` | Creates TLS certificates for Apache2 |
| `archive` | Creates an archive from the specified `ARCHIVE` arguement |
| `build` | Alias that runs `npm local` and `composer install` |

> The docker environment can be destroyed by running `docker-compose down`.