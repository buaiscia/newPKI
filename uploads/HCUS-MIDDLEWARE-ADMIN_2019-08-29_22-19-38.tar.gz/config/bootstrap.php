<?php

use HomeCredit\FormType\ChangeProfilePasswordFormType;
use HomeCredit\FormType\CreateStaffMemberFormType;
use HomeCredit\FormType\CustomerEmailFormType;
use HomeCredit\FormType\ResendWelcomeMessageFormType;
use HomeCredit\FormType\CustomerSearchFormType;
use HomeCredit\FormType\SupporterSearchFormType;
use HomeCredit\Provider\ApiServiceProvider;
use HomeCredit\Provider\AuthenticationServiceProvider;
use HomeCredit\Provider\YAMLConfigServiceProvider;
use HomeCredit\Twig\Extension\VersionedAssetExtension;
use Monolog\Logger;
use Pimple\Container;
use Ramsey\Uuid\Uuid;
use Silex\Application;
use Silex\Provider\CsrfServiceProvider;
use Silex\Provider\FormServiceProvider;
use Silex\Provider\HttpFragmentServiceProvider;
use Silex\Provider\MonologServiceProvider;
use Silex\Provider\RoutingServiceProvider;
use Silex\Provider\ServiceControllerServiceProvider;
use Silex\Provider\TranslationServiceProvider;
use Silex\Provider\TwigServiceProvider;
use Silex\Provider\ValidatorServiceProvider;
use Silex\Provider\WebProfilerServiceProvider;

if (!defined('ROOT_DIR')) {
    define('ROOT_DIR', dirname(__DIR__) . '/');
}

$app = new Application();

// Config
$app->register(new YAMLConfigServiceProvider(), [
    'config.dir' => ROOT_DIR . 'config/'
]);

// Debug mode?
$app['debug'] = $app['config']['debug'];
 
if ($app['debug']) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
}

// Logging
$app->register(
    new MonologServiceProvider(),
    [
        'monolog.logfile' => ROOT_DIR . 'logs/app.log',
        'monolog.level' => constant('\Monolog\Logger::' . $app['config']['log']['level']),
        'monolog.name' => $app['config']['name'],
    ]
);

$app->register(new AuthenticationServiceProvider());

// Templates
$app->register(new TwigServiceProvider(), [
    'twig.path' => ROOT_DIR . 'assets/templates',
    'twig.options' => [
        // 'cache' => ROOT_DIR . 'cache/',
    ],
]);

$app->register(new CsrfServiceProvider());
$app->register(new TranslationServiceProvider(), [
    'locale' => 'en'
]);
$app->register(new ValidatorServiceProvider());
$app->register(new FormServiceProvider(), [
    'twig.form.templates' => ['bootstrap_3_layout.html.twig'],
]);
$app['app.form.customer_search'] = function (Container $app) {
    return $app['form.factory']->create(CustomerSearchFormType::class);
};
$app['app.form.resend_welcome_message'] = function (Container $app) {
    return $app['form.factory']->create(ResendWelcomeMessageFormType::class);
};
$app['app.form.profile'] = function (Container $app) {
    return $app['form.factory']->create(ChangeProfilePasswordFormType::class);
};
$app['app.form.customer_email'] = function (Container $app) {
    return $app['form.factory']->create(CustomerEmailFormType::class);
};

// Controllers as services
$app->register(new ServiceControllerServiceProvider());

// Generating URLs
$app->register(new RoutingServiceProvider());

// Api Connection Services
$app->register(new ApiServiceProvider());

if ($app['config']['profiler']['enable'] && $app['debug']) {
    $app->register(new HttpFragmentServiceProvider());
    $app->register(new WebProfilerServiceProvider(), array(
        'profiler.cache_dir' => ROOT_DIR . '/cache/profiler',
    ));
}

/**
 * In order to get auto-complete in IDEs like PHPStorm,
 * uncomment this line and process a request.
 * This will dump a pimple.json file into the root folder.
 *
 * More Info:
 * Pimple Dumper: https://github.com/Sorien/silex-pimple-dumper
 * PHPStorm Plugin: https://github.com/Sorien/silex-idea-plugin
 */
$app->register(new Sorien\Provider\PimpleDumpProvider());


// Add request ID to each log to group requests
$app['request.id'] = function () {
    return Uuid::uuid4()->toString();
};

// =r,>pH[h\fm,Hx&#
$app->extend('monolog', function (Logger $logger, Container $app) {
    $logger->pushProcessor(function ($data) use ($app) {
        $data['extra']['request_id'] = $app['request.id'];

        return $data;
    });

    foreach ($logger->getHandlers() as $handler) {
        $handler->setFormatter(
            new \Monolog\Formatter\LineFormatter(
                "[%datetime%] [%extra.request_id%] %channel%.%level_name%: %message% %context% %extra%\n"
            )
        );
    }

    return $logger;
});

// Add versioned assets extension to twig
$app->extend('twig', function (Twig_Environment $twig) {
    $twig->addExtension(new VersionedAssetExtension(
        ROOT_DIR . 'web/assets/assets.json'
    ));

    return $twig;
});

return $app;
