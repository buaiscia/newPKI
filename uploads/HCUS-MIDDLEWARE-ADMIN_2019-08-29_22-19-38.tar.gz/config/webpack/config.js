'use strict';
var webpack = require('webpack'),
    path = require('path'),
    autoprefixer = require('autoprefixer'),
    ExtractTextPlugin = require('extract-text-webpack-plugin'),
    AssetsPlugin = require('assets-webpack-plugin');

module.exports = {
    entry:   {
        'main' : [path.resolve(__dirname, '../../assets/js/main.js')]
    },
    output:  {
        path       : path.resolve(__dirname, '../../web/'),
        publicPath : '/',
        filename   : 'assets/js/[name].[hash].js'
    },
    module:  {
        loaders: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                loader: 'babel-loader',
                query: {
                    presets: ['es2015']
                }
            },
            {
                test: /\.scss$/,
                loader: ExtractTextPlugin.extract(['css', 'sass', 'postcss']),
            },
            {
                test: /\.(jpg|png)$/,
                loader: "file-loader?name=assets/img/[name].[ext]"
            },
            {
              test: /\.woff$/,
              loader: 'url',
              query: {
                'limit': 10000,
                'mimetype': 'application/font-woff',
                'name': "assets/fonts/[name].[ext]"
              }
            }, {
              test: /\.woff2$/,
              loader: 'url',
              query: {
                'limit': 10000,
                'mimetype': 'application/font-woff2',
                'name': "assets/fonts/[name].[ext]"
              }
            }, {
              test: /\.(eot|ttf|svg|gif|png)$/,
              loader: "file-loader",
              query: {
                'limit': 10000,
                'name': "assets/fonts/[name].[ext]"
              }
            }
        ]
    },
    resolve: {
        extensions: ['', '.js', '.scss']
    },
    resolveLoader: {
        root: path.resolve(__dirname, '../../node_modules'),
        extensions: ['', '.js', '.scss']
    },
    postcss: function () {
        return [autoprefixer({browsers:['last 2 versions']})];
    },
    plugins: [
        new webpack.ProvidePlugin({
            $: "jquery",
            jQuery: "jquery",
            "window.jQuery": "jquery"
        }),
        new webpack.NoErrorsPlugin(),
        new ExtractTextPlugin('assets/styles/[name].[hash].css', {allChunks: true}),
        new webpack.optimize.OccurenceOrderPlugin(),
        new webpack.optimize.UglifyJsPlugin({
            compress: {
                warnings: false
            },
            output: {
                comments: false
            }
        }),
        new AssetsPlugin({filename: 'web/assets/assets.json'})
    ]
};
