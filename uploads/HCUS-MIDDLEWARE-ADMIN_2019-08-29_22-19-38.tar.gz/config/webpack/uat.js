var webpack = require('webpack'),
    path = require('path'),
    config = require('./config');

config.plugins.push(
    new webpack.DefinePlugin({
        'APPLICATION_ENV' : '"uat"',
        'process.env.NODE_ENV': '"production"'
    })
);

module.exports = config;
