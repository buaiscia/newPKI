var webpack = require('webpack'),
    path = require('path'),
    config = require('./config'),
    LiveReloadPlugin = require('webpack-livereload-plugin'),
    CleanWebpackPlugin = require('clean-webpack-plugin');

config.plugins.push(
    new CleanWebpackPlugin(['img', 'js', 'styles'], {
        root: path.resolve(__dirname, '../../web/assets/')
    }),
    new webpack.DefinePlugin({
        'APPLICATION_ENV' : '"local"',
        'process.env.NODE_ENV': '"production"'
    }),
    new LiveReloadPlugin()
);

module.exports = Object.assign({}, config, {
    devtool: 'source-map'
});
