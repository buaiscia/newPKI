var webpack = require('webpack'),
    path = require('path'),
    config = require('./config'),
    ExtractTextPlugin = require('extract-text-webpack-plugin'),
    AssetsPlugin = require('assets-webpack-plugin');

config.plugins.push(
    new webpack.DefinePlugin({
        'APPLICATION_ENV' : '"master"',
        'process.env.NODE_ENV': '"production"'
    })
);

module.exports = config;
